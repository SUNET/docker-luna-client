
// ****************************************************************************
// Copyright (c) 2016 Gemalto, Inc. All rights reserved.
//
// All rights reserved.  This file contains information that is
// proprietary to SafeNet, Inc. and may not be distributed
// or copied without written consent from Gemalto, Inc.
// ****************************************************************************

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.AlgorithmParameters;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import com.safenetinc.luna.LunaSlotManager;
import com.safenetinc.luna.LunaUtils;
import com.safenetinc.luna.exception.LunaCryptokiException;

/**
 * This sample demonstrates wrapping a key. This demo assumes that the Luna providers are not listed first in the
 * java.security file and that a software provider is the default This could be SUN / IBM / BC / ...
 */
public class CipherCTRWrapUnwrapDemo {

  // Configure these as required.
  private static final int slot = 0;

  private static final String passwd = "userpin";

  public static void main(String args[]) {
    // LunaSlotManager manager;
    // manager = LunaSlotManager.getInstance();
    //
    // try {
    // manager.login(slot, passwd); // log in to the designated slot
    // } catch (Exception e) {
    // System.out.println("Exception during login");
    // System.exit(1);
    // }
    KeyStore myKeyStore = null;
    try {

      /* Note: could also use a keystore file, which contains the token label or slot no. to use. Load that via
       * "new FileInputStream(ksFileName)" instead of ByteArrayInputStream. Save objects to the keystore via a
       * FileOutputStream. */

      ByteArrayInputStream is1 = new ByteArrayInputStream(("slot:" + slot).getBytes());
      myKeyStore = KeyStore.getInstance("Luna");
      myKeyStore.load(is1, passwd.toCharArray());
    } catch (KeyStoreException kse) {
      System.out.println("Unable to create keystore object");
      System.exit(-1);
    } catch (NoSuchAlgorithmException nsae) {
      System.out.println("Unexpected NoSuchAlgorithmException while loading keystore");
      System.exit(-1);
    } catch (CertificateException e) {
      System.out.println("Unexpected CertificateException while loading keystore");
      System.exit(-1);
    } catch (IOException e) {
      // this should never happen
      System.out.println("Unexpected IOException while loading keystore.");
      System.exit(-1);
    }

    byte[] bytes = "Encrypt Me!".getBytes();
    byte[] aesencrypted = null;
    KeyGenerator kg = null;
    SecretKey hwAESKeyToBeWrapped = null;
    SecretKey hwAESWrappingKey = null;
    SecretKey hw3DESWrappingKey = null;
    byte[] wrappedAESKey = null;
    byte[] wrapped3DESKey = null;
    SecretKey unwrappedAESKey = null;
    SecretKey unwrapped3DESKey = null;

    try {
      LunaSlotManager.getInstance().setSecretKeysExtractable(true);

      // ********************************************
      // need to make an aes key in HSM
      // ********************************************
      kg = KeyGenerator.getInstance("AES", "LunaProvider");
      kg.init(256);
      hwAESKeyToBeWrapped = kg.generateKey();

      // ********************************************
      // make the wrapping key. AES
      // ********************************************
      kg = KeyGenerator.getInstance("AES", "LunaProvider");
      kg.init(256);
      hwAESWrappingKey = kg.generateKey();

      // ********************************************
      // make the wrapping key. 3DES
      // ********************************************
      kg = KeyGenerator.getInstance("DESede", "LunaProvider");
      hw3DESWrappingKey = kg.generateKey();

    } catch (Exception e) {
      System.out.println("Exception generating keys");
      e.printStackTrace();
      System.exit(1);
    }

    // ********************************************
    // encrypt something - aes
    // ********************************************
    try {
      Cipher myCipher = Cipher.getInstance("AES/CTR/NoPadding");
      byte[] ivBytes = { (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72,
          (byte) 73, (byte) 74, (byte) 75, (byte) 76, (byte) 77, (byte) 78, (byte) 79, (byte) 80 };
      AlgorithmParameters mAlgParams = AlgorithmParameters.getInstance("IV");
      mAlgParams.init(new IvParameterSpec(ivBytes));
      myCipher.init(Cipher.ENCRYPT_MODE, hwAESKeyToBeWrapped, mAlgParams);
      aesencrypted = myCipher.doFinal(bytes);
    } catch (Exception e) {
      System.out.println("Exception ciphering the data with software AES key");
      e.printStackTrace();
      System.exit(1);
    }

    System.out.println("AES CTR wrap/unwrap");

    // ********************************************
    // try to wrap the aes key (AES)
    // ********************************************
    try {
      Cipher myWrapper = Cipher.getInstance("AES/CTR/NoPadding", "LunaProvider");
      byte[] ctrAESBytes = { (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72,
          (byte) 73, (byte) 74, (byte) 75, (byte) 76, (byte) 77, (byte) 78, (byte) 79, (byte) 80 };
      AlgorithmParameters mAlgParams = AlgorithmParameters.getInstance("IV", "LunaProvider");
      mAlgParams.init(new IvParameterSpec(ctrAESBytes));
      myWrapper.init(Cipher.WRAP_MODE, hwAESWrappingKey, mAlgParams);
      wrappedAESKey = myWrapper.wrap(hwAESKeyToBeWrapped);

    } catch (InvalidKeyException ikex) {
      // If the InvalidKeyException is caused by a LunaCryptokiException, we're trying
      // to wrap the AES key off the HSM. This is not allowed because the key is not
      // marked extractable by default. The key must be created with a software provider
      // for this sample to work properly.
      Throwable cause = ikex.getCause();
      if ((cause != null) && (cause instanceof LunaCryptokiException)) {
        LunaCryptokiException lcex = (LunaCryptokiException) cause;
        if (lcex.GetCKRValue() == 0x6A) {
          System.out.println("The AES key was created with the Luna provider, and cannot"
              + " be wrapped off the HSM.  This demo requires a software crypto"
              + " provider that supports AES to have precedence over the Luna provider" + " in java.security");
          System.exit(1);
        }
      }
      System.out.println("Exception during wrapping of software AES key");
      ikex.printStackTrace();
      System.exit(1);

    } catch (Exception ex) {
      System.out.println("Exception during wrapping of software AES key");
      ex.printStackTrace();
      System.exit(1);
    }

    // ********************************************
    // unwrap the aes key (AES)
    // ********************************************
    try {
      Cipher myUnwrapper = Cipher.getInstance("AES/CTR/NoPadding", "LunaProvider");
      byte[] ctrAESBytes = { (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72,
          (byte) 73, (byte) 74, (byte) 75, (byte) 76, (byte) 77, (byte) 78, (byte) 79, (byte) 80 };
      AlgorithmParameters mAlgParams = AlgorithmParameters.getInstance("IV", "LunaProvider");
      mAlgParams.init(new IvParameterSpec(ctrAESBytes));

      myUnwrapper.init(Cipher.UNWRAP_MODE, hwAESWrappingKey, mAlgParams);
      unwrappedAESKey = (SecretKey) myUnwrapper.unwrap(wrappedAESKey, "AES", Cipher.SECRET_KEY);

    } catch (Exception e) {
      System.out.println("Exception attempting to unwrap wrapped AES key");
      e.printStackTrace();
      System.exit(1);
    }

    // ********************************************
    // decrypt the encrypted value - AES
    // ********************************************
    try {
      Cipher myCipher = Cipher.getInstance("AES/CTR/NoPadding", "LunaProvider");
      byte[] ivBytes = { (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72,
          (byte) 73, (byte) 74, (byte) 75, (byte) 76, (byte) 77, (byte) 78, (byte) 79, (byte) 80 };
      AlgorithmParameters mAlgParams = AlgorithmParameters.getInstance("IV", "LunaProvider");
      mAlgParams.init(new IvParameterSpec(ivBytes));
      myCipher.init(Cipher.DECRYPT_MODE, unwrappedAESKey, mAlgParams);
      byte[] aesdecrypted = myCipher.doFinal(aesencrypted);

      System.out.println("\n\n-----------------------");
      System.out.println("original: " + LunaUtils.getHexString(bytes, true));
      System.out.println("encrypted: " + LunaUtils.getHexString(aesencrypted, true));
      System.out.println("decrypted: " + LunaUtils.getHexString(aesdecrypted, true));
      System.out.println("\n\n-----------------------");

      if (java.util.Arrays.equals(bytes, aesdecrypted)) {
        System.out.println("Decryption was successful");
      } else
        System.out.println("*** decryption failed");
      System.out.println("-----------------------\n\n");

    } catch (Exception e) {
      System.out.println("Exception deciphering the AES-ciphered data");
      e.printStackTrace();
    }

    System.out.println("3DES CTR wrap/unwrap");

    // ********************************************
    // try to wrap the aes key (3DES)
    // ********************************************
    try {
      Cipher myWrapper = Cipher.getInstance("DESede/CTR/NoPadding", "LunaProvider");
      byte[] ctr3DESBytes = { (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72 };
      AlgorithmParameters mAlgParams = AlgorithmParameters.getInstance("IV", "LunaProvider");
      mAlgParams.init(new IvParameterSpec(ctr3DESBytes));
      myWrapper.init(Cipher.WRAP_MODE, hw3DESWrappingKey, mAlgParams);
      wrapped3DESKey = myWrapper.wrap(hwAESKeyToBeWrapped);

    } catch (InvalidKeyException ikex) {
      // If the InvalidKeyException is caused by a LunaCryptokiException, we're trying
      // to wrap the AES key off the HSM. This is not allowed because the key is not
      // marked extractable by default. The key must be created with a software provider
      // for this sample to work properly.
      Throwable cause = ikex.getCause();
      if ((cause != null) && (cause instanceof LunaCryptokiException)) {
        LunaCryptokiException lcex = (LunaCryptokiException) cause;
        if (lcex.GetCKRValue() == 0x6A) {
          System.out.println("The AES key was created with the Luna provider, and cannot"
              + " be wrapped off the HSM.  This demo requires a software crypto"
              + " provider that supports AES to have precedence over the Luna provider" + " in java.security");
          System.exit(1);
        }
      }
      System.out.println("Exception during wrapping of software AES key");
      ikex.printStackTrace();
      System.exit(1);

    } catch (Exception ex) {
      System.out.println("Exception during wrapping of software AES key");
      ex.printStackTrace();
      System.exit(1);
    }

    // ********************************************
    // unwrap the aes key (3DES)
    // ********************************************
    try {
      Cipher myUnwrapper = Cipher.getInstance("DESede/CTR/NoPadding", "LunaProvider");
      byte[] ctr3DESBytes = { (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72 };
      AlgorithmParameters mAlgParams = AlgorithmParameters.getInstance("IV", "LunaProvider");
      mAlgParams.init(new IvParameterSpec(ctr3DESBytes));

      myUnwrapper.init(Cipher.UNWRAP_MODE, hw3DESWrappingKey, mAlgParams);
      unwrapped3DESKey = (SecretKey) myUnwrapper.unwrap(wrapped3DESKey, "AES", Cipher.SECRET_KEY);

    } catch (Exception e) {
      System.out.println("Exception attempting to unwrap wrapped AES key");
      e.printStackTrace();
      System.exit(1);
    }

    // ********************************************
    // decrypt the encrypted value - AES
    // ********************************************
    try {
      Cipher myCipher = Cipher.getInstance("AES/CTR/NoPadding", "LunaProvider");
      byte[] ivBytes = { (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72,
          (byte) 73, (byte) 74, (byte) 75, (byte) 76, (byte) 77, (byte) 78, (byte) 79, (byte) 80 };
      AlgorithmParameters mAlgParams = AlgorithmParameters.getInstance("IV", "LunaProvider");
      mAlgParams.init(new IvParameterSpec(ivBytes));
      myCipher.init(Cipher.DECRYPT_MODE, unwrapped3DESKey, mAlgParams);
      byte[] aesdecrypted = myCipher.doFinal(aesencrypted);

      System.out.println("\n\n-----------------------");
      System.out.println("original: " + LunaUtils.getHexString(bytes, true));
      System.out.println("encrypted: " + LunaUtils.getHexString(aesencrypted, true));
      System.out.println("decrypted: " + LunaUtils.getHexString(aesdecrypted, true));
      System.out.println("\n\n-----------------------");

      if (java.util.Arrays.equals(bytes, aesdecrypted)) {
        System.out.println("Decryption was successful");
      } else
        System.out.println("*** decryption failed");
      System.out.println("-----------------------\n\n");

    } catch (Exception e) {
      System.out.println("Exception deciphering the AES-ciphered data");
      e.printStackTrace();
    }

  }

}
