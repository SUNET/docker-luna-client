
/*******************************************************************************
 *
 * This file is protected by laws protecting trade secrets and confidential
 * information, as well as copyright laws and international treaties.
 * Copyright (c) 2017 Gemalto NV, Inc. All rights reserved.
 *
 * This file contains confidential and proprietary information of
 * Gemalto NV, Inc. and its licensors and may not be
 * copied (in any manner), distributed (by any means) or transferred
 * without prior written consent from Gemalto NV, Inc.
 *
 *******************************************************************************/

import java.security.AlgorithmParameters;
import java.util.Arrays;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import com.safenetinc.luna.LunaSlotManager;

public class CipherAESKwDemo {

  // Configure these as required.
  private static final int slot = 0; // designated slot
  private static final String passwd = "userpin"; // password
  private static Cipher cipher;
  private static LunaSlotManager manager;

  private static KeyGenerator kg = null;
  private static SecretKey wrappingKey = null;
  private static SecretKey keyToBeWrap = null;
  private static SecretKey unwrappedAESKey = null;
  private static byte[] wrappedAESKey = null;

  private static byte[] aesEncrypted = null;
  private static byte[] aesDecrypted = null;

  private static byte[] plainText = null;
  private static char[] plainTextBuf = null;

  // Algorithm parameters
  private static AlgorithmParameters params = null;

  // IV
  private static byte[] iv = null;

  public static void main(String args[]) {

    System.out.println("This demo requires fw version 6.24.2 or higher.");

    manager = LunaSlotManager.getInstance();

    try {
      // log in to the designated slot
      manager.login(slot, passwd);
      cipher = Cipher.getInstance("AES/KW/NoPadding", "LunaProvider");
    } catch (Exception e) {
      System.out.println("Exception during login");
      System.exit(1);
    }

    // Create the HSM AES keys.
    generateAESKeys();

    // Encrypt big plaintext with random IV - AES
    encryptPlainText();

    // Wrap the AES key
    wrapAESKey();

    // unwrap the AES key
    unwrapAESKey();

    // Decrypt the encrypted value - AES
    decryptPlainText();

  }

  // ********************************************
  // Generate the HSM AES keys
  // ********************************************
  private static void generateAESKeys() {
    try {
      manager.setSecretKeysExtractable(true);

      kg = KeyGenerator.getInstance("AES", "LunaProvider");
      kg.init(128);
      wrappingKey = kg.generateKey();
      keyToBeWrap = wrappingKey;

    } catch (Exception e) {
      System.out.println("Exception generating keys");
      e.printStackTrace();
      System.exit(1);
    }
  }

  // ********************************************
  // Encrypt big plaintext.
  // ********************************************
  private static void encryptPlainText() {
    // Create 63K plaintext approx.
    plainTextBuf = new char[1024 * 63];
    // Fill bytes
    Arrays.fill(plainTextBuf, 'a');
    // Convert to bytes to be encrypted.
    plainText = new String(plainTextBuf).getBytes();

    // Generate random IV
    iv = new byte[8];
    (new Random()).nextBytes(iv);

    try {

      System.out.println("\n------------------------------------------------------------");
      System.out.println("\nLength of plain text to be encripted: " + plainTextBuf.length + " bytes");
      System.out.println("\nRandom IV: " + javax.xml.bind.DatatypeConverter.printHexBinary(iv));

      System.out.println("\nCiphering the plain text with HSM AES key");

      params = AlgorithmParameters.getInstance("IV", "LunaProvider");
      params.init(new IvParameterSpec(iv));

      cipher.init(Cipher.ENCRYPT_MODE, keyToBeWrap, params);

      // For multipart, use update() and final().
      cipher.update(plainText);
      aesEncrypted = cipher.doFinal();

    } catch (Exception e) {
      System.out.println("Exception ciphering the data with HSM AES key");
      e.printStackTrace();
      System.exit(1);
    }
  }

  // ********************************************
  // Wrap the AES key
  // ********************************************
  private static void wrapAESKey() {
    try {
      System.out.println("\nWrapping of HSM AES key");

      params = cipher.getParameters();
      cipher.init(Cipher.WRAP_MODE, wrappingKey, params);
      wrappedAESKey = cipher.wrap(keyToBeWrap);

    } catch (Exception ex) {
      System.out.println("Exception during wrapping of HSM AES key");
      ex.printStackTrace();
      System.exit(1);
    }
  }

  // ********************************************
  // Unwrap the AES key
  // ********************************************
  private static void unwrapAESKey() {
    try {
      System.out.println("\nUnwrap wrapped AES key");

      params = cipher.getParameters();
      cipher.init(Cipher.UNWRAP_MODE, wrappingKey, params);
      unwrappedAESKey = (SecretKey) cipher.unwrap(wrappedAESKey, "AES", Cipher.SECRET_KEY);

    } catch (Exception e) {
      System.out.println("Exception attempting to unwrap wrapped AES key");
      e.printStackTrace();
      System.exit(1);
    }
  }

  // ********************************************
  // Decrypt the encrypted value - AES
  // ********************************************
  private static void decryptPlainText() {
    try {

      System.out.println("\nDeciphering the AES-ciphered data");

      params = cipher.getParameters();
      cipher.init(Cipher.DECRYPT_MODE, unwrappedAESKey, params);

      aesDecrypted = cipher.doFinal(aesEncrypted);

      if (java.util.Arrays.equals(plainText, aesDecrypted)) {
        System.out.println("\nDecryption was successful");
      } else
        System.out.println("\n*** Decryption failed ***");
      System.out.println("\n------------------------------------------------------------\n");

    } catch (Exception e) {
      System.out.println("Exception deciphering the AES-ciphered data");
      e.printStackTrace();
    }
  }

}
