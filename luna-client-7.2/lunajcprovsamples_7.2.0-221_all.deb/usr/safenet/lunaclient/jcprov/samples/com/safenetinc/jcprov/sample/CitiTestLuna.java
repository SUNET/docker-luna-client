package com.safenetinc.jcprov.sample;

import com.safenetinc.jcprov.CK_ATTRIBUTE;
import com.safenetinc.jcprov.CK_BBOOL;
import com.safenetinc.jcprov.CK_C_INITIALIZE_ARGS;
import com.safenetinc.jcprov.CK_MECHANISM;
import com.safenetinc.jcprov.CK_OBJECT_HANDLE;
import com.safenetinc.jcprov.CK_SESSION_HANDLE;
import com.safenetinc.jcprov.Cryptoki;
import com.safenetinc.jcprov.CryptokiEx;
import com.safenetinc.jcprov.LongRef;
import com.safenetinc.jcprov.constants.CKA;
import com.safenetinc.jcprov.constants.CKF;
import com.safenetinc.jcprov.constants.CKK;
import com.safenetinc.jcprov.constants.CKM;
import com.safenetinc.jcprov.constants.CKO;
import com.safenetinc.jcprov.constants.CKU;

public class CitiTestLuna
{
    static public void println(String s) {
        System.out.println(s);
    }

    /** display runtime usage of the class */
    public static void usage() {
        println("java ...CitiTestLuna -slot <slotId> -password <password>\n");
        println("");

        System.exit(1);
    }

    private static long slotId = 0;
    private static String password = "";

    private static String LABEL = "DES2 key modifiable";
    private static String LABEL2 = "DES2 key copied";

    // JP
    public static CK_OBJECT_HANDLE findObject(CK_SESSION_HANDLE session, String label) {
        CK_ATTRIBUTE[] template = { new CK_ATTRIBUTE(CKA.LABEL, label.getBytes()) };
        CryptokiEx.C_FindObjectsInit(session, template, 1);
        LongRef objectCount = new LongRef();
        CK_OBJECT_HANDLE[] objects = {new CK_OBJECT_HANDLE()};
        CryptokiEx.C_FindObjects(session, objects, 1, objectCount);
        CryptokiEx.C_FindObjectsFinal(session);
        System.out.println(objects[0]);
        System.out.println("count: " + objectCount.value);
        if (objectCount.value > 0)
            return objects[0];
        else
            return null;
    }

    // JP
    public static CK_OBJECT_HANDLE generateKey(CK_SESSION_HANDLE session) {

        CK_OBJECT_HANDLE object = findObject(session ,LABEL);
        if (object != null) {
            CryptokiEx.C_DestroyObject(session, object);
        }

        CK_ATTRIBUTE[] template =
                {
                        new CK_ATTRIBUTE(CKA.CLASS,     CKO.SECRET_KEY),
                        new CK_ATTRIBUTE(CKA.KEY_TYPE, CKK.DES2),
                        new CK_ATTRIBUTE(CKA.TOKEN,     CK_BBOOL.TRUE),
                        new CK_ATTRIBUTE(CKA.SENSITIVE, CK_BBOOL.TRUE),
                        new CK_ATTRIBUTE(CKA.LABEL,     LABEL.getBytes()),
                        new CK_ATTRIBUTE(CKA.PRIVATE,   CK_BBOOL.TRUE),
                        new CK_ATTRIBUTE(CKA.ENCRYPT,   CK_BBOOL.TRUE),
                        new CK_ATTRIBUTE(CKA.DECRYPT,   CK_BBOOL.TRUE),
                        new CK_ATTRIBUTE(CKA.DERIVE,    CK_BBOOL.TRUE),
//                        new CK_ATTRIBUTE(CKA.MODIFIABLE,    CK_BBOOL.FALSE),
                        new CK_ATTRIBUTE(CKA.MODIFIABLE,    CK_BBOOL.TRUE),
                        new CK_ATTRIBUTE(CKA.VALUE_LEN, 16)
                };
        int templateLen = template.length;

        CK_MECHANISM mechanism = new CK_MECHANISM(CKM.DES2_KEY_GEN);

        CK_OBJECT_HANDLE key = new CK_OBJECT_HANDLE();
        CryptokiEx.C_GenerateKey(session, mechanism, template, templateLen, key);
        return key;
    }

    public static void main(String args[])
    {
        CK_SESSION_HANDLE session = new CK_SESSION_HANDLE();

        /*
         * process command line arguments
         */

        for (int i = 0; i < args.length; ++i)
        {

            if (args[i].equalsIgnoreCase("-slot"))
            {
                if (++i >= args.length)
                    usage();

                try
                {
                    slotId = Integer.parseInt(args[i]);
                }
                catch (Exception ex)
                {
                    println("Invalid slotid :" + args[i]);
                    println("");
                    usage();
                }
            }
            else if (args[i].equalsIgnoreCase("-password"))
            {
                if (++i >= args.length)
                    usage();

                password = args[i];
            }
            else
            {
                usage();
            }
        }

        try
        {
            System.out.println(" starting - CK_C_INITIALIZE_ARGS " );
            CryptokiEx.C_Initialize(new CK_C_INITIALIZE_ARGS(CKF.OS_LOCKING_OK));

            System.out.println(" starting - C_OpenSession " );
            CryptokiEx.C_OpenSession(slotId,CKF.SERIAL_SESSION|CKF.RW_SESSION,null,null,session);

            System.out.println(" starting - C_Login " );
            CryptokiEx.C_Login(session, CKU.USER, password.getBytes(), password.length());

            // JP
            generateKey(session);

            String objLabel = LABEL;
            byte[] label = objLabel.getBytes();
            LongRef objCount = new LongRef ();
            CK_OBJECT_HANDLE[] hKey = { new CK_OBJECT_HANDLE() };

            CK_ATTRIBUTE[] template = {
                    new CK_ATTRIBUTE(CKA.LABEL, label),
                    new CK_ATTRIBUTE(CKA.PRIVATE, new CK_BBOOL(true)) };

            CryptokiEx.C_FindObjectsInit(session, template, template.length);
            CryptokiEx.C_FindObjects(session, hKey, hKey.length, objCount);
            CryptokiEx.C_FindObjectsFinal(session);

            if (objCount.value == 1)
            {
                System.out.println(" Object count found ");
            }
            else
            {
                System.out.println(" Object NOT found ");
            }

            // Get a random sequence of bytes.
            int bufSize = 8;
            byte[] plainText = new byte[bufSize];
            java.util.Random r = new java.util.Random();
            r.nextBytes(plainText);

            com.safenetinc.jcprov.LongRef lRefEnc = new com.safenetinc.jcprov.LongRef();
            com.safenetinc.jcprov.CK_MECHANISM unwrapMechanism =
                    new com.safenetinc.jcprov.CK_MECHANISM(com.safenetinc.jcprov.constants.CKM.DES3_ECB);

            com.safenetinc.jcprov.CryptokiEx.C_EncryptInit(session, unwrapMechanism, hKey[0]);
            com.safenetinc.jcprov.CryptokiEx.C_Encrypt(session, plainText, plainText.length, null,lRefEnc);
            byte[] cipherText = new byte[(int)lRefEnc.value];
            com.safenetinc.jcprov.CryptokiEx.C_Encrypt(session, plainText, plainText.length, cipherText,lRefEnc);

            String output = hexEncode(cipherText);

            System.out.println("lunackm CopyIt() After C_Encrypt1 key check sum for label: "
                               + objLabel + "  : " + output.substring(0, 4));

            CK_ATTRIBUTE[] cptemplate =
            {
                new CK_ATTRIBUTE(CKA.TOKEN,  CK_BBOOL.FALSE),
                new CK_ATTRIBUTE(CKA.LABEL, LABEL2.getBytes()),
                new CK_ATTRIBUTE(CKA.ENCRYPT, CK_BBOOL.TRUE),
                new CK_ATTRIBUTE(CKA.UNWRAP, CK_BBOOL.TRUE),
            };

            com.safenetinc.jcprov.CK_OBJECT_HANDLE hcKey = new com.safenetinc.jcprov.CK_OBJECT_HANDLE();
            com.safenetinc.jcprov.CryptokiEx.C_CopyObject(session, hKey[0], cptemplate, cptemplate.length, hcKey);
            System.out.println(" Key copied successfully ");
        }
        catch (Throwable e)
        {
            e.printStackTrace();
            System.out.println("Exception occured: "+e.toString());
        }
        finally
        {
            /*
             * Logout in case we logged in.
             *
             * Note that we are not using CryptokiEx.* methods because they throw exceptions for errors and that
             * would complicate the finally handling required. The Cryptoki.* methods do not throw exceptions
             * when an error is encountered etc.
             */
            Cryptoki.C_Logout(session);

            /*
             * Close the session.
             *
             * Note that we are not using CryptokiEx.
             */
            Cryptoki.C_CloseSession(session);

            /*
             * All done with Cryptoki
             *
             * Note that we are not using CryptokiEx.
             */
            Cryptoki.C_Finalize(null);
        }
    }

    private static String hexEncode(byte[] input)
    {
        char[] ascii2hex = {
                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'A', 'B', 'C', 'D', 'E', 'F' };

        StringBuffer output = new StringBuffer(2 * input.length);

        for (int i = 0, length = input.length; i < length; i++)
        {
            int chr = input[i];
            output.append(ascii2hex[(chr >> 4) & 0xF]);
            output.append(ascii2hex[chr & 0xF]);
        }

        return output.toString();
    }
}
