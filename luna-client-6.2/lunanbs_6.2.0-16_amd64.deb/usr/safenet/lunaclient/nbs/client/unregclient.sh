hash=`openssl x509 -hash -fingerprint -noout -in $1 | grep -v Fingerprint*`
rm -f "$hash".0 
exit 0

