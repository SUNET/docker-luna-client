hash=`openssl x509 -hash -fingerprint -noout -in $1 | grep -v Fingerprint*`
if [ -e "$hash".0 ]; then 
  exit 0
fi
  
ln -sf $1 "$hash".0 
exit 0

