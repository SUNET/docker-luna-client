// ****************************************************************************
// Copyright (c) 2010 SafeNet, Inc. All rights reserved.
//
// All rights reserved.  This file contains information that is
// proprietary to SafeNet, Inc. and may not be distributed
// or copied without written consent from SafeNet, Inc.
// ****************************************************************************
package com.safenetinc.luna.sample;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.Key;
import java.security.KeyStore;
import java.util.Enumeration;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;


/*
 This example illustrates the LunaMP Keystore type.


 The LunaMP Keystore differs from the Luna Keystore in some important 
 aspects:

 - LunaMP keystores do not log in to the HSM even when a password
 is presented.  This means you must log in to the slot explicitly
 using the LunaSlotManager.

 -LunaMP keystores do not store information about which slot contains
 the actual cryptographic material described in the KeyStore. This
 means that the slot used to create the LunaMP keystore must be the
 active default slot in order to view the contents. 

 - Keys are not stored on the HSM partition (They are still PKCS #11
 session objects) until the KeyStore.store() method is invoked. (Even
 if the Keystore.SetKeyEntry or KeyStore.SetCertificateEntry methods
 are invoked.)

 - You can have multiple LunaMP KeyStores and their content list can be 
 kept independent of each other.

 - LunaMP KeyStores are not automatically filled with the contents of 
 the HSM as with the Luna KeyStore.  Keys and Certificates must be 
 added specifically into the LunaMP KeyStore(s) and as stated above 
 are not made permanent on the HSM until the store() method is invoked.

 - A special file is created when using KeyStore.store() with LunaMP
 Keystores that lists the objects that should appear in this keystore
 (which can be any subset of the objects on the HSM).

 - LunaMP KeyStores still have access to each object stored permanently 
 on an HSM, but unless an object has been previously saved to the 
 keystore (via the store() method), they will not appear in the 
 LunaMP Keystore when it is loaded. 

 - Keys will return null to the getCreationDate() method if the
 Keystore has not had the store() method invoked.

 More details about the LunaMP Keystore type can be found in the Luna 
 Development Guide.
 */

public class KeyStoreLunaMPDemo {
    public static void main(String[] args) {
        // Login to the HSM
        HSM_Manager.hsmLogin();

        KeyGenerator keyGen = null;
        SecretKey desKey = null;
        try {
            // Generate a DES key
            /*
             * The KeyGenerator explicitly specifies the Luna provider This is
             * not necessary if Luna is the default provider listed in the
             * java.security file.
             */
            System.out.println("Generating DES Key");
            keyGen = KeyGenerator.getInstance("DES", "LunaProvider");
            keyGen.init(56);
            desKey = keyGen.generateKey();
        } catch (Exception e) {
            System.out.println("Exception during DES Key Generation - "
                    + e.getMessage());
            System.exit(1);
        }

        SecretKey aesKey = null;
        try {
            // Generate an AES key
            System.out.println("Generating AES Key");
            keyGen = KeyGenerator.getInstance("AES", "LunaProvider");
            /*
             * AES Keys do not have a default keysize and must have a keysize
             * passed to the KeyGenerator.init() method.
             */
            keyGen.init(192);
            aesKey = keyGen.generateKey();
        } catch (Exception e) {
            System.out.println("Exception during AES Key Generation - "
                    + e.getMessage());
            System.exit(1);
        }

        KeyStore LunaMPks1 = null;
        KeyStore LunaMPks2 = null;
        try {
            // Open and load the LunaMP KeyStores
            /*
             * We open two LunaMP keystores. Both point to the same Luna HSM,
             * but may have different contents.
             */
            System.out.println("\nLoading LunaMP Keystores");
            LunaMPks1 = KeyStore.getInstance("LunaMP");
            LunaMPks2 = KeyStore.getInstance("LunaMP");
            /*
             * Invoking the load() method is required before performing any
             * actions with the Keystore or else an Exception will be thrown.
             * 
             * At this time, because we are creating brand new KeyStores, there
             * won't be any objects loaded in the Keystore. If this was an
             * existing Keystore, the load() method would read the list of the
             * objects in the store from the keystore file. An example of
             * loading an existing LunaMP keystore can be seen later on in this
             * file under the heading "Reload the save state of the keystore".
             */
            LunaMPks1.load(null, null);
            LunaMPks2.load(null, null);

            // Display information about the LunaMP Keystores
            System.out.println("LunaMP Keystores Information");
            System.out.println("LunaMP #1\t\t\t\tLunaMP #2");
            System.out.println("Provider - " + LunaMPks1.getProvider()
                    + "\tProvider - " + LunaMPks2.getProvider());
            System.out.println("Type     - " + LunaMPks1.getType()
                    + "\t\t\tType     - " + LunaMPks2.getType());
            System.out.println("Size     - " + LunaMPks1.size() + " objects"
                    + "\t\t\tSize     - " + LunaMPks2.size() + " objects");

        } catch (Exception e) {
            System.out.println("Exception accessing Keystore - "
                    + e.getMessage());
            System.exit(1);
        }

        /*
         * When using the LunaMP Keystore it is important to note that Keys and
         * Certificates are not made persistent with the setKeyEntry() method
         * like with the Luna Keystore. To make Keys and Certificates Persistent
         * with the LunaMP Keystore the store() method must be called.
         */
        try {
            // Saving DES key to Keystore #1
            System.out.println("\nSaving DES Key to Keystore #1");
            LunaMPks1.setKeyEntry("DES Demo Key", desKey, null,
                    (java.security.cert.Certificate[]) null);
            System.out.println("Keystore #1 now has " + LunaMPks1.size()
                    + " objects");
        } catch (Exception e) {
            System.out.println("Exception saving DES Key to Keystore #1 - "
                    + e.getMessage());
            System.exit(1);
        }

        try {
            // Saving AES key to Keystore #2
            System.out.println("\nSaving AES Key to Keystore #2");
            LunaMPks2.setKeyEntry("AES Demo Key", aesKey, null,
                    (java.security.cert.Certificate[]) null);
            System.out.println("Keystore #2 now has " + LunaMPks2.size()
                    + " objects");
        } catch (Exception e) {
            System.out.println("Exception saving AES Key to Keystore #2 - "
                    + e.getMessage());
            System.exit(1);
        }

        try {
            // Make Keys truly persistent in a LunaMP Keystore
            /*
             * Unlike the Luna Keystore Keys are not persistent until you call
             * the store() method. When this method is invoked a file is created
             * containing indexing information for the LunaMP Keystore.
             * 
             * Keys will return null to the getCreationDate() method if the
             * Keystore has not had the store() method invoked.
             */
            LunaMPks1.store(new FileOutputStream("LunaMP1"), null);
            LunaMPks2.store(new FileOutputStream("LunaMP2"), null);
        } catch (Exception e) {
            System.out.println("Exception storing Keystores - "
                    + e.getMessage());
            System.exit(1);
        }

        try {
            // Remove the key from the Keystore
            /*
             * Deleting the keys from the keystore with the deleteEntry() method
             * will not be made permanent until the store() method is called.
             */
            System.out.println("\nRemoving DES Key from Keystore #1");
            LunaMPks1.deleteEntry("DES Demo Key");
            System.out.println("Removing AES Key from Keystore #2");
            LunaMPks2.deleteEntry("AES Demo Key");
        } catch (Exception e) {
            System.out.println("Exception removing Key - " + e.getMessage());
            System.exit(1);
        }

        try {
            // Reload the save state of the KeyStore
            /*
             * This will reload the last stored state of the LunaMP Keystore.
             * Since store() was not called after the deleteEntry calls above,
             * the DES key will still be in the keystore.
             */
            LunaMPks1.load(new FileInputStream("LunaMP1"), null);
            System.out.println("Keystore #1 has " + LunaMPks1.size()
                    + " objects");
            // Search through the Keys stored in the Keystore and save the alias
            Enumeration<String> aliases = LunaMPks1.aliases();
            String Key = aliases.nextElement();
            System.out.println(Key + " was made persistant on "
                    + LunaMPks1.getCreationDate(Key));
        } catch (Exception e) {
            System.out.println("Exception loading Keystore - " + e.getMessage());
            System.exit(1);
        }

        try {
            // When a KeyStore is loaded you can then access the keys within the
            // KeyStore as follows
            Key newKey = LunaMPks1.getKey("DES Demo Key", null);
            System.out.println("newKey was created with "
                    + newKey.getAlgorithm());
        } catch (Exception e) {
            System.out.println("Exception while retrieving a key - "
                    + e.getMessage());
            System.exit(1);
        }

        // Logout of the token
        HSM_Manager.hsmLogout();
    }
}
