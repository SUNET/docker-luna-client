/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#include <stddef.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <fm/host/cryptoki.h>
#include <pinenc.h>

#include <fm/host/md.h>
#include <fm/host/mdStrings.h>
#include <fm/hsm/csa8fm.h>
#include <fm/common/fm_byteorder.h>

/** 
 * pinenc program host stub (encode/decode api)
 */

/*
 * Description:
 *    Create a RSA key pair and an AES key and store in private persistent storage.
 *
 * Parameters:
 *   hsmIndex :  which HSM
 *    zone    :  id of keyset to use
 *    slot_num:  slot number where the application has logged in a session open
 */
int PE_GenKeys(int hsmIndex, int zone, int slot_num)
{
    MD_Buffer_t     request[4], 
                    reply[1];

    uint32_t appState     = 0,
             originatorID = 0;
    uint8_t adapter       = (uint8_t)hsmIndex;
    uint32_t zone32, slotnum32;
    uint32_t recvLen;
    uint32_t cmd          = PE_CMD_GEN_KEYS;
    MD_RV rv              = MDR_UNSUCCESSFUL;

    /** 
     * Build our send buffer. 
     * 
     * The structure of the buffer will depend on the implementation 
     * of the FM. 
     */
    cmd = fm_htobe32(cmd);
    request[0].pData = (uint8_t *)&cmd;
    request[0].length = sizeof(cmd);

    zone32 = fm_htobe32((uint32_t)zone);
    request[1].pData = (uint8_t *)&zone32;
    request[1].length = sizeof(zone32); 

    slotnum32 = fm_htobe32((uint32_t)slot_num);
    request[2].pData = (uint8_t *)&slotnum32;
    request[2].length = sizeof(slotnum32); 

    /** The last MD_Buffer_t MUST be terminated in this fashion. - VERY IMPORTANT */
    request[3].pData = NULL;
    request[3].length = 0;
        
    /** Terminate our receive buffer as per earlier comment - VERY IMPORTANT */
    reply[0].pData = NULL;
    reply[0].length = 0;

    recvLen = 0; appState = 0;

    /** Send and receive our buffer via MD_SendReceive() */
    rv = MD_SendReceive( adapter, 
                         originatorID, 
                         (uint16_t)g_FMID,
                         request, 
                         0,
                         reply, 
                         &recvLen,          
                         &appState);

    
    /** 
     * MD_SendReceive() return MD_RV. If it is not zero then the FM did not see the message
     * or crashed etc. 
     *
     * If MD_Sendreceive is OK then appState holds whatever value was returned from FM
     * If MD_Sendreceive fails convert error to appropriate appState value.
     */

     if (rv != MDR_OK)
     { 
        printf("MD_SendReceive failed: %s\n", MD_RvAsString(rv));
        appState = CKR_GENERAL_ERROR;
     }
    
    return appState;
}

/*
 * Description:
 *    return encoded public key
 *
 * Parameters:
 *   zone    :  id of keyset to use
 *   bufLen: IN: points to buffer length OUT: bytes returned
 *   outBuf: OUT: where to store encoding 
 */
int PE_GetPubKey(int hsmIndex, int zone, int *bufLen, char *outbuf) 
{
    MD_Buffer_t     request[3], 
                    reply[2];

    uint32_t appState     = 0,
             originatorID = 0;
    uint8_t  adapter       = (uint8_t)hsmIndex;
    uint32_t zone32;
    uint32_t recvLen;
    uint32_t cmd          = PE_CMD_GET_PUBKEY;
    MD_RV rv              = MDR_UNSUCCESSFUL;

    /** 
     * Build our send buffer. 
     * 
     * The structure of the buffer will depend on the implementation 
     * of the FM. 
     */
    cmd = fm_htobe32(cmd);
    request[0].pData = (uint8_t *)&cmd;
    request[0].length = sizeof(cmd);

    zone32 = fm_htobe32((uint32_t)zone);
    request[1].pData = (uint8_t *)&zone32;
    request[1].length = sizeof(zone32); 

    /** The last MD_Buffer_t MUST be terminated in this fashion. - VERY IMPORTANT */
    request[2].pData = NULL;
    request[2].length = 0;
        
    reply[0].pData = (uint8_t *)outbuf;  // where to put output
    reply[0].length = *bufLen;         // length of outbuf

    /** Terminate our receive buffer as per earlier comment - VERY IMPORTANT */
    reply[1].pData = NULL;
    reply[1].length = 0;

    recvLen = 0; appState = 0;

    /** Send and receive our buffer via MD_SendReceive() */
    rv = MD_SendReceive( adapter, 
                         originatorID, 
                         (uint16_t)g_FMID,
                         request, 
                         0,
                         reply, 
                         &recvLen,          
                         &appState);

    
    /** 
     * MD_SendReceive() return MD_RV. If it is not zero then the FM did not see the message
     * or crashed etc. 
     *
     * If MD_Sendreceive is OK then appState holds whatever value was returned from FM
     * If MD_Sendreceive fails convert error to appropriate appState value.
     */

     if (rv != MDR_OK)
     { 
        printf("MD_SendReceive failed: %s\n", MD_RvAsString(rv));
        appState = CKR_GENERAL_ERROR;
     } else {
         *bufLen = recvLen;
     }
    
    return appState;
}



/*
 * Description:
 *    encode clear pin with RSA encryption
 *
 * Parameters:
 *   zone    :  id of keyset to use
 *   pinLen: IN: pin length
 *   pin:    IN: pin to encode 
 *   outLen: IN: points to buffer length OUT: bytes returned
 *   outBuf: OUT: where to store encoding 
 */
int PE_ClrPinEncrypt(int hsmIndex,
                     int zone, 
                     int pinLen, char *pin,
                     int *outLen, char *outbuf)
{
    MD_Buffer_t     request[5], 
                    reply[2];

    uint32_t appState     = 0,
             originatorID = 0;
    uint8_t adapter       = (uint8_t)hsmIndex;
    uint32_t zone32;
    uint32_t pinLen32;
    uint32_t recvLen;
    uint32_t cmd          = PE_CMD_CLR_PIN_ENC;
    MD_RV rv              = MDR_UNSUCCESSFUL;

    /** 
     * Build our send buffer. 
     * 
     * The structure of the buffer will depend on the implementation 
     * of the FM. 
     */
    cmd = fm_htobe32(cmd);
    request[0].pData = (uint8_t *)&cmd;
    request[0].length = sizeof(cmd);

    zone32 = fm_htobe32((uint32_t)zone);
    request[1].pData = (uint8_t *)&zone32;
    request[1].length = sizeof(zone32); 

    pinLen32 = fm_htobe32((uint32_t)pinLen);
    request[2].pData = (uint8_t *)&pinLen32;
    request[2].length = sizeof(pinLen32); 

    request[3].pData = (uint8_t *)pin;
    request[3].length = pinLen; 

    /** The last MD_Buffer_t MUST be terminated in this fashion. - VERY IMPORTANT */
    request[4].pData = NULL;
    request[4].length = 0;
        
    reply[0].pData = (uint8_t *)outbuf;  // where to put output
    reply[0].length = *outLen;         // length of outbuf

    /** Terminate our receive buffer as per earlier comment - VERY IMPORTANT */
    reply[1].pData = NULL;
    reply[1].length = 0;

    recvLen = 0; appState = 0;

    /** Send and receive our buffer via MD_SendReceive() */
    rv = MD_SendReceive( adapter, 
                         originatorID, 
                         (uint16_t)g_FMID,
                         request, 
                         0,
                         reply, 
                         &recvLen,          
                         &appState);

    
    /** 
     * MD_SendReceive() return MD_RV. If it is not zero then the FM did not see the message
     * or crashed etc. 
     *
     * If MD_Sendreceive is OK then appState holds whatever value was returned from FM
     * If MD_Sendreceive fails convert error to appropriate appState value.
     */

     if (rv != MDR_OK)
     { 
        printf("MD_SendReceive failed: %s\n", MD_RvAsString(rv));
        appState = CKR_GENERAL_ERROR;
     } else {
         *outLen = recvLen;
     }
    
    return appState;
}


/*
 * Description:
 *    translate pin from RSA to AES
 *
 * Parameters:
 *   hsmIndex IN: which HSM
 *   zone    IN:  id of keyset to use
 *   inLen:  IN: RSA encrypted pin length
 *   in:     IN: RSA encrypted pin 
 *   outLen: IN: points to buffer length OUT: bytes returned
 *   outBuf: OUT: where to store result 
 */
int PE_TranslatePin(int hsmIndex,
                    int zone, 
                    int inLen, char *in,
                    int *outLen, char *outbuf)
{
    MD_Buffer_t     request[5], 
                    reply[2];

    uint32_t appState     = 0,
             originatorID = 0;
    uint8_t  adapter       = (uint8_t)hsmIndex;
    uint32_t zone32;
    uint32_t recvLen;
    uint32_t inLen32;
    uint32_t cmd          = PE_CMD_TRANSLATE_PIN;
    MD_RV rv              = MDR_UNSUCCESSFUL;

    /** 
     * Build our send buffer. 
     * 
     * The structure of the buffer will depend on the implementation 
     * of the FM. 
     */
    cmd = fm_htobe32(cmd);
    request[0].pData = (uint8_t *)&cmd;
    request[0].length = sizeof(cmd);

    zone32 = fm_htobe32((uint32_t)zone);
    request[1].pData = (uint8_t *)&zone32;
    request[1].length = sizeof(zone32); 

    inLen32 = fm_htobe32((uint32_t)inLen);
    request[2].pData = (uint8_t *)&inLen32;
    request[2].length = sizeof(inLen32); 

    request[3].pData = (uint8_t *)in;
    request[3].length = inLen; 

    /** The last MD_Buffer_t MUST be terminated in this fashion. - VERY IMPORTANT */
    request[4].pData = NULL;
    request[4].length = 0;
 
    reply[0].pData = (uint8_t *)outbuf;  // where to put output
    reply[0].length = *outLen;         // length of outbuf

    /** Terminate our receive buffer as per earlier comment - VERY IMPORTANT */
    reply[1].pData = NULL;
    reply[1].length = 0;

    recvLen = 0; appState = 0;

    /** Send and receive our buffer via MD_SendReceive() */
    rv = MD_SendReceive( adapter, 
                         originatorID, 
                         (uint16_t)g_FMID,
                         request, 
                         0,
                         reply, 
                         &recvLen,          
                         &appState);

    
    /** 
     * MD_SendReceive() return MD_RV. If it is not zero then the FM did not see the message
     * or crashed etc. 
     *
     * If MD_Sendreceive is OK then appState holds whatever value was returned from FM
     * If MD_Sendreceive fails convert error to appropriate appState value.
     */

     if (rv != MDR_OK)
     { 
        printf("MD_SendReceive failed: %s\n", MD_RvAsString(rv));
        appState = CKR_GENERAL_ERROR;
     } else {
         *outLen = recvLen;
     }
    
    return appState;
}
