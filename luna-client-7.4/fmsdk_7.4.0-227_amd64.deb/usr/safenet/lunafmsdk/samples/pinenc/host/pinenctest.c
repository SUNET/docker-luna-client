/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

/** 
 * PINENC FM program host side test code
 */

#ifdef OS_WIN32
#include <windows.h>
#else
#ifdef OS_HPUX
  #include <dl.h>
#else
#include <dlfcn.h>
#endif
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fm/host/cryptoki.h"

#include "stdint.h"
#include <pinenc.h>
#include "input.h"

#include <fm/host/md.h>
#include <fm/host/mdStrings.h>
#include <fm/common/integers.h>

#define BUFF_SIZE                                        128
#define PED_ID_UNDEFINED                                 -1

int currentHSM = 0;

// ID value of FM is dynamically assigned so we pick it up at startup
uint32_t g_FMID;


void usage(void)
{
    fprintf(stderr, "Usage:  pinenctest [-z#] [-s<slot> -p<pin> gen] | [-d<hsm> test]\n");
    fprintf(stderr, "    -z#  = use key zone # - (default 1) e.g. -z123\n");
    fprintf(stderr, "    -s#  = use slot # for gen operation - (default 1) e.g. -s3\n");
    fprintf(stderr, "    -d#  = use device #  for pintrans - (default 0) e.g. -d2\n");
    fprintf(stderr, "    -p<pin> = use pin to login to slot to do key gen\n");
    fprintf(stderr, "    -e<ped> = remote ped Id to login to slot to do key gen\n");
    fprintf(stderr, "    gen  = perform key generate operation\n");
    fprintf(stderr, "    test = perform pin translate tests (default)\n");

    exit(1);
}

CK_RV doPinTest(int zone)
{
    CK_RV rv;
    char pubKeyBuf[8*1024/8*2];  // enough for a 8K pub key
    int pubLen;
    char clrPin[] = { '1', '2', '3', '4', '5' };
    char ciphTextRSA[8*1024/8];
    int outLenRSA;
    char ciphTextAES[8*256/8];
    int outLenAES;

    printf("\nApplication to test PINENC FM\n");
    printf("Perfoming Pin translation tests\n\n");

    // Initialize the Message Dispatch library */
    // This also initializes the Cryptoki library
    rv = MD_Initialize();
    if(rv != MDR_OK)
    {
        printf("Error: MD_Initialize failed with rv=0x%08x %s\n", (int)rv, MD_RvAsString(rv));
        exit(1);
    }

    printf("Connection to HSM(s) suceeded\n");

   rv = MD_GetFmIdFromName(currentHSM, FM_NAME, (uint32_t)strlen(FM_NAME), &g_FMID);
   if(rv != MDR_OK)
   {
       printf("FM '%s' not found on HSM %d\n", FM_NAME, currentHSM);
       exit(1);
   }
   printf("FM '%s' Found on HSM %d with ID 0x%x\n", FM_NAME, currentHSM, g_FMID);

    // read the public key in order to verify keys exist
    pubLen = sizeof(pubKeyBuf);
    rv = PE_GetPubKey(currentHSM, zone, &pubLen, pubKeyBuf);
    switch(rv)
    {
        case 0:
            printf("PE_GetPubKey from zone %d returned OK\n", zone);
            break;

        case CKR_KEY_NEEDED:
            printf("Public key not found - run pinenc_test gen\n\n");
            break;

        default:
            printf("Unexpected error (%x) fetching public key\n", (int)rv);
            printf("Check -d option and ensure PinEnc FM is Enabled\n");
            break;
    }
    if ( rv )
        return rv;

    outLenRSA = sizeof(ciphTextRSA);
    if(rv == 0) 
        rv = PE_ClrPinEncrypt(currentHSM, zone, 
                     sizeof(clrPin), clrPin,
                     &outLenRSA, ciphTextRSA);

    if(rv != MDR_OK) 
    {
        printf("PE_ClrPinEncrypt failed with error code: 0x%lx\n", rv);
        exit(1);
    }

    printf("Clear pin block encrypted OK with keys from Zone %2d\n", zone);

    outLenAES = sizeof(ciphTextAES);
    if(rv == 0) 
        rv = PE_TranslatePin(currentHSM, zone, 
                    outLenRSA, ciphTextRSA,
                    &outLenAES, ciphTextAES);

    if(rv != MDR_OK) 
    {
        printf("PE_TranslatePin failed with error code: 0x%lx\n", rv);
        exit(1);
    }
    printf("Encrypted pin block re-encrypted OK with keys from Zone %2d\n", zone);
    printf("\n");

    /** Finalize the library. */
    MD_Finalize();
 
    return rv;
}


int doPinGen(int zone, int slot, char *pin, int pedId)
{

    CK_RV rv = 0;
    CK_SESSION_HANDLE hSess;
    CK_CHAR  pinBuf[256];
    uint32_t hsmIndex;
    CK_ULONG isPedUsed = pedId != PED_ID_UNDEFINED ? 1 : 0;
    CK_ULONG uPedId = (CK_ULONG)pedId;
    CK_ULONG oldPedId = 0;

    printf("\nApplication to test PINENC FM\n");
    printf("Requesting a new Key set to be generated and stored in SMFS\n\n");

    /** Initialize the Cryptoki library 
     * This also initializs the Message dispatch library
     */
    rv = C_Initialize(NULL);
    if(rv != MDR_OK) 
    { 
        printf("C_Initialize %lx\n", rv);
        exit(1);
    }

    rv = C_OpenSession(slot, CKF_SERIAL_SESSION | CKF_RW_SESSION, NULL, NULL, &hSess);

    if(rv != MDR_OK) 
    {
        printf("C_OpenSession failed with error code: 0x%lx\n", rv);
        printf("Check -s option\n");
        exit(1);
    }

    if (isPedUsed) {
        if (pin != NULL && pin[0] != '\0') {
           printf("Error: PIN used for PED only authentication \n");
           rv = CKR_CANCEL;
        } else {
           printf("\nPlease attend to the PED\n");
           rv = CA_GetPedId(slot, &oldPedId);
           if (rv != CKR_OK)
              printf("\nError: Failed to get the existing PED id.\n");
           else {
              if (oldPedId != uPedId) {
                 rv = CA_SetPedId(slot, uPedId);
                 if (rv != CKR_OK)
                    printf("\nError: Failed to set the new PED id (%d).\n", (int)uPedId);
              }
              if (rv == CKR_OK) {
                 rv = C_Login(hSess, CKU_USER, NULL, 0);
                 if (oldPedId != uPedId) {
                     CK_RV rv1 = CA_SetPedId(slot, oldPedId);
                     if (rv1 != CKR_OK) {
                        printf("\nError: Failed to set the old PED id (%d).\n", (int)oldPedId);
                        rv = (rv == CKR_OK)? rv1 : rv;
                     }
                 }
              }
           }
        }
    } else {
        if ( !pin ) {
            printf("Please enter User Pin for slot %d: ", (int)slot);
            CON_GetSecret( (char*)pinBuf, sizeof(pinBuf));
            pin = (char*)pinBuf;
        }

        if ( strlen(pin) > 0 )
            rv = C_Login(hSess, CKU_USER, (CK_CHAR_PTR)pin, (CK_ULONG)strlen(pin));
        else {
            rv = CKR_CANCEL;
            printf("\nError: Failed to input a valid pin.\n");
        }
    }

    if(rv != MDR_OK) 
    {
        printf("C_Login failed with error code: 0x%lx\n", rv);
        exit(1);
    }

    rv = MD_Initialize();
    if(rv != MDR_OK) 
    { 
        printf("MD_Initialize %lx %s\n", rv, MD_RvAsString(rv));
        exit(1);
    }

    // we ignore any -d option from the command line and use the hsm index associated with this slot
    rv = MD_GetHsmIndexForSlot(slot, &hsmIndex);
    if(rv != MDR_OK)
    {
        printf("Slot '%d' not found in HSM %d - reboot HSM if slot is new\n", slot, (int)hsmIndex);
        exit(1);
    }

    rv = MD_GetFmIdFromName(hsmIndex, FM_NAME, (uint32_t)strlen(FM_NAME), &g_FMID);
    if(rv != MDR_OK)
    {
        printf("FM '%s' not found\n", FM_NAME);
        exit(1);
    }
    printf("FM '%s' Found with FM ID 0x%x on HSM %d\n", FM_NAME, g_FMID, hsmIndex);

    // convert Host slot number to HSM slot number
    CK_SLOT_ID slotEmb = 0;
    rv = MD_GetEmbeddedSlotID(slot, &slotEmb);
    if(rv != MDR_OK)
    {
        printf("Embedded slot not found for slot %d error %s\n", (int)slot, MD_RvAsString(rv));
        exit(1);
    }
    printf("Embedded slot %d found for slot %d\n", (int)slotEmb, (int)slot);

    // request FM to generate and store keys for this zone
    rv = PE_GenKeys(hsmIndex, zone, slotEmb);

    if(rv != MDR_OK) 
    {
        printf("PE_GenKeys failed with error code: 0x%lx\n", rv);
        printf("Check -d option and ensure FM is Enabled\n");
        exit(1);
    }

    MD_Finalize();

    /** Finalize the library. */
    rv = C_Finalize(NULL);
    if(rv != CKR_OK) 
    { 
        printf("C_Finalize %lx\n", rv);
        exit(1);
    }
 
    printf("Key Set number %02d generated and stored in Secure Memory on HSM\n\n", zone); 

    return rv;
}

#define GETARGVAL() \
    pVal = &pArg[2]; \
    if (*pVal == '\0') { \
        pVal = *(++argv); \
        if(--argc == 0 || pVal == NULL) \
           usage(); \
    }


int 
main(int argc, char **argv) 
{
    char * pArg;
    char * pVal;
    char * pin = NULL;

    int bGen = 0;
    int bTest = 0;
    int pedId = PED_ID_UNDEFINED;

    int slot = 1;
    int zone = 1;

    int bSlotSpecified = 0;
    int bDeviceSpecified = 0;

    MD_RV rv = MDR_OK;

    /* Parse parameters */
    ++argv;
    --argc;

    while(argc > 0)
    {
        pArg = *argv;
        if (pArg[0] == '-')
        {
            switch(pArg[1])
            {
               case 'z':
                    GETARGVAL();
                    zone = atoi(pVal);
                    break;
                case 'd':
                    GETARGVAL();
                    currentHSM = atoi(pVal);
                    bDeviceSpecified = 1;
                    break;
                case 's':
                    GETARGVAL();
                    slot = atoi(pVal);
                    bSlotSpecified = 1;
                    break;
                case 'p':
                    GETARGVAL();
                    pin = pVal;
                    break;
                case 'e':
                    GETARGVAL();
                    pedId = atoi(pVal);
                    break;

                default:
                   usage();
            }
        } else {
            if ( strcmp(pArg, "gen" ) == 0 ) {
                bGen = 1;
            } else if ( strcmp(pArg, "test" ) == 0 ) {
                bTest = 1;
            } else
                usage();
        }
        --argc;
        ++argv;
    }

    // if no command specified then just do test
    if ( bGen == 0 && bTest == 0 )
        bTest = 1;

    // check parameters
    if ( (bTest && bSlotSpecified) || (bGen && bDeviceSpecified) )
        usage();

    // do key gen operation if requested
    if ( bGen )
        rv = doPinGen(zone, slot, pin, pedId);
    if (rv != 0 )
        return rv;

    // do tests if requested
    if ( bTest )
        rv = doPinTest(zone);
    if (rv != 0 )
        return rv;

    exit(0);

}
