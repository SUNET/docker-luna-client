/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

/*
 *
 * Sample FM.
 * This FM implements a pin translation operation.
 *
 * The FM generates and stores the necessary keys
 * The FM can store up to 20 different keysets (called zones) at a time.
 *
 * Pins are translated from encryption under a RSA key to being encrypted under an AES key.
 * pins are encoded in an ISO format pin block.
 * During the translation the pinblock is changed from ISO format 2 to ISO format 1
 *
 * To help testing a function is provided to create an RSA encrypted pinblock
 *
 * It does this with several custom commands.
 *
 *    PE_GenKeys(int zone, int slotNum)
 *       Create a RSA key pair and an AES key and store in private persistant storage (SMFS).
 *
 *    PE_GetPubKey(int zone, int *bufLen, char *outbuf)
 *        Return encoded public key from secure storage
 *
 *    PE_ClrPinEncrypt( int zone,
 *                   int pinLen, char *pin,
 *                   int *outLen, char *outbuf)
 *         Encrypt clear pin with RSA encryption
 *
 *    PE_TranslatePin( int zone,
 *                   int inLen, char *in,
 *                   int *outLen, char *outbuf)
 *         Translate pin from RSA to AES
 *
 * The demonstrates the use of
 *    Secure Memory file system (SMFS)
 *    Embedded Cryptoki interface
 *    Crypto Engine services
 *    generating Clear RSA and AES keys
 *    A simple cache for SMFS contents
 *    Serialization routines for RSA and AES keys
 *
 * $Source: $
 * $Revision: $
 * $Date: $
 */

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <cryptoki.h>
#include <fmsmfs.h>
#include <fmcrypto.h>
#include <fmsupt.h>
#include <privilege.h>
#include <pinenc.h>
#include "local.h"

#ifndef NUMITEMS
#define NUMITEMS(x) (sizeof(x)/sizeof(x[0]))
#endif

#ifndef ROUNDUP4
#define _ROUNDUP_(val, alignment)      (((val) + ((alignment)-1)) & ~((alignment)-1))
#define ROUNDUP4(val)      _ROUNDUP_((val), 4)
#define ROUNDUP8(val)      _ROUNDUP_((val), 8)
#endif

// FM loads objects into seperate SmFs files.
// To allow for different key sets in 'zones' these files
// are in different subfolders using the id value converted to decimal string.
// e.g. path to pubkey file for zone 2 is "/pinenc/2/pubkey"

#define  APP_NAME "pinenc"

#define  PUB_KEY_NAME "pubkey"
#define  PUBTYPE  CKO_PUBLIC_KEY
#define  PRI_KEY_NAME "prikey"
#define  PRITYPE  CKO_PRIVATE_KEY
#define  SYM_KEY_NAME "symkey"
#define  SYMTYPE  CKO_SECRET_KEY


CK_RV encodeAESKey( char * keyBuf, int *piKeyBufLen,
                    char *val,      int len );


// calculate path to folder with key files in it
void buildPath(int zone, // id of key
               char *path, int len // where to store path
              )
{
    char zoneName[16];

    char *p = path;

    sprintf(zoneName, "%d", zone);

    assert(strlen(APP_NAME) + 2 + strlen(zoneName) < len);

    strcpy(p, "/");
    strcat(p, APP_NAME);
    strcat(p, "/");
    strcat(p, zoneName);
}

// convert Secure Memory file system erros to CK_RV types
int convSmToCk( int smerr )
{
    int ck;

    switch( smerr )
    {
    case  0:
        ck = 0; break;
    case SMFS_ERR_MEMORY: /**< The SMFS has run out of memory */
        ck = CKR_DEVICE_MEMORY; break;
    case SMFS_ERR_NAME_TOO_LONG: /**< The name given for a file is too long */
        ck = CKR_MECHANISM_PARAM_INVALID; break;
    case SMFS_ERR_RESOURCES: /**< The SMFS has run out of resources */
        ck = CKR_DEVICE_MEMORY; break;
    case SMFS_ERR_PARAMETER: /**< An invalid parameter was passed to SMFS */
        ck = CKR_MECHANISM_PARAM_INVALID; break;
    case SMFS_ERR_NOT_FOUND: /**< Requested file was not found */
        ck = CKR_KEY_NEEDED; break;
    case SMFS_ERR_EXIST: /**< A file being created already exists */
        ck = CKR_KEY_FUNCTION_NOT_PERMITTED; break;
    case SMFS_ERR_FILE_TYPE: /**< Operation being performed on wrong file type*/
        ck = CKR_MECHANISM_PARAM_INVALID; break;
    default:
        ck = CKR_DEVICE_ERROR; break;
    }
    return ck;
}

// Get SmFs file size
// fullname is fully qualified i.e. /pinenc/2/pubkey
// len: store length here
// Return : SmFs error : 0 if OK
//
int getSmFileSz(char *fullname, int *len)
{
    int rv = 0;
    struct SmFsAttr attr;

    // verify file exists and get its size
    rv = SmFsGetFileAttr( fullname, &attr );
    if ( rv == 0 )
        *len = attr.Size;

    return rv;
}

// Read a SmFs file contents
// fullname is fully qualified i.e. /pinenc/2/pubkey
// buflen: IN: len of output buf OUT: bytes read
// outbuf: store contents here
// Return : SmFs error: 0 if OK
//
int readSmFile(char *fullname, int *bufLen, char *outbuf)
{
    int SmRv = 0;
    SMFS_HANDLE fh;
    int len;

    // verify file exists and get its size
    SmRv = getSmFileSz(fullname, &len);
    if ( SmRv == 0 )
    {
        assert(len <= *bufLen);

        SmRv = SmFsOpenFile(&fh, fullname);
        if ( SmRv == 0 )
        {
            SmRv = SmFsReadFile(fh, 0, outbuf, len);
            *bufLen = len;
            SmFsCloseFile(fh);
        //    assert(SmRv == 0);
        }
        else {
        }
    }

    return convSmToCk(SmRv);
}

// build necessary folders to make up a path for a key id
// there is no error if the folders already exist
//
// RETURN: CK_RV
//
CK_RV createPath(int zone)
{
    int rv = 0;
    char fullname[128];

    rv = SmFsCreateDir("/" APP_NAME, MAX_ZONES);
    if (rv == SMFS_ERR_EXIST)
        rv = 0;

    if (rv == 0)
    {
        buildPath(zone, fullname, sizeof(fullname));

        rv = SmFsCreateDir(fullname, 3);
        if (rv == SMFS_ERR_EXIST)
            rv = 0;
    }

    return convSmToCk(rv);
}

// store a encoded key blob into a SmFs file
// zone:  index of key
// filename: SmFs file name
// data:   encoding
// datalen: length
//
// RETURN CK_RV
int storeKey( int zone, char * filename, char* data, int datalen)
{
    SMFS_HANDLE fh;
    int rv = 0;
    char fullname[128];
    char path[128];
    int len;

    // make the string for our key folder
    buildPath(zone, path, sizeof(path));

    // store public key, create file if required
    strcpy(fullname, path);
    strcat(fullname, "/");
    strcat(fullname, filename);

    // erase file if it is wrong size
    rv = getSmFileSz(fullname, &len);
    if (rv == 0)
    {
        if ( len != datalen )
        {
            SmFsDeleteFile(fullname);
            rv = SMFS_ERR_NOT_FOUND;
        }
    }

    // create the file if not found
    if (rv == SMFS_ERR_NOT_FOUND)
        rv = SmFsCreateFile(fullname, datalen);

    // store encoded key in file
    if ( rv == 0 )
        rv = SmFsOpenFile(&fh, fullname);
    if ( rv == 0 )
        rv = SmFsWriteFile(fh, 0, data, datalen);
    if ( rv == 0 )
        rv = SmFsCloseFile(fh);

    return convSmToCk( rv );
}

// Store an encoded public key in a SmFs file and an encoded public key
CK_RV storeRSAKeypair(int zone, int pubLen, char * pubBuf, int priLen, char * priBuf)
{
    CK_RV rv = CKR_OK;

    // ensure folders exist for this zone
    if ( rv == 0)
        rv = createPath(zone);

    if ( rv == 0)
        rv = storeKey( zone, PUB_KEY_NAME, pubBuf, pubLen);

    if ( rv == 0)
        rv = storeKey( zone, PRI_KEY_NAME, priBuf, priLen);

    return rv;
}

// Store an encoded AES key in a SmFs file
CK_RV storeSymKey(int zone, int aesLen, char * aesBuf)
{
    CK_RV rv = CKR_OK;
    char keyBuf[32];
    int  iKeyBufLen = sizeof(keyBuf);

    // ensure folders exist for this zone
    if ( rv == 0)
        rv = createPath(zone);

    if ( rv == 0)
        rv = encodeAESKey( keyBuf, &iKeyBufLen,
                           aesBuf,  aesLen );

    if ( rv == 0)
        rv = storeKey( zone, SYM_KEY_NAME, keyBuf, iKeyBufLen);

    return rv;
}


//////////////////////////////////
//
// simple Cache implementation
//
static struct keyList_s {
    int    key;
    char * buf;
    int    len;
} keyList[MAX_ZONES*3] = {{0}};

// look for a key in the cache
int getCacheEntry( int key, int *bufLen, char ** buf)
{
    int ctr;
    struct keyList_s  *pList;

    // look for the entry in the cache and return it if it is found
    for(ctr=0, pList=keyList; ctr<NUMITEMS(keyList); ++pList, ++ctr)
        if(pList->buf && pList->key == key)
        {
            *bufLen = pList->len;
            *buf    = pList->buf;
            return 0;
        }

    return CKR_DATA_INVALID;
}

int setCacheEntry( int key, int bufLen, char * buf)
{
    int ctr;
    struct keyList_s  *pList;

    // look for the entry in the cache and return error if found
    for(ctr=0, pList=keyList; ctr<NUMITEMS(keyList); ++pList, ++ctr)
        if(pList->buf && pList->key == key)
        {
            return CKR_DATA_INVALID;
        }

    // look for an empty entry in our list
    for(ctr=0, pList=keyList; ctr<NUMITEMS(keyList); ++pList, ++ctr)
        if (pList->buf == NULL)
            break;

    // if no empty entries then too many keys
    if ( ctr==NUMITEMS(keyList))
        return CKR_DEVICE_MEMORY;

    pList->buf  = buf;
    pList->len  = bufLen;
    pList->key  = key;

    return CKR_OK;
}

// combine key type and zone number to make a unique key id for the cache
#define MAKEID(type, zone) (type << 16 | zone)
#define MAKEIDPRI(zone) MAKEID(PRITYPE, zone)
#define MAKEIDPUB(zone) MAKEID(PUBTYPE, zone)
#define MAKEIDSYM(zone) MAKEID(SYMTYPE, zone)

#define KEYTOZONE(k) (k&0xffff)

// pull encode key from cache or from smfs file if cache is empty.
// We use cache method because SmFs is too slow
// filename:  smfs path where key is backed up
// cacheKey:  id of key
// bufLen:    OUT: len of data
// buf:       OUT: ptr to value
int getCachedKey( char * filename, int cacheKey, int *bufLen, char ** buf)
{
    int rv;
    int len;
    char * p = 0;
    char fullname[128];

    /// if key is in cache then we are done
    rv = getCacheEntry( cacheKey, bufLen, buf);
    if ( rv == 0 )
        return rv;

    // setup full path to key file
    buildPath(KEYTOZONE(cacheKey), fullname, sizeof(fullname)-10);  // get to path to SmFs folder for this zone
    strncat(fullname, "/", sizeof(fullname));
    strncat(fullname, filename, sizeof(fullname));

    // ensure SmFs file exists and get its size
    rv = getSmFileSz(fullname, &len);

    if ( rv == 0 )
    {
        p = malloc(len);

        if (p == NULL)
           rv = CKR_DEVICE_MEMORY;
    }

    if ( rv == 0 )
        rv = readSmFile(fullname, &len, p);

    if ( rv == 0 ) {
       rv = setCacheEntry(cacheKey, len, p);
       *bufLen = len;
       *buf    = p;
    } else
        if(p)
            free(p);

    return rv;
}

// pull encode private key from cache or from smfs file if cache is empty.
// use cache method because SmFs is too slow
// zone:  id of key
// bufLen: OUT: len of entry
// buf:    OUT: store cache entry addr here
int getCachedPriKey( int zone, int *bufLen, char ** buf)
{
    return getCachedKey( PRI_KEY_NAME, MAKEIDPRI(zone), bufLen, buf);
}

// pull encode public key from cache or from smfs file if cache is empty.
// use cache method because SmFs is too slow
// zone:  id of key
// bufLen: OUT: len of entry
// buf:    OUT: store cache entry addr here
int getCachedPubKey( int zone, int *bufLen, char ** buf)
{
    return getCachedKey( PUB_KEY_NAME, MAKEIDPUB(zone), bufLen, buf);
}

// pull encode public key from cache or from smfs file if cache is empty.
// use cache method because SmFs is too slow
// zone:  id of key
// bufLen: OUT: len of entry
// buf:    OUT: store cache entry addr here
int getCachedSymKey( int zone, int *bufLen, char ** buf)
{
    return getCachedKey( SYM_KEY_NAME, MAKEIDSYM(zone), bufLen, buf);
}

// Use Cryptoki engine to generate a RSA key pair
//
CK_RV generateRsaKeyPair(CK_SESSION_HANDLE hSession,
	CK_OBJECT_HANDLE * phPublicKey,
	CK_OBJECT_HANDLE * phPrivateKey)
{
	CK_MECHANISM mechanism = { 0, NULL, 0 };
	CK_ULONG bits = 2048;
	static const CK_BYTE label[] = {"tmp"};
	static const CK_BBOOL enc = FALSE;
	static const CK_BBOOL ver = FALSE;
	static const CK_BBOOL wrap = FALSE;
	static const CK_BBOOL sens = TRUE;
	static const CK_BBOOL extr = FALSE;
	CK_BBOOL isTok = FALSE;   // session key
	CK_BBOOL isPri = TRUE;    // owner must be logged in
	CK_CHAR pubExp[] = { 0x01, 0x00, 0x01 };

	CK_ATTRIBUTE pubTemplate[] = {
		{CKA_TOKEN, (void*)&isTok, 1},
		{CKA_PRIVATE, (void*)&isPri, 1},
		{CKA_LABEL, (void*)label, sizeof(label)-1},
		{CKA_MODULUS_BITS, (void*)&bits, sizeof(bits)},
		{CKA_ENCRYPT, (void*)&enc, 1},
		{CKA_VERIFY, (void*)&ver, 1},
//		{CKA_WRAP, (void*)&wrap, 1},
//		{CKA_EXTRACTABLE, (void*)&extr, 1},
		{CKA_PUBLIC_EXPONENT, pubExp, sizeof(pubExp)}
	};
	CK_ATTRIBUTE priTemplate[] = {
		{CKA_TOKEN, (void*)&isTok, 1},
		{CKA_PRIVATE, (void*)&isPri, 1},
		{CKA_LABEL, (void*)label, sizeof(label)-1},
		{CKA_SENSITIVE, (void*)&sens, 1},
		{CKA_DECRYPT, (void*)&enc, 1},
		{CKA_SIGN, (void*)&ver, 1},
		{CKA_UNWRAP, (void*)&wrap, 1},
		{CKA_EXTRACTABLE, (void*)&extr, 1}
	};
	CK_RV rv;

	/* Generate the key pair */
	mechanism.mechanism = CKM_RSA_X9_31_KEY_PAIR_GEN;
	rv = C_GenerateKeyPair(hSession, &mechanism,
		pubTemplate, NUMITEMS(pubTemplate),
		priTemplate, NUMITEMS(priTemplate),
		phPublicKey, phPrivateKey
	);

	return rv;
}

// Serialize some bytes into the output buffer and add padding as required.
// Format:  | component | padding to 4 byte boundary |
// Return: address of next free byte in outBuf or NULL if run out of space
//           *pulBufLen is decremented by number of bytes consumed
//
inline static char * EncodePadded(
                        char * pVal,     // IN: buffer to encode
                        int valLen,      // IN: length to encode
                        char * outBuf,   // OUT: where to store the encoding
                        int * pulBufLen  // IN/OUT: number of bytes left in buffer
                       )
{
   int len = ROUNDUP4(valLen);

   if ( outBuf == NULL || len > *pulBufLen )
       return NULL;

   memcpy( outBuf, pVal, len );
   *pulBufLen -= len;
   outBuf += len;

   return outBuf;
}

// Encode an Int component
// Formet:  | 32 bit len BE |
// Return: address of next free byte in keyBuf or NULL if run out of space
//
inline static char * EncodeIntegerVal (
                             uint32_t val,             // IN: int val to encode
                             char * outBuf,          // OUT: where to store the encoding
                             int * pulOutBufLen   // IN/OUT: number of bytes left in buffer
                            )
{
   uint32_t leVal = htobe32(val);

   return EncodePadded(
                        (void*)&leVal, // IN: buffer to encode
                        sizeof(leVal), // IN: length to encode
                        outBuf,        // OUT: where to store the encoding
                        pulOutBufLen   // IN/OUT: number of bytes left in buffer
                       );
}

// Encode a variable lenght component
// Formet:  | 32 bit len BE | value | padding |
// Return: address of next free byte in keyBuf or NULL if run out of space
//
inline static char * EncodeComponent (
                             char * data,       // IN: val to encode
                             int    len,        // IN: length of val
                             char * outBuf,     // OUT: where to store the encoding
                             int * piOutBufLen  // IN/OUT: number of bytes left in buffer
                            )
{
    outBuf = EncodeIntegerVal (
                             len,          // IN: int val to encode
                             outBuf,       // OUT: where to store the encoding
                             piOutBufLen); // IN/OUT: number of bytes left in buffer

   return EncodePadded(
                        (void*)data,  // IN: buffer to encode
                        len,          // IN: length to encode
                        outBuf,       // OUT: where to store the encoding
                        piOutBufLen   // IN/OUT: number of bytes left in buffer
                       );
}

// serialize rsa private key values for transmission or storage
// keyBuf     OUT: where to store the encoding
// ulKeyBufLen IN: sizeof keyBuf, OUT: number of bytes wrote to keyBuf
// Return CKR_KEY_SIZE_RANGE if keyBuf is too small else CKR_OK
//
CK_RV encodeRSAPrivate( char * keyBuf,  int *piKeyBufLen,
                        char *mod,      int mod_len,
                        char *pub,      int pub_len,
                        char *pri,      int pri_len,
                        char *p,        int p_len,
                        char *q,        int q_len,
                        char *dmp1,     int dmp1_len,
                        char *dmq1,     int dmq1_len,
                        char *iqmp,     int iqmp_len )
{
    char * pkeyBuf = keyBuf;

    pkeyBuf = EncodeIntegerVal(CKO_PRIVATE_KEY, pkeyBuf, piKeyBufLen);
    pkeyBuf = EncodeIntegerVal(CKK_RSA,         pkeyBuf, piKeyBufLen);

    if ( ( pkeyBuf = EncodeComponent(mod,  mod_len,  pkeyBuf, piKeyBufLen)) != NULL  &&
         ( pkeyBuf = EncodeComponent(pub,  pub_len,  pkeyBuf, piKeyBufLen)) != NULL  &&
         ( pkeyBuf = EncodeComponent(pri,  pri_len,  pkeyBuf, piKeyBufLen)) != NULL  &&
         ( pkeyBuf = EncodeComponent(p,    p_len,    pkeyBuf, piKeyBufLen)) != NULL  &&
         ( pkeyBuf = EncodeComponent(q,    q_len,    pkeyBuf, piKeyBufLen)) != NULL  &&
         ( pkeyBuf = EncodeComponent(dmp1, dmp1_len, pkeyBuf, piKeyBufLen)) != NULL  &&
         ( pkeyBuf = EncodeComponent(dmq1, dmq1_len, pkeyBuf, piKeyBufLen)) != NULL  &&
         ( pkeyBuf = EncodeComponent(iqmp, iqmp_len, pkeyBuf, piKeyBufLen)) != NULL  )
    {
        *piKeyBufLen = pkeyBuf - keyBuf;
    } else {
        return CKR_KEY_SIZE_RANGE;
    }

    return CKR_OK;
}

// serialize rsa private key values for transmission or storage
// keyBuf     OUT: where to store the encoding
// ulKeyBufLen IN: sizeof keyBuf, OUT: number of bytes wrote to keyBuf
// Return CKR_KEY_SIZE_RANGE if keyBuf is too small else CKR_OK
//
CK_RV encodeRSAPublic( char * keyBuf,  int *piKeyBufLen,
                        char *mod,      int mod_len,
                        char *pub,      int pub_len
                     )
{
    char * pkeyBuf = keyBuf;

    pkeyBuf = EncodeIntegerVal(CKO_PUBLIC_KEY, pkeyBuf, piKeyBufLen);
    pkeyBuf = EncodeIntegerVal(CKK_RSA,        pkeyBuf, piKeyBufLen);

    if ( ( pkeyBuf = EncodeComponent(mod,  mod_len,  pkeyBuf, piKeyBufLen)) != NULL  &&
         ( pkeyBuf = EncodeComponent(pub,  pub_len,  pkeyBuf, piKeyBufLen)) != NULL )
    {
        *piKeyBufLen = pkeyBuf - keyBuf;
    } else {
        return CKR_KEY_SIZE_RANGE;
    }

    return CKR_OK;
}

// serialize AES key value for transmission or storage
// keyBuf      OUT: where to store the encoding
// piKeyBufLen IN: sizeof keyBuf, OUT: number of bytes wrote to keyBuf
// val         IN  key
// len         IN len of key
// Return CKR_KEY_SIZE_RANGE if keyBuf is too small else CKR_OK
//
CK_RV encodeAESKey( char * keyBuf, int *piKeyBufLen,
                    char *val,      int len )
{
    char * pkeyBuf = keyBuf;

    pkeyBuf = EncodeIntegerVal(CKO_SECRET_KEY, pkeyBuf, piKeyBufLen);
    pkeyBuf = EncodeIntegerVal(CKK_AES,        pkeyBuf, piKeyBufLen);

    if ( ( pkeyBuf = EncodeComponent(val,  len,  pkeyBuf, piKeyBufLen)) != NULL )
    {
        *piKeyBufLen = pkeyBuf - keyBuf;
    } else {
        return CKR_KEY_SIZE_RANGE;
    }

    return CKR_OK;
}

// convert 32bit integer from encoding format to native format
// Return address following the encoding of NULL if pInBuf is null or we ran out of data to read
static char * DecodeIntegerVal(int * pVal,   // OUT: store int val here
                               char * pInBuf,   // IN: first byte of encoding (may be NULL)
                               int *pulInBufLen // IN/OUT: length left in encoding buffer
                              )
{
   if ( pInBuf && *pulInBufLen >= sizeof(uint32_t) ) {
       *pVal = htobe32(*(uint32_t*)pInBuf);
       *pulInBufLen -= sizeof(uint32_t);
       return pInBuf + sizeof(uint32_t);
   }
   return NULL;
}

// convert encoded buffer
// format is 32bit len followed by data plus 0-3 bytes padding to next 4 byte boundary
// Return address following the encoding of NULL if pInBuf is null or we ran out of data to read
static char * DecodeBuffer(int * pLen,      // OUT: set val and len members of this struct
                           char ** pVal,    // OUT: set val
                           char * pInBuf,   // IN: first byte of encoding (may be NULL)
                           int *pulInBufLen // IN/OUT: length left in encoding buffer
                           )
{
   int ulLen = 0;

   // get component length
   pInBuf = DecodeIntegerVal( &ulLen, pInBuf, pulInBufLen);
   *pLen  = ulLen;
   *pVal  = (char*)pInBuf;

   // ensure that the component is inside the encoding buffer
   if ( ulLen > *pulInBufLen )
      return NULL;

   // decrement the amount of memory left and return next read pointer
   *pulInBufLen -= ROUNDUP4(ulLen);

   return pInBuf + ROUNDUP4(ulLen);
}

// convert encoded key component
// format is 32bit len followed by data plus 0-3 bytes padding to next 4 byte boundary
// Return address following the encoding of NULL if pInBuf is null or we ran out of data to read
static char * DecodeComponent(
                     raw_key_component_t * pVal, // OUT: set val and len members of this struct
                     char * pInBuf,              // IN: first byte of encoding (may be NULL)
                     int *pulInBufLen            // IN/OUT: length left in encoding buffer
                             )
{
    int len;
    char *p;

    char * pNext = DecodeBuffer(&len,   // OUT: set val and len members of this struct
                            &p,         // OUT: set val
                            pInBuf,     // IN: first byte of encoding (may be NULL)
                            pulInBufLen // IN/OUT: length left in encoding buffer
                           );
    pVal->len = len;
    pVal->val = (unsigned char *)p;

    return pNext;
}

// take a buffer holding encoded keys that are supported by the Crypto engine
// and decode them into a FMCE_KEY structure.
// NOTE: pointers in FMCE keys struct point to bytes in the encoding buffer i.e. encoding is not copied.
// Return: LUNA erorr code
static CK_RV decodeKey(FMCE_KEY * pKey,  // OUT: setup this struct
                       char * pEncKey,   // IN:  first byte of encoding
                       int ulEncLen      // IN:  length of encoding
                           )
{
    int key_class, key_type;
    int ulKeyBufLen = ulEncLen;
    char * pkeyBuf = pEncKey;
    int val_bits = 0;


    pkeyBuf = DecodeIntegerVal(&key_class, pkeyBuf, &ulKeyBufLen);
    pkeyBuf = DecodeIntegerVal(&key_type, pkeyBuf, &ulKeyBufLen);

    if ( pkeyBuf ) {
        pKey->key_class = key_class;
        pKey->key_type = key_type;
    } else
        return CKR_DATA_INVALID;  // weird error for encoding bug only


    // use class and key type to determine encoding
    switch(key_class)
    {
        case CKO_SECRET_KEY:
            pkeyBuf = DecodeComponent(&pKey->sym.sym_key,  pkeyBuf, &ulKeyBufLen);
            break;

        case CKO_PRIVATE_KEY:
            switch(key_type)
            {
                case CKK_RSA:
                pkeyBuf = DecodeComponent(&pKey->rsa_pri.mod,  pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->rsa_pri.pub,  pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->rsa_pri.pri,  pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->rsa_pri.p,    pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->rsa_pri.q,    pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->rsa_pri.dmp1, pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->rsa_pri.dmq1, pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->rsa_pri.iqmp, pkeyBuf, &ulKeyBufLen);
                break;

                case CKK_DSA:
                case CKK_X9_42_DH:
                case CKK_KCDSA:
                pkeyBuf = DecodeComponent(&pKey->dsa_pri.p,       pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dsa_pri.q,       pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dsa_pri.g,       pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dsa_pri.pri_key, pkeyBuf, &ulKeyBufLen);
                break;

                case CKK_DH:
                pkeyBuf = DecodeComponent(&pKey->dh_pri.p,         pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dh_pri.g,         pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dh_pri.pri_key,   pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeIntegerVal(&val_bits, pkeyBuf, &ulKeyBufLen);
                pKey->dh_pri.val_bits = val_bits;
                break;

                case CKK_ECDSA:
                pkeyBuf = DecodeComponent(&pKey->ec_pri.ec_param,  pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->ec_pri.pub_key,   pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->ec_pri.pri_key,   pkeyBuf, &ulKeyBufLen);
                break;

                default:
                   return CKR_KEY_TYPE_INCONSISTENT;
            }
            break;

        case CKO_PUBLIC_KEY:
            switch(key_type)
            {
                case CKK_RSA:
                pkeyBuf = DecodeComponent(&pKey->rsa_pub.mod,  pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->rsa_pub.pub,  pkeyBuf, &ulKeyBufLen);
                break;

                case CKK_DSA:
                case CKK_X9_42_DH:
                case CKK_KCDSA:;
                pkeyBuf = DecodeComponent(&pKey->dsa_pub.p,       pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dsa_pub.q,       pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dsa_pub.g,       pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dsa_pub.pub_key, pkeyBuf, &ulKeyBufLen);
                break;

                case CKK_DH:
                pkeyBuf = DecodeComponent(&pKey->dh_pub.p,         pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dh_pub.g,         pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->dh_pub.pub_key,   pkeyBuf, &ulKeyBufLen);
                break;

                case CKK_ECDSA:
                pkeyBuf = DecodeComponent(&pKey->ec_pri.ec_param,  pkeyBuf, &ulKeyBufLen);
                pkeyBuf = DecodeComponent(&pKey->ec_pri.pub_key,   pkeyBuf, &ulKeyBufLen);
                break;

                default:
                   return CKR_KEY_TYPE_INCONSISTENT;
            }
            break;

        default:
            return CKR_KEY_TYPE_INCONSISTENT;
    }
    if ( pkeyBuf == NULL ) {
        return CKR_DATA_INVALID;  // weird error for encoding bug only
    }

    return CKR_OK;
}
//
// read sensitive attributes from a rsa private key object and save them in seperate
// serialized buffers.
//
// hSession:  cryptoki session
// hPri:      object handle of rsa private key
// pubLen:    IN sizeof pubBuf,  OUT bytes written to pubBuf
// pubBuf:    OUT where to write serialized public key
// priLen:    IN sizeof priBuf,  OUT bytes written to priBuf
// priBuf:    OUT where to write serialized private key
//
CK_RV extractRSAKeypair(CK_SESSION_HANDLE hSession, CK_OBJECT_HANDLE hPri,
                        int *pubLen, char *pubBuf,
                        int *priLen, char *priBuf)
{
    CK_RV rv = CKR_OK;

    char mod [FMCE_MAX_RSA_BITS/8];
    char pub [FMCE_MAX_RSA_BITS/8];
    char pri [FMCE_MAX_RSA_BITS/8];
    char p   [FMCE_MAX_RSA_BITS/8/2];
    char q   [FMCE_MAX_RSA_BITS/8/2];
    char dmp1[FMCE_MAX_RSA_BITS/8/2];
    char dmq1[FMCE_MAX_RSA_BITS/8/2];
    char iqmp[FMCE_MAX_RSA_BITS/8/2];

    // NOTE - must preserve order of these attributes
    CK_ATTRIBUTE priTemplate[] = {
        {CKA_MODULUS,          (void*)mod,  sizeof(mod) },
        {CKA_PUBLIC_EXPONENT,  (void*)pub,  sizeof(pub) },
        {CKA_PRIVATE_EXPONENT, (void*)pri,  sizeof(pri) },
        {CKA_PRIME_1,          (void*)p,    sizeof(p)   },
        {CKA_PRIME_2,          (void*)q,    sizeof(q)   },
        {CKA_EXPONENT_1,       (void*)dmp1, sizeof(dmp1)},
        {CKA_EXPONENT_2,       (void*)dmq1, sizeof(dmq1)},
        {CKA_COEFFICIENT,      (void*)iqmp, sizeof(iqmp)}
    };

    CT_SetPrivilegeLevel(PRIVILEGE_OVERRIDE);

    rv = C_GetAttributeValue(hSession, hPri, priTemplate, NUMITEMS(priTemplate));

    CT_SetPrivilegeLevel(PRIVILEGE_NORMAL);

    if ( rv == CKR_OK )
        rv = encodeRSAPrivate( priBuf,  priLen,
                        mod,    priTemplate[0].ulValueLen,
                        pub,    priTemplate[1].ulValueLen,
                        pri,    priTemplate[2].ulValueLen,
                        p,      priTemplate[3].ulValueLen,
                        q,      priTemplate[4].ulValueLen,
                        dmp1,   priTemplate[5].ulValueLen,
                        dmq1,   priTemplate[6].ulValueLen,
                        iqmp,   priTemplate[7].ulValueLen
                        );

    if ( rv == CKR_OK )
        rv = encodeRSAPublic( pubBuf,  pubLen,
                        mod,    priTemplate[0].ulValueLen,
                        pub,    priTemplate[1].ulValueLen
                     );

   return rv;
}

CK_RV print_slot_list()
{
    // slots
    typedef struct
    {
       CK_SLOT_ID     slotID;
       CK_SLOT_INFO   slotInfo;
    }SlotList;

    SlotList *pSlotList = 0;
    unsigned int slotCount;

    CK_ULONG       usCount;
    CK_ULONG       usCheckCount;
    CK_ULONG       usLoop;
    CK_SLOT_ID     *slotList = 0;
    CK_RV          usStatus;

    usStatus = C_GetSlotList(FALSE, NULL, &usCount);
    slotCount = usCount;
    if( usStatus == CKR_OK )
    {
       slotList = (CK_SLOT_ID*)malloc(sizeof(CK_SLOT_ID)*usCount + 1);
       pSlotList = (SlotList*)malloc(sizeof(SlotList)*usCount + 1);
       if ( (slotList == NULL) || (pSlotList == NULL) )
       {
          usStatus = CKR_GENERAL_ERROR;
          return usStatus;
       }
    }

    // store the initial value
    usCheckCount = usCount;

    // Get slot list
    if( usStatus == CKR_OK )
    {
       usStatus = C_GetSlotList(FALSE, slotList, &usCount);
    }

    // Verify that new count does not exceed number of slots detected earlier ( mem allocated for that many slots )
    if( usStatus == CKR_OK )
    {
       if( usCheckCount < usCount )
       {
          printf("\nSecond call to C_GetSlotList returns a number of present slots (%d"
               ") larger than previously detected (%d)\n" ,(int)usCheckCount ,(int)usCount );
          return usStatus;
       }
    }

    // Get info for each slot
    slotCount = 0;
    for(usLoop=0; usLoop<usCheckCount && usStatus==CKR_OK; ++usLoop)
    {
       usStatus = C_GetSlotInfo(slotList[usLoop], &(pSlotList[usLoop].slotInfo));
       if( usStatus == CKR_OK )
       {
          pSlotList[slotCount].slotID = slotList[slotCount];
          slotCount++;
       }
    }

    printf("Slots available:%d\n",slotCount);
    for(usLoop=0; usLoop<slotCount; ++usLoop)
    {
        pSlotList[usLoop].slotInfo.slotDescription[sizeof(pSlotList[usLoop].slotInfo.slotDescription)-1]='\0';
        printf("%d slotID %d - %s\n",(int)usLoop,
                (int)pSlotList[usLoop].slotID,
                pSlotList[usLoop].slotInfo.slotDescription );
    }
    return(CKR_OK);
}

/*
 * Description:
 *    Create a RSA key pair and an AES key and store in private persistant storage.
 *
 * Parameters:
 *   zone    :  id of keyset to use
 *    slotNum:  slot where the application has a logged on session
 */
int FM_PE_GenKeys(int zone, int slotNum)
{
    CK_RV rv = CKR_OK;
    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hPri = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hPub = CK_INVALID_HANDLE;
    char priBuf[8*1024];
    int priLen;
    char pubBuf[4*1024];
    int pubLen;
    char aesBuf[16];

    rv = C_OpenSession(slotNum, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSession);

    if (rv == CKR_OK)
        rv = generateRsaKeyPair(hSession, &hPub, &hPri);

    if (rv == CKR_OK)
    {
        priLen = sizeof(priBuf);
        pubLen = sizeof(pubBuf);
        rv = extractRSAKeypair(hSession, hPri, &pubLen, pubBuf, &priLen, priBuf);
    }

    if (rv == CKR_OK)
        rv = C_DestroyObject(hSession, hPub);

    if (rv == CKR_OK)
        rv = storeRSAKeypair(zone, pubLen, pubBuf, priLen, priBuf);

    if ( hSession != CK_INVALID_HANDLE )
        C_CloseSession(hSession);

    if (rv == CKR_OK) {
        // Please note that FM_GetNDRandom returns the number of bytes instead of the error code
        if (FM_GetNDRandom(aesBuf, sizeof(aesBuf)) != sizeof(aesBuf) )
           rv = CKR_FUNCTION_FAILED;
    }

    if (rv == CKR_OK)
        rv = storeSymKey(zone, sizeof(aesBuf), aesBuf);

    // create audit log entry to mark the keys being generated
    {
        char msg[FM_MAX_AUDIT_LEN];

        msg[FM_MAX_AUDIT_LEN-1] = '\0';
        snprintf(msg, sizeof(msg)-1, "Keys Generated for Zone %d - result code 0x%x", (int)zone, (int)rv);

        FM_AddToExtLog(msg);
    }

    return rv;
}

/*
 * Description:
 *    return encoded public key from secure storage
 *
 * Parameters:
 *   zone    :  id of keyset to use
 *   bufLen: IN: points to buffer length OUT: bytes returned
 *   outBuf: OUT: where to store encoding
 */
int FM_PE_GetPubKey(int zone, int *bufLen, char *outbuf)
{
    char name[128];

    // setup full path to pubkey file
    buildPath(zone, name, sizeof(name)-10);  // get to path to SmFs folder for this zone
    strncat(name, "/", sizeof(name));
    strncat(name, PUB_KEY_NAME, sizeof(name));

    return readSmFile(name, bufLen, outbuf);
}

/*
 * ISO4 format pin block (8 bytes - 32 nibbles)
 * |1|L|P|P|P|P|P|R|R|R|R|R|R|R|R|R|R|R|P|P|P|P|P|R|R|R|R|R|R|R|R|R
 *
 * ISO2 format pin block (8 bytes - 16 nibbles)
 * |2|L|P|P|P|P|P|F|F|F|F|F|F|F|F|F|
 *
 * L = length of pin (5 in this example)
 * P = pin character value
 * F = fill = 0xf
 * R = random nibble value
 */

char GetNibble(char *p, int idx)
{
    if (idx&1)
        return (char)(p[idx/2] & 0x0f);
    else
        return (char)((p[idx/2] & 0xf0) >> 4);
}

void PutNibble(char *p, int idx, char val)
{
    if (idx&1)
        p[idx/2] = (p[idx/2] & 0xf0) | (val & 0xf);
    else
        p[idx/2] = (p[idx/2] & 0x0f) | (val << 4);
}

/*
 * Description:
 *    encode clear pin with RSA encryption
 *
 * Parameters:
 *   zone    :  id of keyset to use
 *   pinLen: IN: pin length
 *   pin:    IN: pin to encode - ASCII chars
 *   outLen: IN: points to buffer length OUT: bytes returned
 *   outBuf: OUT: where to store encoding
 */
int FM_PE_ClrPinEncrypt( int zone,
                    int pinLen, char *pin,
                    int *outLen, char *outbuf)
{
    int len;
    int rv = CKR_OK;
    int encodedkeyLen;
    char * encodedkey;
    FMCE_KEY fmkey;
    CK_ULONG    ulOutLen = *outLen;
    CK_RSA_PKCS_OAEP_PARAMS oaep = { CKM_SHA256, CKG_MGF1_SHA256, CKZ_DATA_SPECIFIED, NULL, 0 };
    CK_MECHANISM mech = {CKM_RSA_PKCS_OAEP, &oaep, sizeof(oaep) };
    char ISO2Blk[8];

    // ensure pin length is in range
    if (pinLen > 12 || pinLen < 4)
        return CKR_DATA_LEN_RANGE;

    // encode pin into a ISO 2 format pin block
    PutNibble(ISO2Blk, 0, 2);
    PutNibble(ISO2Blk, 1, pinLen);

    memset(ISO2Blk+1, 0xff, sizeof(ISO2Blk)-1);
    for(len=0; len<pinLen; ++len)
        PutNibble(ISO2Blk, len+2, (char)(pin[len] & 0xf));

    // obtain pointer to a encoded i.e. serialized pub key
    // use cache method because SmFs is too slow
    rv = getCachedPubKey( zone, &encodedkeyLen, &encodedkey );
    if ( rv != 0 )
        return rv;

    // set a fmkey object as a rsa public using values in encoded key
    rv = decodeKey(&fmkey,  // OUT: setup this struct
                   encodedkey,   // IN:  first byte of encoding
                   encodedkeyLen   // IN:  length of encoding
                  );

    // perform encryption
    if ( rv == 0 )
        rv = FMCE_Encrypt(
               &mech,  // mechanism type and parameters
               &fmkey,   // key value

               sizeof(ISO2Blk),
               (CK_BYTE_PTR)ISO2Blk,
               &ulOutLen,
               (CK_BYTE_PTR)outbuf);

    *outLen = 0;
    if ( rv == 0 )
        *outLen = (int)ulOutLen;

    return rv;
}

/*
 * Description:
 *    translate pin from RSA to AES
 *
 * Parameters:
 *   zone    :  id of keyset to use
 *   inLen:  IN: RSA encrypted pin length
 *   in:     IN: RSA encrypted pin block type ISO2
 *   outLen: IN: points to buffer length OUT: bytes returned
 *   outBuf: OUT: where to store result  (encrypted pin block ISO4)
 *
 *   RETURN: CK_RV type
 */
int FM_PE_TranslatePin( int zone,
                    int inLen, char *in,
                    int *outLen, char *outbuf)
{
    CK_RV rv = CKR_OK;
    int encodedkeyLen;
    char * encodedkey;
    FMCE_KEY fmkey;
    CK_ULONG    ulOutLen;
    CK_RSA_PKCS_OAEP_PARAMS oaep = { CKM_SHA256, CKG_MGF1_SHA256, CKZ_DATA_SPECIFIED, NULL, 0 };
    CK_MECHANISM mechDec = {CKM_RSA_PKCS_OAEP, &oaep, sizeof(oaep) };
    CK_MECHANISM mechEnc = {CKM_AES_ECB, NULL, 0 };
    char ISO4Blk[16];
    char ISO2Blk[8];
    char fill[16];
    int pinLen, fillLen, fillOff; // these all count nibbles

    // obtain pointer to a encoded i.e. serialized pri key
    // use cache method because SmFs is too slow
    rv = getCachedPriKey( zone, &encodedkeyLen, &encodedkey );
    if ( rv != 0 )
        return convSmToCk(rv);

    // set a fmkey object as a rsa private with values in encoded key
    rv = decodeKey(&fmkey,  // OUT: setup this struct
                   encodedkey,   // IN:  first byte of encoding
                   encodedkeyLen   // IN:  length of encoding
                  );

    // perform decryption
    if ( rv == 0 ) {
        ulOutLen = sizeof(ISO2Blk);
        rv = FMCE_Decrypt(
               &mechDec,  // mechanism type and parameters
               &fmkey,   // key value

               inLen,  // len of cipher text
               (CK_BYTE_PTR)in,     // cipher text
               &ulOutLen, // outbuflen/outsize
               (CK_BYTE_PTR)ISO2Blk);  // outpub buf
        if (rv != 0) // FMCE_Decrypt fails
           return rv;
    } else // decode failed and abort the operation
      return rv;

    // ensure format and pin length is in range
    if (GetNibble(ISO2Blk, 0) != 2)
        return CKR_DATA_INVALID;

    pinLen = GetNibble(ISO2Blk, 1);

    if (pinLen > 12 || pinLen < 4)
        return CKR_DATA_LEN_RANGE;

    fillOff = 2 + pinLen;  // offset of padding (in nibbles)
    fillLen = sizeof(ISO4Blk)*2 - fillOff;

    // convert pin from a ISO 2 format pin block to ISO 4
    // Get sufficient random nibbles to add padding
    if (FM_GetNDRandom(fill, (fillLen+1)/2) != ((fillLen+1)/2) )
       rv = CKR_FUNCTION_FAILED;

    if ( rv == 0 ) {
        int idx;
        memcpy(ISO4Blk, ISO2Blk, sizeof(ISO2Blk));
        PutNibble(ISO4Blk, 0, 0x04);  // set format nibble

        // do random fill of nibbles following pin
        for(idx=fillOff; idx<sizeof(ISO4Blk)*2; ++idx)
        {
            PutNibble(ISO4Blk, idx, GetNibble(fill, idx-fillOff));
        }
    } else // Failed to get sufficient randome nibble to add padding and abort the operation
      return rv;

    // obtain pointer to a encoded i.e. serialized sym key
    // use cache method because SmFs is too slow
    rv = getCachedSymKey( zone, &encodedkeyLen, &encodedkey );
    if ( rv != 0 )
        return rv;

    // set a fmkey object as a rsa public using values in encoded key
    rv = decodeKey(&fmkey,  // OUT: setup this struct
                   encodedkey,   // IN:  first byte of encoding
                   encodedkeyLen   // IN:  length of encoding
                  );

    // perform encryption with AES mode
    ulOutLen = *outLen;
    if ( rv == 0 )
        rv = FMCE_Encrypt(
               &mechEnc,  // mechanism type and parameters
               &fmkey,   // key value

               sizeof(ISO4Blk),
               (CK_BYTE_PTR)ISO4Blk,
               &ulOutLen,
               (CK_BYTE_PTR)outbuf);

    *outLen = 0;
    if ( rv == 0 )
        *outLen = (int)ulOutLen;

    return rv;
}

