/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

// local function declarations
//
int FM_PE_GenKeys(int zone, int slotNum);
int FM_PE_GetPubKey(int zone, int *bufLen, char *outbuf);
int FM_PE_ClrPinEncrypt( int zone,
                         int pinLen, char *pin,
                         int *outLen, char *outbuf);
int FM_PE_TranslatePin( int zone,
                        int inLen, char *in,
                        int *outLen, char *outbuf);

