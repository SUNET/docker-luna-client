/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#include <pinenc.h>
#include <fm/hsm/mkfmhdr.h>

#define FM_VERSION 0x0301 /* V3.01 */
#define FM_SER_NO  0
#define FM_MANUFACTURER "Gemalto Inc"

DEFINE_FM_HEADER(FMID_ALLOCATE_NORM,
		FM_VERSION,
		FM_SER_NO,
		FM_MANUFACTURER,
		FM_NAME);

