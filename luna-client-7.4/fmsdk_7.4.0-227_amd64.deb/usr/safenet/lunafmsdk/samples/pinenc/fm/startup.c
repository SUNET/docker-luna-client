/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.

PIN_ENC FM: Demonstrates the creation of a custom API using FMs

*/


#include <stdlib.h>
#include <stdio.h>       //printf()
#include <string.h>

#include <cryptoki.h>

#include "fm/hsm/fmsw.h"
#include "fm/hsm/fm_io_service.h"
#include "fm/hsm/fm.h"

#include "pinenc.h"
#include "fmcrypto.h"
#include <endian.h>
#include "local.h"

// Comment out one of the two following lines
//#define trace(x)
#define trace(x) x

/* command handler entry point */
static
int PinEncFM_HandleMessage(
                            FmMsgHandle token
                          )
{
    uint32_t cmd, inLen, slot_num, zone;
    int outLen;
    int rv;
    void * pinBuf;
    void * pResp;

    trace(printf("entr: PinEncFM_HandleMessage\n");)

    /* read in Cmd code */
    if (SVC_IO_Read32(token, &cmd) != sizeof(cmd))
    {
        /* Ensure the request is long enough to contain at least the cmd */
        return (uint32) CKR_FUNCTION_NOT_SUPPORTED;
    }

    trace(printf("cmd %d\n",cmd);)

    /* command switch */
    switch(cmd) {

    case PE_CMD_GEN_KEYS:

        // Generate a set of working keys and store them internally
        // Input: | zone | slot_num |
        // Output : none
        //
        // Get slot number

        if (SVC_IO_Read32(token, &zone) != sizeof(zone) ||
            SVC_IO_Read32(token, &slot_num) != sizeof(slot_num))
        {
            rv = (int) CKR_ARGUMENTS_BAD;
            break;
        }

        rv = FM_PE_GenKeys( (int)zone, (int)slot_num);

        break;

    case PE_CMD_GET_PUBKEY:

        // encode and return public key
        // Input: | zone |
        // Output: | encoded key |
        //
        if (SVC_IO_Read32(token, &zone) != sizeof(zone))
        {
            rv = (int) CKR_ARGUMENTS_BAD;
            break;
        }

        // get address and length of the output buffer
        outLen = SVC_IO_GetWriteBuffer( token, (void**)&pResp );

        // get key and put in response buffer
        rv = FM_PE_GetPubKey( zone, &outLen, (char *)pResp);

        if ( rv == CKR_OK )
        {
            // tell the output system how much to send back to host
            SVC_IO_UpdateWritePointer(token, outLen);
        }
        break;

    case PE_CMD_CLR_PIN_ENC:

        // take a clear pin and encrypt it and return the result
        // Input: | zone | len | clr pin |
        // Output: | encrypted pin |
        //
        // get pin length set pinBuf to point to value
        if (SVC_IO_Read32(token, &zone) != sizeof(zone)  ||
            SVC_IO_Read32(token, &inLen) != sizeof(inLen)  ||
            SVC_IO_GetReadBuffer(token, &pinBuf) < inLen )
        {
            rv = (int) CKR_ARGUMENTS_BAD;
            break;
        }

        // get address and length of the output buffer
        outLen = SVC_IO_GetWriteBuffer( token, (void**)&pResp );

        // get cryptogramme and put in response buffer
        rv = FM_PE_ClrPinEncrypt((int)zone, (int)inLen, pinBuf,
                    &outLen, (char*)pResp);

        if ( rv == CKR_OK )
        {
            // tell the output system how much to send back to host
            SVC_IO_UpdateWritePointer(token, outLen);
        }
        break;

    case PE_CMD_TRANSLATE_PIN:

        // take an encrypted pin and re-encrypt it and return the result
        // Input: | zone | len | encrypted pin |
        // Output: | re-encrypted pin |
        //
        if (SVC_IO_Read32(token, &zone) != sizeof(zone)  ||
            SVC_IO_Read32(token, &inLen) != sizeof(inLen)  ||
            SVC_IO_GetReadBuffer(token, &pinBuf) < inLen )
        {
            rv = (int) CKR_ARGUMENTS_BAD;
            break;
        }

        // get address and length of the output buffer
        outLen = SVC_IO_GetWriteBuffer( token, (void**)&pResp );

        // get cryptogramme and put in response buffer
        rv = FM_PE_TranslatePin((int)zone, (int)inLen, pinBuf,
                    &outLen, (char*)pResp);

        if ( rv == CKR_OK )
        {
            // tell the output system how much to send back to host
            SVC_IO_UpdateWritePointer(token, outLen);
        }
        break;

    default:
        rv = (int) CKR_FUNCTION_NOT_SUPPORTED;
    }

    trace(printf("end: PinEncFM_HandleMessage rv=%x\n", rv);)

    return rv;
}


/* FM Startup function */
FM_RV Startup(void)
{
    FM_RV rv;

    /* register handler for our new API */
    trace(printf("Registering dispatch function ... ");)

    rv = FMSW_RegisterStreamDispatch(GetFMID(), PinEncFM_HandleMessage);

    trace(printf( "registered. Return Code = 0x%x\n", rv);)

    return rv;
}
