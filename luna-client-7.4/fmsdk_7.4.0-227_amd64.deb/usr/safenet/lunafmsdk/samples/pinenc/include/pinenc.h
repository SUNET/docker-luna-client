/*
 * $Id: samples/rsaenc/include/rsaenc.h 1.1 2013/12/13 16:43:05GMT-05:00 tlowe Exp  $
 * $Author: tlowe $
 *
 * $Source: samples/rsaenc/include/rsaenc.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:43:05GMT-05:00 $
 */

/*
 * This header file contains the function declarations and type definitions for
 * the PIN_ENC custom API.
 */
#ifndef INC_PINENC_H
#define INC_PINENC_H

#include <stdint.h>

/* multiple keys are stored by the HSM.
 * Each key is referred to be a zone number - any valid 32 bit integer
 * This FM only handles 10 zones
 */

#define MAX_ZONES 10

/*
 * Description:
 *    Create a RSA key pair and an AES key and store in private persistant storage.
 *
 * Parameters:
 *   hsmIndex :  which hsm
 *    zone    :  id of keyset to use
 *    slot_num:  slot number where the application has logged in a session open
 */
int PE_GenKeys(int hsmIndex, int zone, int slot_num);

#define PE_CMD_GEN_KEYS  1

/*
 * Description:
 *    return encoded public key
 *
 * Parameters:
 *   hsmIndex IN: index of Hsm to talk to
 *   zone    IN: id of keyset to use
 *   bufLen: IN: points to buffer length OUT: bytes returned
 *   outBuf: OUT: where to store encoding 
 */
int PE_GetPubKey(int hsmIndex, int zone, int *bufLen, char *outbuf);

#define PE_CMD_GET_PUBKEY  2

/*
 * Description:
 *    encode clear pin with RSA encryption
 *
 * Parameters:
 *   hsmIndex IN: which HSM
 *   zone    IN: id of keyset to use
 *   pinLen: IN: pin length
 *   pin:    IN: pin to encode 
 *   outLen: IN: points to buffer length OUT: bytes returned
 *   outBuf: OUT: where to store encoding 
 */
int PE_ClrPinEncrypt(int hsmIndex,
                     int zone, 
                     int pinLen, char *pin,
                     int *outLen, char *outbuf);

#define PE_CMD_CLR_PIN_ENC  3

/*
 * Description:
 *    translate pin from RSA to AES
 *
 * Parameters:
 *   hsmIndex IN: which HSM
 *   zone    IN: id of keyset to use
 *   inLen:  IN: RSA encrypted pin length
 *   in:     IN: RSA encrypted pin 
 *   outLen: IN: points to buffer length OUT: bytes returned
 *   outBuf: OUT: where to store result 
 */
int PE_TranslatePin(int hsmIndex,
                    int zone, 
                    int inLen, char *in,
                    int *outLen, char *outbuf);

#define PE_CMD_TRANSLATE_PIN  4

extern int defaultHSM;
extern uint32_t g_FMID;

#define FM_NAME "PIN_ENC"

#endif /* INC_PINENC_H */
