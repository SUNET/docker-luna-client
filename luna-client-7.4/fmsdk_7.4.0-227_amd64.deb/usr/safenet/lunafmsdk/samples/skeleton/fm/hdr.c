/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#include <mkfmhdr.h>

#include "skeleton.h"

DEFINE_FM_HEADER(SKELETON_FM_ID,
      FM_MAKE_VERSION(1,01),
      0,
      SKELETON_FM_MANUFACTURER_ID,
      SKELETON_FM_PRODUCT_ID);
