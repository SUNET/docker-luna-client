/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.

 WRAP-COMP FM: Demonstrates the creation of a custom API using FMs
*/


#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>       //printf() 
#include <string.h>

#include <cryptoki.h>

#include "fm/hsm/fmsw.h"
#include "fm/hsm/fm_io_service.h"
#include "fm/hsm/fm.h"

#include "wrap-comp.h"
#include "wclocal.h"

#ifdef  DEBUG
#define trace(x) x
#else
#define trace(x)
#endif

/* command handler entry point */
static
int WrapCompFM_HandleMessage(
                            FmMsgHandle token
                          )
{
    uint32_t cmd;
    CK_ULONG outLen;
    int rv;
    unsigned char  outBuf[8*1024/8 + 16];

    uint32_t slot_num;
    uint32_t attr_type;
    uint32_t hObjPriKey;
    uint32_t hObjWrap;

    trace(printf("entr: WrapCompFM_HandleMessage\n");)

    /* read in Cmd code */
    if (SVC_IO_Read32(token, &cmd) != sizeof(cmd))
    {
        /* Ensure the request is long enough to contain at least the cmd */ 
        return (uint32) CKR_FUNCTION_NOT_SUPPORTED;
    }

    trace(printf("cmd %d\n",cmd);)

    /* command switch, only one command */
    switch(cmd) {

    case WC_CMD_GET_RSA_COMP:

        // Wrap a component of the RSA private key
        // Input: | slot_num | attribute_type | hObjPriKey | hObjWrapKey |
        // Output | len | output |
        //

        if (SVC_IO_Read32(token, &slot_num) != sizeof(slot_num) ||
            SVC_IO_Read32(token, &attr_type) != sizeof(attr_type) ||
            SVC_IO_Read32(token, &hObjPriKey) != sizeof(hObjPriKey)  ||
            SVC_IO_Read32(token, &hObjWrap) != sizeof(hObjWrap))
        {
            rv = (int) CKR_ARGUMENTS_BAD;
            break;
        }

        outLen = sizeof(outBuf);
        rv = WC_WrapComp( (CK_SLOT_ID)slot_num, 
                          (CK_ATTRIBUTE_TYPE)attr_type, 
                          (CK_OBJECT_HANDLE)hObjPriKey, 
                          (CK_OBJECT_HANDLE)hObjWrap, 
                          outBuf, &outLen);

        if ( rv == CKR_OK )
        {
            SVC_IO_Write(token, outBuf, outLen); // store encoded pubkey
        }
        break;

    default:
        rv = (int) CKR_FUNCTION_NOT_SUPPORTED;
    }

    trace(printf("end: WrapCompFM_HandleMessage rv=%x\n", rv);)

    return rv;
}


/* FM Startup function */
FM_RV Startup(void) 
{
    FM_RV rv;

    /* register handler for our new API */
    trace(printf("Registering dispatch function ... ");)

    rv = FMSW_RegisterStreamDispatch(GetFMID(), WrapCompFM_HandleMessage);

    trace(printf( "registered. Return Code = 0x%x\n", rv);)
    
    return rv;
}
