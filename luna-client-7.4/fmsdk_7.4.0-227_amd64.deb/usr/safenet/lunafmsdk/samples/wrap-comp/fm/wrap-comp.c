/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

/*
 * Sample FM.
 * This FM implements a RSA private key component wrapping mechanism.
 *
 * The demonstrates the use of
 *    Embedded Cryptoki interface
 *    Use of CT_SetPrivilageLevel
 *
 * Prerequisites:
 *   the FM assumes that the calling process has already logged into the slot and
 *   that the hObjPriKey is a handle of a wrappable RSA private key and
 *   that hObjWrap is the handle of a wrapping AES key
 *
 * $Source: $
 * $Revision: $
 * $Date: $
 */

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <cryptoki.h>
#include <privilege.h>
#include <fmcrypto.h>
#include <wrap-comp.h>
#include "wclocal.h"

// Comment out one of the two following lines
#define debug(x)
//#define debug(x) x

CK_RV WC_WrapComp( CK_SLOT_ID slot_num,
                   CK_ATTRIBUTE_TYPE attr_type,
                   CK_OBJECT_HANDLE hObjPriKey,
                   CK_OBJECT_HANDLE hObjWrap,
                   unsigned char * outBuf,  CK_ULONG_PTR  outLen)
{
    CK_RV rv = CKR_OK;

    char comp [FMCE_MAX_RSA_BITS/8 + 16];  // enough for largest component plus encryption padding
    CK_OBJECT_CLASS ck_class;
    CK_KEY_TYPE ck_type;
    CK_BBOOL    bWrap;
    CK_BBOOL    bExtractable;
    CK_CHAR     ivr[16];
    CK_MECHANISM  encMech;

    CK_ATTRIBUTE priCompTemplate =
        {0,          (void*)comp,  sizeof(comp) } ;  // Note: attribute type added later

    CK_ATTRIBUTE priUsageTemplate[] = {
        {CKA_CLASS,       (void*)&ck_class,     sizeof(ck_class) },
        {CKA_KEY_TYPE,    (void*)&ck_type,      sizeof(ck_type) },
        {CKA_EXTRACTABLE, (void*)&bExtractable, sizeof(bExtractable) }
    };

    CK_ATTRIBUTE wrapUsageTemplate[] = {
        {CKA_CLASS,       (void*)&ck_class,     sizeof(ck_class) },
        {CKA_KEY_TYPE,    (void*)&ck_type,      sizeof(ck_type) },
        {CKA_WRAP,        (void*)&bWrap,        sizeof(bWrap) }
    };

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;

    debug(printf("%s: Enter slot=%d attr=0x%x hPri=0x%x hWrap=0x%x\n", __func__, slot_num, attr_type, hObjPriKey, hObjWrap);)

    rv = C_OpenSession(slot_num, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSession);
    if ( rv ) goto exit;

    //
    // check wrapped key attributes
    //
    debug(printf("%s: Check pri key is RSA\n", __func__);)
    rv = C_GetAttributeValue(hSession, hObjPriKey, priUsageTemplate, NUMITEMS(priUsageTemplate));
    if ( rv ) goto exit;

    if ( ck_class != CKO_PRIVATE_KEY || ck_type != CKK_RSA ) {
        rv = CKR_WRAPPED_KEY_INVALID;
        goto exit;
    }

    if ( bExtractable == 0 ) {
        rv = CKR_KEY_UNEXTRACTABLE;
        goto exit;
    }

    debug(printf("%s: Check wrapping key is AES\n", __func__);)

    //
    // check wrapping key attributes
    //
    rv = C_GetAttributeValue(hSession, hObjWrap, wrapUsageTemplate, NUMITEMS(wrapUsageTemplate));
    if ( rv ) goto exit;

    if ( ck_class != CKO_SECRET_KEY || ck_type != CKK_AES ) {
        rv = CKR_WRAPPING_KEY_TYPE_INCONSISTENT;
        goto exit;
    }

    if ( bWrap == 0 ) {
        rv = CKR_KEY_FUNCTION_NOT_PERMITTED;
        goto exit;
    }

    //
    // fetch the rsa private key component
    //
    debug(printf("%s: Fetching the attribute\n", __func__);)

    CT_SetPrivilegeLevel(PRIVILEGE_OVERRIDE);   // allow sensitive attributes to be read

    priCompTemplate.type = attr_type;
    rv = C_GetAttributeValue(hSession, hObjPriKey, &priCompTemplate, 1);

    CT_SetPrivilegeLevel(PRIVILEGE_NORMAL);

    if ( rv ) goto exit;

    //
    // encrypt the key component
    //
    debug(printf("%s: Encrypting the component\n", __func__);)
    memset(ivr, 0, sizeof(ivr));
    encMech.mechanism = CKM_AES_CBC_PAD;
    encMech.ulParameterLen = sizeof(ivr);
    encMech.pParameter = ivr;

    // The wrapping key has CKA_WRAP=true but CKA_ENCRYPT=false (as you would expect for a wrapping key)
    // We set FM privilege temporarilly
    // allow key with CKA_ENCRYPT=false to be used with Encrypt operation
    CT_SetPrivilegeLevel(PRIVILEGE_OVERRIDE);

    if ( (rv = C_EncryptInit(hSession, &encMech, hObjWrap)) != 0 ||
         (rv = C_Encrypt(hSession, priCompTemplate.pValue, priCompTemplate.ulValueLen, outBuf, outLen )) != 0 )
        goto exit;

    // Note: if call above fails exits this function then the Privilege state of the FM will be
    // automatically cleared when the current command returns its results to the host
    CT_SetPrivilegeLevel(PRIVILEGE_NORMAL);

exit:
    debug(printf("%s: Exit rv=0x%x\n", __func__, rv);)

    C_CloseSession(hSession);

    return rv;
}

