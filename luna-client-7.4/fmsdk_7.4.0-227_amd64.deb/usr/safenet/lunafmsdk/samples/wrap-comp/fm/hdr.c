/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#include <fm/hsm/mkfmhdr.h>

#define FM_VERSION 0x0201 /* V2.01 */
#define FM_SER_NO  0
#define FM_MANUFACTURER "Gemalto Inc"
#define FM_NAME "WRAP_COMP"

DEFINE_FM_HEADER(FMID_ALLOCATE_NORM,
		FM_VERSION,
		FM_SER_NO,
		FM_MANUFACTURER,
		FM_NAME);

