/*
 * This header file contains the function declarations and type definitions for
 * the PIN_ENC custom API.
 */
#ifndef INC_WRAPCOMP_H
#define INC_WRAPCOMP_H

#include "stdint.h"

#ifndef NUMITEMS
#define NUMITEMS(X)  (sizeof(X)/sizeof((X)[0]))
#endif

// command code sent to FM for this function
#define  WC_CMD_GET_RSA_COMP 1

typedef struct {
    uint32_t cmd;    // = WC_CMD_GET_RSA_COMP
    uint32_t slot;
    uint32_t type;
    uint32_t objPri;
    uint32_t objWrap;
} WCReq_t;

#define FM_NAME  "WRAP_COMP"

#endif /* INC_WRAPCOMP_H */
