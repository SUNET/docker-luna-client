/*
 * Copyright (c) 2000,2018 SafeNet Inc
 * All Rights Reserved - Proprietary Information of Safenet Inc
 * Not to be Construed as a Published Work.
 *
 */

/**
 * PINENC FM program host side test code
 */

#ifdef OS_WIN32
#include <windows.h>
#else
#ifdef OS_HPUX
  #include <dl.h>
#else
#include <dlfcn.h>
#endif
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fm/host/cryptoki.h"

#include <wrap-comp.h>
#include "wclocal.h"
#include "input.h"

#include <fm/common/fmerr.h>
#include <fm/host/md.h>
#include <fm/host/mdStrings.h>
#include <fm/common/integers.h>


#define BUFF_SIZE                                        128
#define PED_ID_UNDEFINED                                 -1

int PE_GenKeys(int zone, int slot_num);

void usage(void)
{
    fprintf(stderr, "Usage:  wrapcomptest [-sSlot] [-p<pin>]\n");
    fprintf(stderr, "    -s#  = use slot # - (default 1) e.g. -s3\n");
    fprintf(stderr, "    -p<pin>  = user pin (default is to prompt)\n");
    fprintf(stderr, "    -e<ped> = remote ped Id to login to slot \n");

    exit(1);
}

int login(int slot, char *pin, CK_SESSION_HANDLE * phSess, int pedId)
{

    CK_RV rv = 0;
    CK_SESSION_HANDLE hSess;
    CK_ULONG isPedUsed = pedId != PED_ID_UNDEFINED ? 1 : 0;
    CK_ULONG uPedId = (CK_ULONG)pedId;
    CK_ULONG oldPedId = 0;
    CK_CHAR pinBuf[256];

    /** Initialize the Cryptoki library
     */
    rv = C_Initialize(NULL);
    if(rv != MDR_OK)
    {
        printf("C_Initialize %lx\n", rv);
        exit(1);
    }
    /*
     * This also initializs the Message dispatch library
     */
    rv = MD_Initialize();
    if (rv != MDR_OK) {
        printf("MD_Initialize %s\n", MD_RvAsString(rv));
        exit(1);
    }

    rv = C_OpenSession(slot, CKF_SERIAL_SESSION | CKF_RW_SESSION, NULL, NULL, &hSess);

    if(rv != MDR_OK) {
        printf("C_OpenSession failed with error code: 0x%lx\n", rv);
        printf("Check -s option\n");
        exit(1);
    }

    if (isPedUsed) {
       if (pin != NULL && pin[0] != '\0') {
          printf("Error: PIN used for PED only authentication \n");
          rv = CKR_CANCEL;
       } else {
          printf("\nPlease attend to the PED\n");
          rv = CA_GetPedId(slot, &oldPedId);
          if (rv != CKR_OK)
             printf("\nError: Failed to get the existing PED id.\n");
          else {
             if (oldPedId != uPedId) {
                rv = CA_SetPedId(slot, uPedId);
                if (rv != CKR_OK)
                   printf("\nError: Failed to set the new PED id (%d).\n", (int)uPedId);
             }
             if (rv == CKR_OK) {
                rv = C_Login(hSess, CKU_USER, NULL, 0);
                if (oldPedId != uPedId) {
                   CK_RV rv1 = CA_SetPedId(slot, oldPedId);
                   if (rv1 != CKR_OK) {
                       printf("\nError: Failed to set the old PED id (%d).\n", (int)oldPedId);
                       rv = (rv == CKR_OK)? rv1 : rv;
                   }
                }
             }
          }
       }
    } else {
       if ( !pin ) {
             printf("Please enter User Pin: ");
             CON_GetSecret( (char*)pinBuf, sizeof(pinBuf));
             pin = (char*)pinBuf;
       }

       if ( pin && strlen(pin) > 0 )
           rv = C_Login(hSess, CKU_USER, (CK_CHAR_PTR)pin, (CK_ULONG)strlen(pin));
       else {
           rv = CKR_CANCEL;
           printf("\nError: Failed to input a valid pin.\n");
       }
    }

    if(rv != MDR_OK)
    {
        printf("C_Login failed with error code: 0x%lx\n", rv);
        exit(1);
    }

    *phSess = hSess;

    return rv;
}

int logout(CK_SESSION_HANDLE hSess)
{

    CK_RV rv = 0;

    rv = C_Logout(hSess);

    if(rv != MDR_OK)
    {
        printf("C_Logout failed with error code: 0x%lx\n", rv);
        exit(1);
    }

    rv = C_CloseSession(hSess);

    if(rv != MDR_OK)
    {
        printf("C_CloseSession failed with error code: 0x%lx\n", rv);
        exit(1);
    }

    /** Finalize the MD library. */
    MD_Finalize();

    /** Finalize the Cryptoki library. */
    C_Finalize(NULL);

    return rv;
}

// Use Cryptoki engine to generate a RSA key pair
//
CK_RV generateRsaKeyPair(CK_SESSION_HANDLE hSession,
    int keyLen,   // key length in bits
	CK_OBJECT_HANDLE * phPublicKey,
	CK_OBJECT_HANDLE * phPrivateKey)
{
	CK_MECHANISM mechanism = { 0, NULL, 0 };
	static CK_ULONG bits;
	static CK_CHAR  exp[]  = { 0x01, 0x00, 0x01 };
	static const CK_BYTE label[] = {"tmp"};
	static const CK_BYTE id[] = {123};
	static const CK_BBOOL enc = FALSE;
	static const CK_BBOOL ver = FALSE;
	static const CK_BBOOL wrap = FALSE;
	static const CK_BBOOL sens = TRUE;
	static const CK_BBOOL extr = TRUE;
	static CK_BBOOL isTok = FALSE;   // session key
	static CK_BBOOL isPri = TRUE;    // owner must be logged in
	CK_ATTRIBUTE pubTemplate[] = {
		{CKA_TOKEN, (void*)&isTok, 1},
		{CKA_PRIVATE, (void*)&isPri, 1},
		{CKA_LABEL, (void*)label, sizeof(label)},
		{CKA_MODULUS_BITS, (void*)&bits, sizeof(bits)},
		{CKA_ENCRYPT, (void*)&enc, 1},
		{CKA_VERIFY, (void*)&ver, 1},
		{CKA_WRAP, (void*)&wrap, 1},
		{CKA_PUBLIC_EXPONENT, exp, sizeof(exp)} /* last */
	};
	CK_ATTRIBUTE priTemplate[] = {
		{CKA_TOKEN, (void*)&isTok, 1},
		{CKA_PRIVATE, (void*)&isPri, 1},
		{CKA_LABEL, (void*)label, sizeof(label)},
		{CKA_ID, (void*)id, sizeof(id)},
		{CKA_SENSITIVE, (void*)&sens, 1},
		{CKA_DECRYPT, (void*)&enc, 1},
		{CKA_SIGN, (void*)&ver, 1},
		{CKA_UNWRAP, (void*)&wrap, 1},
		{CKA_EXTRACTABLE, (void*)&extr, 1}
	};
	CK_RV rv;

	bits = keyLen;

	/* Generate the key pair */
	mechanism.mechanism = CKM_RSA_X9_31_KEY_PAIR_GEN;
	rv = C_GenerateKeyPair(hSession, &mechanism,
		pubTemplate, NUMITEMS(pubTemplate),
		priTemplate, NUMITEMS(priTemplate),
		phPublicKey, phPrivateKey
	);

    if(rv != CKR_OK)
    {
        printf("C_GenerateKeyPair failed with error code: 0x%lx\n", rv);
    }

    return rv;
}

// Use Cryptoki engine to generate a RSA key pair
//
CK_RV generateAESKey(CK_SESSION_HANDLE hSession,
	CK_OBJECT_HANDLE * phAESKey)
{
	CK_MECHANISM mechanism = { 0, NULL, 0 };
	static const CK_BYTE label[] = {"tmp"};
	static const CK_BYTE id[] = {123};
	static const CK_BBOOL enc = FALSE;
	static const CK_BBOOL dec = FALSE;
	static const CK_BBOOL ver = FALSE;
	static const CK_BBOOL sign = FALSE;
	static const CK_BBOOL wrap = TRUE;
	static const CK_BBOOL unwrap = FALSE;
	static const CK_BBOOL sens = TRUE;
	static const CK_BBOOL extr = FALSE;
	static CK_BBOOL isTok = FALSE;   // session key
	static CK_BBOOL isPri = TRUE;    // owner must be logged in

    static CK_ULONG  len = 32;  // length of key in bytes

	CK_ATTRIBUTE keyTemplate[] = {
		{CKA_TOKEN, (void*)&isTok, 1},
		{CKA_PRIVATE, (void*)&isPri, 1},
		{CKA_LABEL, (void*)label, sizeof(label)},
		{CKA_VALUE_LEN, (void*)&len, sizeof(len)},
		{CKA_ENCRYPT, (void*)&enc, 1},
		{CKA_VERIFY, (void*)&ver, 1},
		{CKA_WRAP, (void*)&wrap, 1},
		{CKA_EXTRACTABLE, (void*)&extr, 1},
		{CKA_ID, (void*)id, sizeof(id)},
		{CKA_SENSITIVE, (void*)&sens, 1},
		{CKA_DECRYPT, (void*)&dec, 1},
		{CKA_SIGN, (void*)&sign, 1},
		{CKA_UNWRAP, (void*)&unwrap, 1},
		{CKA_EXTRACTABLE, (void*)&extr, 1}
	};
	CK_RV rv;


	/* Generate the key */
	mechanism.mechanism = CKM_AES_KEY_GEN;
	rv = C_GenerateKey(hSession, &mechanism,
		keyTemplate, NUMITEMS(keyTemplate),
		phAESKey
	);

    if(rv != CKR_OK)
    {
        printf("C_GenerateKey failed with error code: 0x%lx\n", rv);
    }

    return rv;
}

// perform rsa component wrap test by:
//   generating a temporary rsa key pair
//   generating a temporary wrapping AES key
//   wrap each component and discard the result
//   delete all temporary keys
CK_RV doWrapTest(CK_SESSION_HANDLE hSess, CK_SLOT_ID slot, int keyLen)
{
    CK_RV rv;
    CK_OBJECT_HANDLE hPublicKey;
    CK_OBJECT_HANDLE hPrivateKey;
    CK_OBJECT_HANDLE hWrapKey;
    unsigned char outBuf[8*1024/8];
    CK_ULONG  outLen;
    int idx;
    uint32_t fmid, hsmIndex;

    struct {
        char * name;
        CK_ATTRIBUTE_TYPE type;
    } attrList[] = {
        { "CKA_MODULUS", CKA_MODULUS },
        { "CKA_PUBLIC_EXPONENT", CKA_PUBLIC_EXPONENT },
        { "CKA_PRIVATE_EXPONENT", CKA_PRIVATE_EXPONENT },
        { "CKA_PRIME_1", CKA_PRIME_1 },
        { "CKA_PRIME_2", CKA_PRIME_2 },
        { "CKA_EXPONENT_1", CKA_EXPONENT_1 },
        { "CKA_EXPONENT_2", CKA_EXPONENT_2 },
        { "CKA_COEFFICIENT", CKA_COEFFICIENT }
    };

    printf("Generating RSA Key Pair\n");
    rv = generateRsaKeyPair(hSess, keyLen, &hPublicKey, &hPrivateKey);
    if ( rv ) return rv;

    // remove public key we do not need it
    rv = C_DestroyObject(hSess, hPublicKey);
    if ( rv ) return rv;

    printf("Generating AES Key\n");
    rv = generateAESKey(hSess, &hWrapKey);
    if ( rv ) return rv;

    rv = MD_GetHsmIndexForSlot(slot, &hsmIndex);
    if (rv != 0) return CKR_SLOT_ID_INVALID;
    printf("Hsm index for slot %d is %d\n", (int)slot, (int)hsmIndex);

    rv = MD_GetFmIdFromName(hsmIndex, FM_NAME, (uint32_t)strlen(FM_NAME), &fmid);
    if (rv != 0) {
       printf("FM %s not found on HSM %d\n", FM_NAME, (int)hsmIndex);
       return CKR_FUNCTION_NOT_SUPPORTED;
    }
    printf("FM %s found with ID %dxn", FM_NAME, (int)fmid);

    for(idx=0; idx < NUMITEMS(attrList); ++idx)
    {
        outLen = sizeof(outBuf);
        rv = WC_WrapComp( (uint16_t)fmid,
                       slot,
                       attrList[idx].type,
                       hPrivateKey,
                       hWrapKey,
                       outBuf,  &outLen);
        if (rv) {
            printf("WC_WrapComp failed wrapping %s with error code: 0x%lx\n",
                       attrList[idx].name, rv);
            printf("Check -s option\n");
           break;
        } else {
            printf("WC_WrapComp wrapped %20s OK len = %3ld val = %02x %02x %02x ...\n",
                       attrList[idx].name, outLen,
                       outBuf[0], outBuf[1], outBuf[2]);
        }
    }
    return rv;
}


#define GETARGVAL() \
    pVal = &pArg[2]; \
    if (*pVal == '\0') { \
        pVal = *(++argv); \
        if(--argc == 0 || pVal == NULL) \
           usage(); \
    }


int
main(int argc, char **argv)
{
    CK_RV rv = 0;
    CK_SESSION_HANDLE hSess;
    char * pVal;
    char * pin = NULL;
    int pedId = PED_ID_UNDEFINED;
    int slot = 1;

    /* Parse parameters */
    ++argv;
    --argc;

    while(argc > 0)
    {
        char * pArg;

        pArg = *argv;
        if (pArg[0] == '-')
        {
            switch(pArg[1])
            {
                case 's':
                    GETARGVAL();
                    slot = atoi(pVal);
                    break;
                case 'p':
                    GETARGVAL();
                    pin = pVal;
                    break;
                case 'e':
                    GETARGVAL();
                    pedId = atoi(pVal);
                    break;
                default:
                   usage();
            }
        } else {
                usage();
        }
        --argc;
        ++argv;
    }

    printf("\nWrap RSA Components Test Application\n");
    printf("Logging in to slot %d\n", slot);

    rv = login(slot, pin, &hSess, pedId);
    if (rv != 0 )
        return rv;

    // do tests if requested
    rv = doWrapTest(hSess, slot, 2048);
    if (rv != 0 )
        return rv;

    printf("Logging out of slot %d\n", slot);
    rv = logout(hSess);

    return rv;
}

