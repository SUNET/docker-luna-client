/*
 * Copyright (c) 2018 Safenet Inc
 *
 * All Rights Reserved - Proprietary Information of Safenet Inc
 * Not to be Construed as a Published Work.
 *
 */
#ifndef INC_INPUT_H
#define INC_INPUT_H


/**
 * Obtains a secret value from the console.
 *
 * It will read up to len-1 characters, or until a '\n' is entered - whichever
 * comes first. The '\n' character will be removed from the string.
 *
 * This function will read and ignore the rest of the unread characters up
 * until the next '\n', or eof.
 *
 * The string is always zero terminated.
 *
 * This function does not show the characters that are input from the
 * console.
 *
 * Parameters:
 * buf: The buffer, which will accept the input. It must be at
 *     least len bytes long.
 * len: The number of bytes available in buf.
 *
 * Return Value:
 *     Number of characters placed into the provided buffer.
 *     If an error occurs reading the values, zero is returned.
 */
unsigned int CON_GetSecret( 
		/* The buffer, which will accept the input. It must be at least len
		   bytes long. */
		char *buf, 

		/* The number of bytes available in buf. */
		unsigned int len 
);
int CON_EchoOff(void);
int CON_EchoOn(void);

#endif /* INC_INPUT_H */
