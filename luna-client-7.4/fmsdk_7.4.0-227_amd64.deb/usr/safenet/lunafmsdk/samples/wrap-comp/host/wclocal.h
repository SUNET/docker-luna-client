/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/


/*
 * Description:
 *    wrap a component of a RSA private key using AES
 *
 * Parameters:
 *    slot_num:  slot number where the application has logged in a session
 *    attr_type: 
 *    hObjPriKey: key where component comes from - must be RSA private key with CKA_EXTRACTABLE=1
 *    hObjWrap  : wrapping key - must be AES key with CKA_WRAP=1
 *    outBuf:     store cryptogramm here
 *    outLen  :   IN: length of outBuf, OUT: bytes written to outBuf
 *    RETURN : CK_RV, 0 if OK
 */
CK_RV WC_WrapComp( uint16_t fmid, 
                   CK_SLOT_ID slot_num, 
                   CK_ATTRIBUTE_TYPE attr_type, 
                   CK_OBJECT_HANDLE hObjPriKey, 
                   CK_OBJECT_HANDLE hObjWrap, 
                   unsigned char * outBuf,  CK_ULONG_PTR  outLen);

