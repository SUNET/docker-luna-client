/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#include <stddef.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <fm/host/cryptoki.h>
#include <wrap-comp.h>

#include <fm/host/md.h>
#include <fm/host/mdStrings.h>
#include <fm/hsm/csa8fm.h>
#include <fm/common/fm_byteorder.h>
#include "wclocal.h"

/**
 * wrap-comp program host stub (encode/decode api)
 */


/*
 * Description:
 *    wrap a cmponent of a RSA private key using AES
 *
 * Parameters:
 *    slot_num:  slot number where the application has logged in a session
 *    attr_type:
 *    hObjPriKey: key where component comes from - must be RSA private key with CKA_EXTRACTABLE=1
 *    hObjWrap  : wrapping key - must be AES key with CKA_WRAP=1
 *    outBuf:     store cryptogramm here
 *    outLen  :   IN: length of outBuf, OUT: bytes written to outBuf
 *    RETURN : CK_RV, 0 if OK
 */
CK_RV WC_WrapComp( uint16_t fmid,
                   CK_SLOT_ID slot_num,
                   CK_ATTRIBUTE_TYPE attr_type,
                   CK_OBJECT_HANDLE hObjPriKey,
                   CK_OBJECT_HANDLE hObjWrap,
                   unsigned char * outBuf,  CK_ULONG_PTR  outLen)
{
    MD_Buffer_t     request[4],
                    reply[2];

    uint32_t appState     = 0,
             originatorID = 0;
    CK_SLOT_ID hsmslotnum;
    uint32_t recvLen;
    uint32_t cmd          = WC_CMD_GET_RSA_COMP;
    MD_RV rv              = MDR_UNSUCCESSFUL;
    WCReq_t  req;
    uint32_t HsmIndex = 0;

    // convert Host slot number to HSM slot number
    rv = MD_GetEmbeddedSlotID(slot_num, &hsmslotnum);
    if (rv != 0) return CKR_SLOT_ID_INVALID;

    rv = MD_GetHsmIndexForSlot(slot_num, &HsmIndex);
    if (rv != 0) return CKR_SLOT_ID_INVALID;

    /**
     * Build our send buffer.
     *
     * The structure of the buffer will depend on the implementation
     * of the FM.
     */
    req.cmd = fm_htobe32(cmd);
    req.slot = fm_htobe32(hsmslotnum);
    req.type = fm_htobe32((uint32_t)attr_type);
    req.objPri = fm_htobe32((uint32_t)hObjPriKey);
    req.objWrap = fm_htobe32((uint32_t)hObjWrap);

    request[0].pData = (uint8_t *)&req;
    request[0].length = sizeof(req);

    /** The last MD_Buffer_t MUST be terminated in this fashion. - VERY IMPORTANT */
    request[1].pData = NULL;
    request[1].length = 0;

    /** point to where response should be written */
    reply[0].pData = (uint8_t *)outBuf;
    reply[0].length = *outLen;

    /** Terminate our receive buffer as per earlier comment - VERY IMPORTANT */
    reply[1].pData = NULL;
    reply[1].length = 0;

    recvLen = 0; appState = 0;

    /** Send and receive our buffer via MD_SendReceive() */
    rv = MD_SendReceive( HsmIndex,
                         originatorID,
                         fmid,
                         request,
                         0,
                         reply,
                         &recvLen,
                         &appState);


    /**
     * MD_SendReceive() return MD_RV. If it is not zero then the FM did not see the message
     * or crashed etc.
     *
     * If MD_Sendreceive is OK then appState holds whatever value was returned from FM
     * If MD_Sendreceive fails convert error to appropriate appState value.
     */

     if (rv != MDR_OK)
     {
        printf("MD_SendReceive failed: %s\n", MD_RvAsString(rv));
        appState = CKR_GENERAL_ERROR;
     } else
        *outLen = recvLen;

    return appState;
}

