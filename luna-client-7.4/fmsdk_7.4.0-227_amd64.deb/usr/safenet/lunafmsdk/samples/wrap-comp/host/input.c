/*
 * Copyright (c) 2018 Safenet Inc
 *
 * All Rights Reserved - Proprietary Information of Safenet Inc
 * Not to be Construed as a Published Work.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#ifdef unix
#include <unistd.h>
#include <termios.h>
#include <errno.h>
#endif
#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif
#include "input.h"

#ifdef unix
	struct termios settings;
	tcflag_t old_c_lflag;
	char *cp;
#endif
#ifdef WIN32
	HANDLE hStdIn;
	DWORD conMode;
#endif

/*
 * Obtains a secret value from the console.
 *
 * It will read up to len-1 characters, or until a '\n' is entered - whichever
 * comes first. The '\n' character will be removed from the string.
 *
 * This function will read and ignore the rest of the unread characters up
 * until the next '\n', or eof.
 *
 * The string is always zero terminated.
 *
 * This function does not show the characters that are input from the
 * console.
 *
 * Parameters:
 * buf: The buffer, which will accept the input. It must be at
 *     least len bytes long.
 * len: The number of bytes available in buf.
 *
 * Return Value:
 *     Number of characters placed into the provided buffer.
 *     If an error occurs reading the values, zero is returned.
 */
unsigned int CON_GetSecret( 
		char *buf, 
		unsigned int len 
)
{
    char *s;

    /* validate arguments */
    if ((buf == NULL) || (len < 1))
    {
        return 0;
    }

    /* Turn the echo of entered characters off */
	if (CON_EchoOff())
		return 0;

    /* read up to newline/EOF or strSize-1 characters */
    s = fgets(buf, len, stdin);

    /* check for error. s != buf for pedantic compiler */
    if (s != buf || ferror(stdin) != 0)
    {
        return 0;
    }

    if (buf[strlen(buf)-1] == '\n')
    {
        /* convert newline into '\0' */
        buf[strlen(buf)-1] = '\0';
    }
    else
    {
        /* 
         * We did not read the newline.
         *
         * Eat everything upto newline or EOF.
         */
        int ch = 0;

        do
        {
            ch = fgetc(stdin);
        } while ((ch !=
#ifdef WIN32
               '\r'
#else
               '\n'
#endif
        ) && (!feof(stdin)) && (!ferror(stdin)));
    }

    /* Turn the echo of entered characters back on */
	if (CON_EchoOn())
		return 0;

	return (unsigned int)strlen(buf);
}

int CON_EchoOff(void)
{
#ifdef unix
	if (isatty(fileno(stdin)))
	{
		if ( tcgetattr(fileno(stdin), &settings) != 0 ) {
			return 1;
		}

		old_c_lflag = settings.c_lflag;
		settings.c_lflag &= ~(ECHO|ECHOE);
		settings.c_lflag |= ECHONL;

		if ( tcsetattr(fileno(stdin), TCSANOW, &settings) != 0 ) {
			return 1;
		}
	}
#endif
#ifdef WIN32
	hStdIn = GetStdHandle(STD_INPUT_HANDLE);
	if (hStdIn != INVALID_HANDLE_VALUE) {
		BOOL r = GetConsoleMode(hStdIn, &conMode);
		if (r != FALSE) {
			DWORD newMode = ENABLE_PROCESSED_INPUT|ENABLE_LINE_INPUT;
			SetConsoleMode(hStdIn, newMode);
		} else {
			hStdIn = INVALID_HANDLE_VALUE;
		}
	}
#endif

	return 0;
}

int CON_EchoOn(void)
{
#ifdef unix
	if (isatty(fileno(stdin)))
	{
		settings.c_lflag = old_c_lflag;

		if ( tcsetattr(fileno(stdin), TCSANOW, &settings) != 0 ) {
			return 1;
		}
	}
#endif
#ifdef WIN32
	SetConsoleMode(hStdIn, conMode);
	puts("");
#endif

	return 0;
}

