/****************************************************************************\
*
* Filename:    fm_byteorder.h
*
* Description: target byte order determination, byte order conversions
*
* Detects the native byte order (endianess) of the platform we're building
* on. Once detected, provides varios functions/macros to convert big endian
* and/or little endian representation of sized integral types to/from the
* platform native byte order.
*
* Copyright � 2011-17 SafeNet.  All rights reserved.
*
* All rights reserved. This file contains information that is
* proprietary to SafeNet and may not be distributed
* or copied without written consent from SafeNet.
*
\****************************************************************************/
#ifndef FM_BYTEORDER_H
#define FM_BYTEORDER_H

/*
 * Quick API reference
 *
 *
 * 1. Global macro predefines
 * --------------------------
 *
 * After successful processing of this file:
 *
 * - FM_BIG_ENDIAN is defined if compiling for big endian target
 * - FM_LITTLE_ENDIAN is defined if compiling for little endian target
 *
 * Only one of the two macros is defined. If the target byte order cannot be
 * determined compilation fails with error. 
 *
 *
 * 3. Swappers between the host's native and big or little endian byte orders
 * --------------------------------------------------------------------------
 *
 * In APIs below:
 *
 * - 'be'  stands for Big Endian byte order
 * - 'le'  stands for Little Endian byte order
 * - 'h'   stands for Host (e.g. platform native) byte order
 *
 *
 * Take an aligned word of sized integer type and return it in requested byte order:
 *
 * - uint16_t fm_htobe16(uint16_t w)
 * - uint16_t fm_htole16(uint16_t w)
 * - uint16_t fm_betoh16(uint16_t w)
 * - uint16_t fm_letoh16(uint16_t w)
 *
 * - uint32_t fm_htobe32(uint32_t w)
 * - uint32_t fm_htole32(uint32_t w)
 * - uint32_t fm_betoh32(uint32_t w)
 * - uint32_t fm_letoh32(uint32_t w)
 *
 * - uint64_t fm_htobe64(uint64_t w)
 * - uint64_t fm_htole64(uint64_t w)
 * - uint64_t fm_betoh64(uint64_t w)
 * - uint64_t fm_letoh64(uint64_t w)
 * 
 */

#include <stdint.h>

/******************************************************************************
 * Detect the target platform byte order (a.k.a.endianess). Most compilers,
 * despite they _do_ know the byte order of the platform they are building for
 * do not set any predefined macros that explicitly tell what the byte order
 * is. We have to dig this information from various sources.
 *
 * The end result of the detection process is either FM_BIG_ENDIAN or
 * FM_LITTLE_ENDIAN defined and set to 1. Only _one_ of this macros is
 * defined. If detection fails none is defined and the preprocessor throws
 * out an error.
 *****************************************************************************/

/*
 * FM_BIG_ENDIAN or FM_LITTLE_ENDIAN can be defined externally, for example
 * as a compiler option (e.g. gcc -DFM_BIG_ENDIAN).
 */
#if defined(FM_BIG_ENDIAN) && defined(FM_LITTLE_ENDIAN)
#  error Ambiguous predefined byte order for the platform
#endif

/*
 * If none already defined detect ourselves. Start from obvious build targets
 * and descent to more obscure platforms until either FM_BIG_ENDIAN or
 * FM_LITTLE_ENDIAN is defined. Once defined skip all remaining test cases.
 *
 * Lots of compiler's predefined macros are taken from:
 * http://sourceforge.net/p/predef/wiki/Home/
 */

/*
 * Assume Windows is always little endian (Windows can be built for ARM these
 * days but normally it is little endian too).
 */
#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if defined(_WIN32) || defined(_WIN64) || defined(__WIN32__) || defined(__TOS_WIN__) || defined(__WINDOWS__)
#     define FM_LITTLE_ENDIAN
#  endif
#endif

/*
 * Try C libary's or OS's endian.h. Location of the file varies
 */
#if !defined(FM_BIG_ENDIAN) && !defined(FM_LITTLE_ENDIAN)
#  if   defined(__GLIBC__) || defined(__GNU_LIBRARY__)
#     define FM_ENDIAN_H_PATH__    <endian.h>
#  elif defined(macintosh) || defined(Macintosh) || (defined(__APPLE__) && defined(__MACH__)) || defined(__OpenBSD__)
#     define FM_ENDIAN_H_PATH__    <machine/endian.h>
#  elif defined(__FreeBSD__) || defined(__NetBSD__) || defined(__bsdi__) || defined(__DragonFly__)
#     define FM_ENDIAN_H_PATH__    <sys/endian.h>
#  endif

#  if defined(FM_ENDIAN_H_PATH__)
#     include FM_ENDIAN_H_PATH__
#  endif

#  if defined(__BYTE_ORDER)
#     if   __BYTE_ORDER == __BIG_ENDIAN
#        define FM_BIG_ENDIAN
#     elif __BYTE_ORDER == __LITTLE_ENDIAN
#        define FM_LITTLE_ENDIAN
#     else
#        error Unsupported byte order for the platform
#     endif
#  endif

#  if !defined(__BYTE_ORDER) && defined(_BYTE_ORDER)
#     if   _BYTE_ORDER == _BIG_ENDIAN
#        define FM_BIG_ENDIAN
#     elif _BYTE_ORDER == _LITTLE_ENDIAN
#        define FM_LITTLE_ENDIAN
#     else
#        error Unsupported byte order for the platform
#     endif
#  endif
#endif

/*
 * Try compiler predefines related to byte order specifically, e.g.:
 * - IBM's XL C compiler (__xlc__) defines __BIG_ENDIAN__ and _BIG_ENDIAN
 * - ARM compiler (__arm__) defines __BIG_ENDIAN or nothing depending on
 *   the command line options
 */
#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if defined(__BIG_ENDIAN__) && !defined(__LITTLE_ENDIAN__)
#     define FM_BIG_ENDIAN
#  endif
#endif

#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if defined(_BIG_ENDIAN) && !defined(_LITTLE_ENDIAN)
#     define FM_BIG_ENDIAN
#  endif
#endif

#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if defined(__LITTLE_ENDIAN__) && !defined(__BIG_ENDIAN__)
#     define FM_LITTLE_ENDIAN
#  endif
#endif

#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if defined(_LITTLE_ENDIAN) && !defined(_BIG_ENDIAN)
#     define FM_LITTLE_ENDIAN
#  endif
#endif

#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if (defined(__arm__) || defined(__arm)) && defined(__BIG_ENDIAN)
#     define FM_BIG_ENDIAN
#  else
#     define FM_LITTLE_ENDIAN
#  endif
#endif

/*
 * Try compiler predefines for architectures that support just one byte order
 */
#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if defined(__m68k__) || defined(M68000)
#     define FM_BIG_ENDIAN
#  elif defined(__hppa__) || defined(__hppa) || defined(__HPPA__)
#     define FM_BIG_ENDIAN
#  elif defined(__370__) || defined(__THW_370__)
#     define FM_BIG_ENDIAN
#  elif defined(__s390__) || defined(__s390x__)
#     define FM_BIG_ENDIAN
#  elif defined(__SYSC_ZARCH__)
#     define FM_BIG_ENDIAN
#  elif defined(__sparc)
#     define FM_BIG_ENDIAN
#  endif
#endif

#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if defined(i386) || defined(__i386__) || defined(__i386)
#     define FM_LITTLE_ENDIAN
#  elif defined(__i486__) || defined(__i586__) || defined(__i686__)
#     define FM_LITTLE_ENDIAN
#  elif defined(_M_IX86) || defined(_X86_) || defined(__I86__)
#     define FM_LITTLE_ENDIAN
#  elif defined(__THW_INTEL__) || defined(__INTEL__)
#     define FM_LITTLE_ENDIAN
#  elif defined(__amd64__) || defined(__amd64) || defined(__x86_64) || defined(__x86_64__) || defined(_M_X64)
#     define FM_LITTLE_ENDIAN
#  elif defined(__ia64__) || defined(__ia64) || defined(_IA64) || defined(__IA64__) || defined(_M_IA64) || defined(__itanium__) 
#     define FM_LITTLE_ENDIAN
#  elif defined(__bfin__) || defined(__BFIN__) || defined(bfin) || defined(BFIN)
#     define FM_LITTLE_ENDIAN
#  endif
#endif

/*
 * Try compiler predefines that have endian suffix/prefix for bi-endian
 * architectures.
 */
#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if defined(__ARMEB__) || defined(__THUMBEB__) 
#     define FM_BIG_ENDIAN
#  elif defined(__AARCH64EB__) || defined(_MIPSEB) || defined(__MIPSEB) || defined(__MIPSEB__)
#     define FM_BIG_ENDIAN
#  endif
#endif

#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  if defined(__ARMEL__) || defined(__THUMBEL__) 
#     define FM_LITTLE_ENDIAN
#  elif defined(__AARCH64EL__) || defined(_MIPSEL) || defined(__MIPSEL) || defined(__MIPSEL__)
#     define FM_LITTLE_ENDIAN
#  endif
#endif

/*
 * Give up if failed to detect the platform byte order
 */
#if !defined(FM_LITTLE_ENDIAN) && !defined(FM_BIG_ENDIAN)
#  error Unknwon platform byte order. Define FM_LITTLE_ENDIAN or FM_BIG_ENDIAN explicitly or add the rule
#endif

/******************************************************************************
 * Macros/functions for byte order swapping in integral types. Swappers do not
 * depend on the target platform endianess, but they are usually used for
 * endian conversions. Platform can provide highly optimized byte swappers.
 *****************************************************************************/ 

/*
 * Generic platform-agnostic byte swappers.
 */
static inline uint16_t
fm_bswap16__(uint16_t i)
{
   return (i >> 8) | (i << 8);
}

static inline uint32_t
fm_bswap32__(uint32_t i)
{
   return  (i << 24) |
          ((i << 8) & 0xff0000UL) |
          ((i >> 8) & 0xff00UL) |
           (i >> 24);
}

static inline uint64_t
fm_bswap64__(uint64_t i)
{
   return  (i << 56) |
          ((i << 40) & 0xff000000000000ULL) | 
          ((i << 24) & 0xff0000000000ULL) |
          ((i << 8)  & 0xff00000000ULL) |
          ((i >> 8)  & 0xff000000ULL) |
          ((i >> 24) & 0xff0000ULL) |
          ((i >> 40) & 0xff00ULL) |
           (i >> 56);
}

/*
 * MS Visual Studio 2005 (_MSC_VER == 1400) added the functions below.
 */
#if !defined(fm_bswap16_) || !defined(fm_bswap32_) || !defined(fm_bswap64_)
#  if defined(_MSC_VER) && (_MSC_VER >= 1400)
#     include <stdlib.h>
#     define fm_bswap16_         _byteswap_ushort
#     define fm_bswap32_         _byteswap_ulong
#     define fm_bswap64_         _byteswap_uint64
#  endif
#endif

/*
 * GCC builtins
 */
#if !defined(fm_bswap16_) || !defined(fm_bswap32_) || !defined(fm_bswap64_)
#  if defined(__GNUC__) && (__GNUC__ >= 4)
#     if (__GNUC_MINOR__ >= 3)
#        if !defined(fm_bswap32_)
#           define fm_bswap32_   __builtin_bswap32
#        endif
#        if !defined(fm_bswap64_)
#           define fm_bswap64_   __builtin_bswap64
#        endif
#     endif
#     if (__GNUC_MINOR__ >= 8)
#        if !defined(fm_bswap16_)
#           define fm_bswap16_   __builtin_bswap16
#        endif
#     endif
#  endif
#endif

/*
 * On Linux fast platform-specific byte swappers are provided by kernel.
 * headers. Bit of a hack...
 */
#if !defined(fm_bswap16_) || !defined(fm_bswap32_) || !defined(fm_bswap64_)
#  if defined(__linux__) || defined(linux) || defined(__linux)
#     include <asm/byteorder.h>
#     if !defined(fm_bswap16_)
#        define fm_bswap16_      __swab16
#     endif
#     if !defined(fm_bswap32_)
#        define fm_bswap32_      __swab32
#     endif
#     if !defined(fm_bswap64_)
#        define fm_bswap64_      __swab64
#     endif
#  endif
#endif

/*
 * Do inline assembler on x86 platform and GCC compiler
 */
#if !defined(fm_bswap16_) || !defined(fm_bswap32_) || !defined(fm_bswap64_)
#  if defined(__GNUC__)
#     if defined(i386) || defined(__i386__) || defined(__i386) || defined(__amd64__) || defined(__amd64)  || defined(__x86_64) || defined(__x86_64__)
#        if !defined(fm_bswap32_)
#           define fm_bswap32_(v32_)  \
               ({\
                  __asm ("bswap %1" : "=r" (v32_) : "0" (v32_)); v32_;\
               })
#        endif
#        if !defined(fm_bswap64_)
#           define fm_bswap64_(v64_)  \
               ({\
                  uint32_t l32_ = (v64_), h32_ = ((v64_) >> 32); \
                  ((uint64_t)fm_bswap32_(h32_)) << 32 | fm_bswap32_(l32_); \
               })
#        endif
#     endif
#  endif
#endif

/*
 * Do inline asm for ARM compiler too
 */
#if !defined(fm_bswap16_) || !defined(fm_bswap32_) || !defined(fm_bswap64_)
#  if defined(__arm) || defined(__arm__)
#     if !defined(fm_bswap16_)
         fm_sinline short unsigned arm_swap16(short unsigned a)
         {  
            unsigned b;
            __asm
            {
               MOV   b, a, LSL #8
               ORR   a, b, a, LSR #8
               BIC   a, a, #0xFF0000
            }
            return a;
         }
#        define fm_bswap16_   arm_swap16
#     endif
#     if !defined(fm_bswap32_)
         fm_sinline unsigned arm_swap32(unsigned a)
         {  
            unsigned b;
            __asm
            {
               EOR      b, a, a, ROR #16
               BIC      b, b, #0xFF0000
               MOV      a, a, ROR #8
               EOR      a, a, b, LSR #8
            }
            return a;
         }
#        define fm_bswap32_   arm_swap32
#     endif
#     if !defined(fm_bswap64_)
         fm_sinline unsigned long long arm_swap64(unsigned long long a)
         {
            unsigned b;
            union { struct {unsigned l; unsigned h;} w; unsigned long long qw; } swp;
            swp.qw = a;
            b = arm_swap32(swp.w.l);
            swp.w.l = arm_swap32(swp.w.h);
            swp.w.h = b;
            return swp.qw;
         }
#        define fm_bswap64_   arm_swap64
#     endif
#  endif
#endif

/*
 * For any byte swapper not yet defined default to generic version
 */
#if !defined(fm_bswap16_)
#  define fm_bswap16_         fm_bswap16__
#endif

#if !defined(fm_bswap32_)
#  define fm_bswap32_         fm_bswap32__
#endif

#if !defined(fm_bswap64_)
#  define fm_bswap64_         fm_bswap64__
#endif


/******************************************************************
 * Converters between native target platform byte order and big or
 * little endian byte order.
 ******************************************************************/


#if defined(__cplusplus)
extern "C" {
#endif

/*
 * host-to-le, le-to-host, host-to-be, be-to-host
 * for _aligned_ of sized types.
 */
#if defined(FM_BIG_ENDIAN)

static inline uint16_t fm_htobe16(uint16_t v) { return v; }
static inline uint16_t fm_htole16(uint16_t v) { return (uint16_t)fm_bswap16_(v); }
static inline uint16_t fm_betoh16(uint16_t v) { return (uint16_t)v; }
static inline uint16_t fm_letoh16(uint16_t v) { return (uint16_t)fm_bswap16_(v); }
static inline uint32_t fm_htobe32(uint32_t v) { return (uint32_t)v; }
static inline uint32_t fm_htole32(uint32_t v) { return (uint32_t)fm_bswap32_(v); }
static inline uint32_t fm_betoh32(uint32_t v) { return (uint32_t)v; }
static inline uint32_t fm_letoh32(uint32_t v) { return (uint32_t)fm_bswap32_(v); }
static inline uint64_t fm_htobe64(uint64_t v) { return (uint64_t)v; }
static inline uint64_t fm_htole64(uint64_t v) { return (uint64_t)fm_bswap64_(v); }
static inline uint64_t fm_betoh64(uint64_t v) { return (uint64_t)v; }
static inline uint64_t fm_letoh64(uint64_t v) { return (uint64_t)fm_bswap64_(v); }

#else

static inline uint16_t fm_betoh16(uint16_t v) { return (uint16_t)fm_bswap16_(v); }
static inline uint16_t fm_htole16(uint16_t v) { return (uint16_t)v; }
static inline uint16_t fm_htobe16(uint16_t v) { return (uint16_t)fm_bswap16_(v); }
static inline uint16_t fm_letoh16(uint16_t v) { return (uint16_t)v; }
static inline uint32_t fm_betoh32(uint32_t v) { return (uint32_t)fm_bswap32_(v); }
static inline uint32_t fm_htole32(uint32_t v) { return (uint32_t)v; }
static inline uint32_t fm_htobe32(uint32_t v) { return (uint32_t)fm_bswap32_(v); }
static inline uint32_t fm_letoh32(uint32_t v) { return (uint32_t)v; }
static inline uint64_t fm_htobe64(uint64_t v) { return (uint64_t)fm_bswap64_(v); }
static inline uint64_t fm_htole64(uint64_t v) { return (uint64_t)v; }
static inline uint64_t fm_betoh64(uint64_t v) { return (uint64_t)fm_bswap64_(v); }
static inline uint64_t fm_letoh64(uint64_t v) { return (uint64_t)v; }

#endif

#if defined(__cplusplus)
}
#endif

#endif /* FM_BYTEORDER_H */
