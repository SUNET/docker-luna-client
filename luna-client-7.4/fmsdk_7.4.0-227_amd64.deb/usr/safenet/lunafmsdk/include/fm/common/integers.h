/****************************************************************************
*
*  Filename:      ethsm/integers.h
*
*  Description:   integers.h for PTK and PPO compatiblity 
*
* Copyright © 2011-17 SafeNet.  All rights reserved.
*
* All rights reserved. This file contains information that is
* proprietary to SafeNet and may not be distributed
* or copied without written consent from SafeNet.
*/

#ifndef INC_INTEGERS_H
#   define INC_INTEGERS_H

#include <stdint.h>

#ifndef     TRUE
#   define     TRUE                1
#endif /* #ifndef     TRUE */
#ifndef     FALSE
#   define     FALSE               !TRUE
#endif /* #ifndef     FALSE */

#if !defined __cplusplus && !defined _BOOL && !defined bool
    typedef unsigned char bool;
#endif /* ifndef __cplusplus */

typedef int8_t int8;
typedef int16_t int16;
typedef int32_t int32;
typedef int64_t int64;

typedef uint8_t uint8;
typedef uint16_t uint16;
typedef uint32_t uint32;
typedef uint64_t uint64;

#endif /* INC_INTEGERS_H */
