/****************************************************************************
*
*  Filename:
*
*  Description:  Compatibility header for customers migrating from PPO.
*
*  Copyright © 2004-18 SafeNet. All rights reserved.

*  This file contains information that is proprietary to SafeNet and may not be
*  distributed or copied without written consent from SafeNet.
*
****************************************************************************/

#ifndef INC_FMHDR_COMPAT_H
#define INC_FMHDR_COMPAT_H

#include "../hsm/fmhdr.h"

#endif /* INC_FMHDR_COMPAT_H */
