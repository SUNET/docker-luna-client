/****************************************************************************
*
*  Filename:
*
*  Description:  Compatibility header for customers migrating from PPO.
*
*  Copyright © 2004-18 SafeNet. All rights reserved.

*  This file contains information that is proprietary to SafeNet and may not be
*  distributed or copied without written consent from SafeNet.
*
****************************************************************************/


#ifndef INC_FMSW_COMPAT_H
#define INC_FMSW_COMPAT_H

#include "../hsm/fmsw.h"

/* old names should match to the original Random Access dispatch method */
#define FMSW_RandomDispatchFn_t FMSW_DispatchFn_t
#define FMSW_RegisterDispatch FMSW_RegisterRandomDispatch

#endif /* INC_FMSW_COMPAT_H */
