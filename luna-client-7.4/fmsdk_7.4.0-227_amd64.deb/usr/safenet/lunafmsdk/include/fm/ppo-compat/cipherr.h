/****************************************************************************
*
*  Filename:
*
*  Description:  Compatibility header for customers migrating from PPO.
*
*  Copyright © 2004-18 SafeNet. All rights reserved.

*  This file contains information that is proprietary to SafeNet and may not be
*  distributed or copied without written consent from SafeNet.
*
****************************************************************************/

#ifndef INC_CIPHERR_COMPAT_H
#define INC_CIPHERR_COMPAT_H

#include "../hsm/fmciphobj.h"

#endif //INC_CIPHERR_COMPAT_H
