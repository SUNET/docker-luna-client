/****************************************************************************
*
*  Filename:
*
*  Description:  Compatibility header for customers migrating from PPO.
*
*  Copyright © 2004-18 SafeNet. All rights reserved.

*  This file contains information that is proprietary to SafeNet and may not be
*  distributed or copied without written consent from SafeNet.
*
****************************************************************************/
#ifndef INC_KEY_COMPAT_H
#define INC_KEY_COMPAT_H

#include "../hsm/key.h"

/*
 TBD: remove old code once new header is comoplete and compatablity
 items are added here

 #if 0 code below originally from prod/include/key.h
*/
#if 0

/*
	CRYPTOKI
	Copyright (c) ERACOM Pty. Ltd. Simon McMahon 1997.
*/
/*	Revision history
	Apr/97   V 1.0   Simon McMahon (sdm)
		Original.
*/

struct CtPubRsaKey {
	int isPub;		/* TRUE */
	unsigned int modSz;
	RSA_PUBLIC_KEY key;
};
typedef struct CtPubRsaKey CtPubRsaKey;

struct CtPriRsaKey {
	int isPub;		/* FALSE */
	int isXcrt;
	unsigned int modSz;
	RSA_PRIVATE_KEY_XCRT key;
};
typedef struct CtPriRsaKey CtPriRsaKey;

#endif // if 0
#endif /* ifndef INC_KEY_COMPAT_H */
