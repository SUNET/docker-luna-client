/****************************************************************************
*
*  Filename:
*
*  Description:  Compatibility header for customers migrating from PPO.
*
*  Copyright © 2004-18 SafeNet. All rights reserved.

*  This file contains information that is proprietary to SafeNet and may not be
*  distributed or copied without written consent from SafeNet.
*
****************************************************************************/

#ifndef INC_FMDEBUG_COMPAT_H
#define INC_FMDEBUG_COMPAT_H

#include "../hsm/fmdebug.h"

#   define dbg_init()
#   define dbg_final()
#   define dbg_str(str)  printf("%s", str)
#   define dbg_print(...)  printf(__VA_ARGS__)

#endif /* INC_FMDEBUG_COMPAT_H */
