/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

/*
 *	Generic Hash object.
 *	Wraps hashing algorithms into a common interface.
 */

#ifndef HASHOBJPUB_INCLUDED
#define HASHOBJPUB_INCLUDED

#include "../hsm/fmciphobj.h"

#endif /* HASHOBJPUB_INCLUDED */
