/****************************************************************************
*
*  Filename:
*
*  Description:  Compatibility header for customers migrating from PPO.
*
*  Copyright © 2004-18 SafeNet. All rights reserved.

*  This file contains information that is proprietary to SafeNet and may not be
*  distributed or copied without written consent from SafeNet.
*
*
****************************************************************************/

#ifndef INC_CSA8FM_COMPAT_H
#define INC_CSA8FM_COMPAT_H

#include "../hsm/csa8fm.h"

#endif /* INC_CSA8FM_COMPAT_H */
