/****************************************************************************
*
*  Filename:     csa8hiface.h
*
*  Description:  Compatibility header for customers migrating from PPO.
*
*  Copyright © 2004-18 SafeNet. All rights reserved.

*  This file contains information that is proprietary to SafeNet and may not be
*  distributed or copied without written consent from SafeNet.
*
*
****************************************************************************/
#ifndef INC_CSA8HIFACE_COMPAT_H
#define INC_CSA8HIFACE_COMPAT_H

#include "../hsm/fm_io_service.h"
#include "integers.h"

typedef FmMsgHandle HI_MsgHandle;

#endif /* INC_CSA8HIFACE_COMPAT_H */
