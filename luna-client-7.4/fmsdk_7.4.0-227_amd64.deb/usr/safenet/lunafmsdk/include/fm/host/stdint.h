/*
   ISO C99 stdint.h compatablity header for non-compliant OSes

   This file should reside in the search path after the compiler
   or stdlib supplied stdint.h on systems with C99 support.
*/
#if defined(OS_AIX) || defined(OS_SOLARIS)
#include <inttypes.h>
#else
#if defined(_MSC_VER)
// include Alexander Chemeris msinttypes version
#include "msinttypes/stdint.h"
#else
#include_next "stdint.h"
#endif
#endif

