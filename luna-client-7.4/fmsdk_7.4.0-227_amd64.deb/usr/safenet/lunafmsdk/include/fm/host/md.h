/****************************************************************************
*
*  Filename:      md.h
*
*  Description:  Header for MD API
*
* This file is protected by laws protecting trade secrets and confidential
* information, as well as copyright laws and international treaties.
* Copyright 2012-2013 SafeNet, Inc. All rights reserved.
*
* This file contains confidential and proprietary information of
* SafeNet, Inc. and its licensors and may not be
* copied (in any manner), distributed (by any means) or transferred
* without prior written consent from SafeNet, Inc.
*
****************************************************************************/

#ifndef INC_MD_H
#define INC_MD_H
#include "stdint.h"
#include "hsmstate.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <cryptoki.h>

/**
 * Set of possible MD_ function return codes.
 */
typedef enum
{
    /** Operation was completed successfully. */
    MDR_OK                          = 0,

    /** MD_Initialize() function was not called. */
    MDR_NOT_INITIALIZED             = 1,

    /** At least one of the parameter values is invalid. */
    MDR_INVALID_PARAMETER           = 3,

    /** The specified HSM index is greater than or equal to the total HSM
     * count. */
    MDR_INVALID_HSM_INDEX           = 4,

    /** The system or the HSM does not have enough resources to complete
     * operation. */
    MDR_INSUFFICIENT_RESOURCES      = 6,

    /** The operation was cancelled. This return value is currently unused. */
    MDR_OPERATION_CANCELLED         = 8,

    /** The HSM was restarted while the operation was in progress. */
    MDR_HSM_RESET                   = 9,

    /** The specified FM number is not available on the specified HSM. */
    MDR_FM_NOT_AVAILABLE            = 10,

    /** The operation could not be carried out, and the reason is unknown. */
    MDR_UNSUCCESSFUL                = 11,

    /** There is an internal error in the library. This error should never be
     * encountered. */
    MDR_INTERNAL_ERROR              = 12,

    /** The operation was not allowed to be carried out. */
    MDR_OPERATION_NOT_ALLOWED       = 13,

    /** The HSM is not available */
    MDR_HSM_NOT_AVAILABLE           = 14,

    /** No embedded P11 slot for the given host P11 slot */
    MDR_NO_EMBEDDED_SLOT            = 15

} MD_RV;

/**
 * MD library parameters used for MD_GetParameter() and MD_SetParameter()
 * function calls.
 */
typedef enum {
    /**
     * The recommended maximum buffer size, in number of bytes, for messages
     * that can be sent using the MD library. This value is informational only.
     * Whilst messages larger than this buffer size may be accepted by the
     * library, it is not recommended to do so.
     *
     * Different types of HSM access providers have different values for this
     * parameter. The value 0 means that there is no limit to the amount of
     * data that can be sent using this library.
     *
     * The value type is a uint32_t (4-byte integer value).
     *
     * This parameter is read only.
     */
    MDP_MAX_BUFFER_LENGTH = 1
} MD_Parameter_t;

/*
 * Set of possible HSM infoType values.
 * Different infoTypes require different pValue buffers types and sizes be provided
 * to MD_GetHsmInfo
 */
typedef enum {
    /**
     * Luna Slot Description
     * pValue: preallocated char * buffer. Result is always NULL-terminated
     *         and may be truncated.
     */
    MDI_HSM_DESCRIPTION = 1,
    /**
     * HSM Model Name
     * pValue: preallocated char * buffer. Result is always NULL-terminated
     *         and may be truncated.
     */
    MDI_HSM_MODEL,
    /**
     * HSM Label
     * pValue: preallocated char * buffer. Result is always NULL-terminated.
     *         and may be truncated.
     */
    MDI_HSM_LABEL,
    /**
     * HSM Serial Number
     * pValue: preallocated char * buffer. Result is always NULL-terminated.
     *     The serial number is at most 16 characters plus NULL terminator
     *     and will match the PKCS#11 serial number for the HSM's admin partition.
     */
    MDI_HSM_SERIAL_NUMBER,
    /**
     * HSM Firmware Version
     * pValue: preallocated char * buffer. Result is always NULL-terminated.
     */
    MDI_HSM_FIRMWARE_VERSION,
    /**
     * HSM Connection Status
     * pValue: null. The return value of MDR_HSM_NOT_AVAILABLE indicates the HSM
     * is not connected.  MDR_OK indicates it is.
     */
    MDI_HSM_CONNECTED,
    /**
     * Is there access to the FM Private functions of the HSM?
     * pValue: null. The return value of MDR_OPERATION_NOT_ALLOWED indicates the HSM
     * refuses FM Private commands.  MDR_OK indicates it supports them.
     */
    MDI_HSM_SUPPORTS_PRIV_CMDS

} MD_Info_t;

/* should match LunaMemBuf struct from Defs.h */
typedef struct
{
    uint8_t* pData;
    uint32_t length;
} MD_Buffer_t;

/**
 * Initialize the message dispatch library.
 *
 * Until this function is called, all other functions will return @c MDR_NOT_INITIALIZED.
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_Initialize(void);

/**
 * Finalize the message dispatch library. After this function returns, only the
 * MD_Initialize() function can be called. All other functions will return
 * @c MDR_NOT_INITIALIZED error code.
 */
void MD_Finalize(void);

/**
 * Retrieve the number of visible HSMs.
 *
 * @param pHsmCount
 *  Address of a variable to hold the result.
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_GetHsmCount(uint32_t* pHsmCount);

/**
 * Retrieve the state of the specified HSM.
 *
 * @param hsmIndex
 *  Zero based index of the HSM to query.
 *
 * @param pState
 *  Address of a variable to hold the result. This parameter must not be @c
 *  NULL.
 *
 * @param pErrorCode
 *  If the HSM is halted, this represents what caused the halt. This parameter
 *  may be @c NULL.
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_GetHsmState(uint32_t hsmIndex,
                     HsmState_t* pState,/* this should change */
                     uint32_t* pErrorCode);


/**
 * Retrieve information about the specified HSM.
 *
 * @param hsmIndex
 *  Zero based index of the HSM to query.
 *
 * @param infoType
 *   The type of information being queried.
 *
 * @param pValue
 *   The address of the buffer to hold the information value. The buffer must
 *   have been allocated by the caller. The size of the buffer is determined by
 *   the infoType that is being obtained.
 *
 * @param valueLen
 *   The length of the buffer pValue, in number of bytes.
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_GetHsmInfo(uint32_t hsmIndex,
                    MD_Info_t infoType,
                    void *pValue,
                    uint32_t valueLen );

/**
 * Retrieve the state of the specified HSM.
 *
 * @param hsmIndex
 *  Zero based index of the HSM to query.
 *
 * @param pName
 *    name of fm to query
 *
 * @param len
 *    len of name
 *
 * @param fmid
 *    fmid returned for name
 *
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_GetFmIdFromName(uint32_t hsmIndex, char *pName, uint32_t len, uint32_t *fmid);

/**
 * Reset the specified HSM.
 *
 * @param hsmIndex
 *  Zero based index of the HSM to reset.
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_ResetHsm(uint32_t hsmIndex);

/**
 * Send a request and receive the response.
 *
 * @param hsmIndex
 *  Zero based index of the HSM to send the request to.
 *
 * @param originatorId
 *  Id of the request originator. This Id is typically 0, only if the
 *  calling application is acting as a proxy would this be non-zero.
 *
 * @param fmNumber
 *  Identifier of the Functionality Module to send the request to.
 *
 * @param pReq
 *  Array of buffers to send. The final element in the array
 *  must be {NULL, 0}.
 *
 * @param msTimeOut
 *  Timeout in milliseconds to be used for the command.
 *  This is a timeout for the round trip transaction
 *  Setting this to 0 will use the system default timeout.
 *
 * @param pResp
 *  Array of buffers allocated to receive the response. The
 *  final element in the array must be {NULL, 0}.<br>
 *
 * @param pReceivedLen
 *  Address of variable to hold total number of bytes placed in the
 *  response buffers specified during the related MD_Send call. The
 *  buffers are filled in order until either the entire response is
 *  copied or the buffers overflow. The value of this parameter may be
 *  @c NULL.
 *
 * @param pFmStatus
 *  Address of variable to hold the status/return code from the
 *  Functionality Module which processed the request. The meaning of
 *  the value is defined by the FM. The value of this parameter may be
 *  @c NULL.
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_SendReceive(uint32_t hsmIndex,
                     uint32_t originatorId,
                     uint16_t fmNumber,
                     MD_Buffer_t* pReq,
                     uint32_t msTimeOut,
                     MD_Buffer_t* pResp,
                     uint32_t* pReceivedLen,
                     uint32_t* pFmStatus);

/**
 * Obtain the value of a system parameter. For a definition of parameters, and
 * the buffer types required for these parameters, see MD_Parameter_t
 * documentation.
 *
 * If the buffer length is not correct, MDR_INVALID_PARAMETER is returned.
 *
 * @param parameter
 *   The parameter whose value is being queried.
 *
 * @param pValue
 *   The address of the buffer to hold the parameter value. The buffer must
 *   have been allocated by the caller. The size of the buffer is determined by
 *   the parameter that is being obtained.
 *
 * @param valueLen
 *   The length of the buffer pValue, in number of bytes.
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_GetParameter(MD_Parameter_t parameter,
                      void *pValue,
                      uint32_t valueLen);



/**
 * For HSMs with FMs enabled this function translates host P11 slot ID to the
 * embedded Cryptoki library slot ID view of the same P11 slot. This way FM
 * developers can direct FM custom commands to the same embedded P11 slot as
 * they see in the host. This function should be used by the host ethsm only.
 *
 * @param hostP11SlotId
 *    Host side slot ID of a P11 slot
 *
 * @param pEmbeddedP11SlotId
 *    Pointer to a variable to hold the translated value.
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li MDR_NO_EMBEDDED_SLOT indicates the host slot does not have its peer
 *  @li in the HSM.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_GetEmbeddedSlotID(CK_SLOT_ID hostP11SlotId, CK_SLOT_ID *pEmbeddedP11SlotId);

/**
 * For HSMs with FMs enabled this function translates host P11 slot ID to the
 * HSM index. Using this function FM developers can direct FM custom commands
 * to a respective HSM. This function should be used by the host ethsm only.
 *
 * @param hostP11SlotId
 *    Host side slot ID of a P11 slot
 *
 * @param pHsmIndex
 *
 * @return
 *  @li MDR_OK for successful execution.
 *  @li MDR_HSM_NOT_AVAILABLE if a host slot does not have its peer in any HSM
 *  @li with FMs enabled.
 *  @li Any other MD_RV error code to indicate error condition.
 */
MD_RV MD_GetHsmIndexForSlot(CK_SLOT_ID hostP11SlotId, uint32_t *pHsmIndex);


/**
 * Utility macro to check if an hsm is present.
 *
 * @param hsmIndex
 *   Zero based index of the HSM to check.
 *
 * @return
 *   @li true if present
 *   @li false otherwise
 */
#define IS_HSM_PRESENT(hsmIndex) \
    ( MD_GetHsmInfo(hsmIndex, MDI_HSM_CONNECTED, NULL, NULL) == MDR_OK )


/**
 * Macros for endian conversion
 */
#if defined(IS_BIG_ENDIAN) || defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__

#define hton_short(x) (x)
#define ntoh_short(x) (x)
#define hton_long(x) (x)
#define ntoh_long(x) (x)

#else

#define hton_short(x) ((((x) >> 8)&0xffu) | (((x) << 8) & 0xff00u))
#define ntoh_short(x) hton_short(x)
#define hton_long(x) ((((x) >> 24)&0xffuL) | (((x) >> 8) & 0xff00uL) | (((x) << 8) & 0xff0000uL) | (((x) << 24) & 0xff000000uL))
#define ntoh_long(x) hton_long(x)

#endif

/**
 * Macros for FM identifers
 */
#ifndef FM_NUMBER_CUSTOM_FM
#define FM_NUMBER_CUSTOM_FM 0x100

#define FMID_ALLOCATE_HIGH  0xffff
#define FMID_ALLOCATE_NORM  0xfffe
#define FMID_ALLOCATE_LOW  0xfffd

#define FM_ID_CUSTOM_MIN 0x100
#define FM_ID_CUSTOM_MAX 0x7fff

#endif /* #ifdef IS_BIG_ENDIAN */

#ifdef __cplusplus
}
#endif

#endif
