/****************************************************************************
*
*  Filename:      mdStrings.h
*
*  Description:  Header for MD constant to string conversion routines
*
* This file is protected by laws protecting trade secrets and confidential
* information, as well as copyright laws and international treaties.
* Copyright 2012 SafeNet, Inc. All rights reserved.
*
* This file contains confidential and proprietary information of
* SafeNet, Inc. and its licensors and may not be
* copied (in any manner), distributed (by any means) or transferred
* without prior written consent from SafeNet, Inc.
*
****************************************************************************/

#ifndef MDSTRINGS_H_
#define MDSTRINGS_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Obtain a string representation of an MD_RV value.
 *
 * Any unknown value is returned as "UNKNOWN"
 *
 * @param mdRv
 *  The MD_RV value to be converted.
 *
 * @return
 *  Null terminated string representing the provided MD_RV value.
 */
const char* MD_RvAsString(MD_RV mdRv);

/**
 * Obtain a string representation of an MD_Parameter_t value.
 *
 * Any unknown value is returned as "UNKNOWN"
 *
 * @param mdParameter
 *  The MD_Parameter_t value to be converted.
 *
 * @return
 *  Null terminated string representing the provided MD_Parameter_t value.
 */
const char* MD_ParamAsString(MD_Parameter_t mdParameter);

/**
 * Obtain a string representation of an MD_Info_t value.
 *
 * Any unknown value is returned as "UNKNOWN"
 *
 * @param mdInfo
 *  The MD_Info_t value to be converted.
 *
 * @return
 *  Null terminated string representing the provided MD_Info_t value.
 */
const char* MD_InfoAsString(MD_Info_t mdInfo);

/**
 * Obtain a string representation of an HsmState_t value.
 *
 * Any unknown value is returned as "UNKNOWN"
 *
 * @param hsmState
 *  The HsmState_t value to be converted.
 *
 * @return
 *  Null terminated string representing the provided HsmState_t value.
 */
const char* MD_StateAsString(HsmState_t hsmState);

#ifdef __cplusplus
}
#endif

#endif /* MDSTRINGS_H_ */
