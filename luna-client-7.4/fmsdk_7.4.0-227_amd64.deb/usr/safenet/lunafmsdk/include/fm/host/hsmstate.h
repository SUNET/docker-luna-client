/**
 * @file This file contains information about the state of the HSM.
 *
 * Copyright (c) Safenet Inc
 * All Rights Reserved - Proprietary Information of Safenet Inc
 * Not to be Construed as a Published Work.
 */
#ifndef INC_HSMSTATE_H
#define INC_HSMSTATE_H

/**
 * Possible states that the HSM can be in.
 */
typedef enum {
    /**
     * HSM decommissioned
     */
    S_HSM_ERASED = 1,

     /** The HSM is not present. */
    S_HSM_DISCONNECTED = 2,

     /** The HSM is in tampered state. */
    S_TAMPER_RESPOND = 3,

    S_NORMAL_OPERATION = 0x8000uL

} HsmState_t;


#endif /* INC_HSMSTATE_H */
