/*
   ISO C99 inttypes.h compatablity header for non-compliant OSes

   This file should reside in the search path after the compiler
   or stdlib supplied stdint.h on systems with C99 support.
*/
#ifdef _MSC_VER
   // include Alexander Chemeris msinttypes version
   #include "msinttypes/inttypes.h"
#else
    #include_next "inttypes.h"
#endif

