/*****************************************************************************
*
*  Filename:     embedded_fm.h
*
*  Description: Runs a series of tests of FMs embedded into the LUNA f/w
*
* This file is protected by laws protecting trade secrets and confidential
* information, as well as copyright laws and international treaties.
*
*  Copyright (C) 2017 SafeNet, Inc. All rights reserved.
*
* All rights reserved. This file contains information that is
* proprietary to SafeNet, Inc. and may not be distributed
* or copied without written consent from SafeNet, Inc.
*
*****************************************************************************/
#ifndef EMBEDDED_FM_H
#define EMBEDDED_FM_H

#include <stdint.h>

#define FM_EMBEDDED_GET_SLOTS_IDS   1


typedef uint8_t OUID[12];

typedef struct {
   uint32_t slot_id;
   OUID   slot_ouid;
} slot_ids_t;

typedef struct {
	uint32_t max_num_ids;
} slot_ids_request_t;

typedef struct {
	uint32_t total_num_ids;
   /* Followed by array of slot_ids_t [total_num_ids] */
} slot_ids_reply_t;

#endif /* EMBEDDED_FM_H */
