#ifndef FMDISP_INCL
#define FMDISP_INCL

#include "../host/md.h"
#include "fmerr.h"
#include "integers.h"

#define FM_DispatchRequest( adapterInstance,  originatorID, \
                            request,  reply,  receivedLength, applicationStatus) \
          MD_SendReceive(adapterInstance,    \
                     originatorID,                      \
                     FM_NUMBER_CUSTOM_FM,                 \
                     (MD_Buffer_t*) request,            \
                     0,                                 \
                     (MD_Buffer_t*) reply,              \
                     receivedLength,                    \
                     applicationStatus)


#define FM_MESSAGE MD_Buffer_t
#define data  pData

#define FM_RV MD_RV
#define FM_OK MDR_OK

#endif
