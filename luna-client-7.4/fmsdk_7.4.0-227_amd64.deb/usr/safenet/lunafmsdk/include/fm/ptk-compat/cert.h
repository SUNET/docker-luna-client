/**
 * @file
 * ctcert related definitions
 */

/*
 * $Id: include/fm/ptk-compat/cert.h 1.1 2013/12/13 16:42:23EST tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 2001 ERACOM Pty. Ltd.
 * All Rights Reserved - Proprietary Information of ERACOM Pty. Ltd.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/cert.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:23EST $
 */

#ifndef CERT_H_INCLUDED
#define CERT_H_INCLUDED

#ifdef WIN32
#define strcasecmp _stricmp
#endif

#ifndef DEBUG
#define debug(x)
#define debugErr(x)
#define debugErrMalloc(x)
#else
#define debug(x) x
#define debugErr(x) x
#define debugErrMalloc(x) x
#endif

/** length of the CKA_ID attribute */
#define ID_LEN 20

/** CKA_SLOT_ID value to indicate that the slot ID is invalid/not specified */
#define SLOT_NOT_SPECIFIED CK_UNAVAILABLE_INFORMATION


/** OID of the Policy extension */
#define CERT_EXTN_OID_POLICY { 2, 5, 29, 32 }

/** OID of the Certificate Practice Statement extension */
#define CERT_EXTN_OID_CPS { 1, 3, 6, 1, 5, 5, 7, 2, 1 }

/** OID of the User Notice extension */
#define CERT_EXTN_OID_UNOTICE { 1, 3, 6, 1, 5, 5, 7, 2, 2 }

/** OID of the Key Usage extension */
#define CERT_EXTN_OID_KEYUSAGE { 2, 5, 29, 15 }

/** OID of the Basic Constraints extension */
#define CERT_EXTN_OID_BASICCONSTRAINTS { 2, 5, 29, 19 }


/** String name for Policy extension */
#define CERT_EXTN_STR_POLICY "certificatePolicies"

/** String name for Key Usage extension */
#define CERT_EXTN_STR_KEYUSAGE "keyUsage"

/** String for Key Usage extension critical value */
#define CERT_EXTN_CRITICAL "critical"

/** String for Key Usage noncritical value */
#define CERT_EXTN_NONCRITICAL "noncritical"

/** String name for Basic Constraints extension */
#define CERT_EXTN_STR_BASICCONSTRAINTS "basicConstraints"


/*
 * Note the '*' in the DN strings below indicates to the
 * parser that any amount of whitespace it permitted between
 * the DN component string and the '='. eg CN=, CN  = are
 * allowed.
 */

/** common name */
#define CERT_DN_CN_STR "CN*="

/** organisational unit */
#define CERT_DN_OU_STR "OU*="

/** organisation */
#define CERT_DN_O_STR "O*="

/** country */
#define CERT_DN_C_STR "C*="

/** The CN field will be populated with the adapter serial number */
#define CERT_DN_CN_SERIAL_STR "serialno"

/**
 * The CN field will be the adapter serial number followed by the key
 * usage count.
 */
#define CERT_DN_CN_UNIQUE_STR "unique"

/** Value of TRUE for DER encoding */
#define CERT_DER_BOOL_TRUE 0xFF

/** Value of FALSE for DER encoding */
#define CERT_DER_BOOL_FALSE 0

/** Max size of a certificate field */
#define CERT_FIELD_SIZE 1024

/** char to signify the start of a field value */
#define CERT_VALUE_START '{'

/** char to signify the end of a field value */
#define CERT_VALUE_END '}'

/** char to signify a space in a field value */
#define CERT_SPACE ' '

/** Max size of a extension field */
#define CERT_EXTN_SIZE 1024

/** Max # chars in an OID component */
#define CERT_OIDVAL_SIZE 10

/** Max # chars in a keyusage string */
#define CERT_KEYVAL_SIZE 17

/** Size of a KeyUsage bit string */
#define CERT_KEYUSAGE_BITSTRING 2

/** Max depth of an OID tree */
#define CERT_OID_TREE_DEPTH 30

/** oid extension token value */
#define CERT_OID_TOKEN "oid"

/** cps extension token value */
#define CERT_CPS_TOKEN "cps"

/** unnoticed extension token value */
#define CERT_UNOTICE_TOKEN "unotice"

/** Length of URI */
#define CERT_URI_LENGTH 200

/** Length of the User Notice */
#define CERT_UNOTICE_LENGTH 200

/** CPS delimiter */
#define CERT_CPS_DELIMITER '"'

/** User Notice delimiter */
#define CERT_UNOTICE_DELIMITER '"'

/** Max length of a Distinguished Name value */
#define CERT_DN_ELEMENT_LENGTH 128

/** Complete list of ASN1 printable characters */
#define ASN1_PRINTABLE_STRING \
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 '()+,-./:=?"

/** basic constraints ca field */
#define CERT_CA_TOKEN "ca"

/** basic constraints pathLenConstraint field */
#define CERT_PATHLENCONSTRAINT_TOKEN "pathLenConstraint"

/** Length of the ca filed value */
#define CERT_CA_LENGTH 4

/** Length of the pathLenConstraint filed value */
#define CERT_PATHLENCONSTRAINT_LENGTH 4 /* 9999 is the maximum in this case */




#ifndef NUL
#define NUL    '\0'
#endif    /* NUL */

/** Definition of an element in a certificate extension linked list */
struct cert_extn {

    /** extension type */
    unsigned char       type[CERT_FIELD_SIZE];

    /** extension value */
    unsigned char       value[CERT_FIELD_SIZE];

    /** reference to next extension */
    struct cert_extn    *next;
};


extern CK_BBOOL ProcessExtension(struct cert_extn* lst);
extern CK_BBOOL LoadCertAttributes(char* filename);
extern CK_RV GenIssuerDNStr(void), GenSubjectDNStr(CK_COUNT usage_cnt);
extern unsigned char* MyStrStr(unsigned char* haystack, unsigned char* needle);
extern CK_RV GetAdapterSerialNo(char* serial_no);
extern CK_BBOOL CheckPrintable(char* string, char** bad_chr);

#endif    /* CERT_H_INCLUDED */
