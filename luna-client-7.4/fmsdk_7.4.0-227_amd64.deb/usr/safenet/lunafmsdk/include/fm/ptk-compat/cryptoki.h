/****************************************************************************
*
*  Filename:     cryptoki.h
*
*  Description:  Compatibility header for customers migrating from PTK.
*
* This file is protected by laws protecting trade secrets and confidential
* information, as well as copyright laws and international treaties.
* Copyright 2013 SafeNet, Inc. All rights reserved.
*
* This file contains confidential and proprietary information of
* SafeNet, Inc. and its licensors and may not be
* copied (in any manner), distributed (by any means) or transferred
* without prior written consent from SafeNet, Inc.
*
****************************************************************************/
#ifndef PTK_CRYPTOKI_INCLUDED
#define PTK_CRYPTOKI_INCLUDED

#include "../host/cryptoki.h"

#endif /* PTK_CRYPTOKI_INCLUDED */
