/*
 * $Id: include/fm/ptk-compat/integers.h 1.1 2013/12/13 16:42:38GMT-05:00 tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 2009 SafeNet Inc.
 * All Rights Reserved - Proprietary Information of SafeNet Inc.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/integers.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:38GMT-05:00 $
 */
#ifndef INC_PTKCOMPAT_INTEGERS_H
#   define INC_PTKCOMPAT_INTEGERS_H

#include <../common/integers.h>

#endif /* INC_PTKCOMPAT_INTEGERS_H */
