/*
 * $Id: include/fm/ptk-compat/endyn.h 1.1 2013/12/13 16:42:32EST tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 2009 SafeNet Inc.
 * All Rights Reserved - Proprietary Information of SafeNet Inc.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/endyn.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:32EST $
 */
#ifndef INC_ENDYN_H
#define INC_ENDYN_H

#include <../hsm/fm.h>

#ifdef __cplusplus
extern "C" {
#endif

void BigEndianBuf(void * tgt, void * src, size_t len);

#ifdef __cplusplus
}
#endif

#endif /* INC_ENDYN_H */
