/*
 * $Id: include/fm/ptk-compat/ber.h 1.1 2013/12/13 16:42:20EST tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 1997,2001 ERACOM Pty. Ltd.
 * All Rights Reserved - Proprietary Information of ERACOM Pty. Ltd.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/ber.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:20EST $
 */
#ifndef	BER_INCLUDED
#define BER_INCLUDED

#ifndef NOIDENT
#pragma ident "@(#)RELEASE VERSION $Name:  $ ERACOM"
#endif

#include "field.h"
#include "bvalue.h"

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

/* use asn1err.h
#define BER_ERR_EOF	1
#define BER_ERR_IO	2
#define BER_ERR_ERROR	3
*/

/*
 * Global variables
 */
extern const char ** TagClass;
extern const char ** TagType;

typedef Value Oid;

/*
**	BER/DER Decoding functions
*/

int ExtractField(Field * f, Value ** pv);

int DecodeField(Field *f);
int DecodeLength(Field * f);
int DecodeTagAndLength(Field * f);

int DecodeByteChain(Field * f, unsigned long * val);

int DecodeInteger(Field * f, unsigned long * val);
int DecodeIntegerField(Field * f, unsigned long * val);


int DecodeOctet(Field * f, Value ** pv);
int DecodeOctetField(Field * f, Value ** pv);

int DecodeBitString(Field * f, Value ** pv);
int DecodeBitStringField(Field * f, Value ** pv);

int DecodeOid(Field * f, Oid ** pv);
int DecodeOidField(Field * f, Oid ** pv);


int DiscardField(Field * f);
int IsUniversalType(Field *f, unsigned int tagtype);

#define GetCurrentDepth(F) ((F)->depth)
/*#define NumRemainingBytes(F, D) (GetMaxLen(F, D) - GetCurLen(F, D))*/
size_t NumRemainingBytes( Field *f, unsigned int depth );
int CheckRecurseEnd(Field *f);

size_t GetCurLen(Field *f, unsigned int depth);
size_t GetMaxLen(Field *f, unsigned int depth);

/*
**	BER/DER Encoding functions
*/
int EncodeCopy(Field * f, const void * buf, size_t length);

int EncodeValue(struct Field * f, int vtype, const Value * v);

int EncodeTagAndLength(Field * f,
		  unsigned int tc,
		  int constructed,
		  unsigned int tag,
		  size_t length);
int EncodeTag(Field * f,
  		  unsigned int tc,
		  int constructed,
		  unsigned int tag);
int EncodeLength(Field * f, size_t contlen);
int EncodeByteChain(Field * f, unsigned long val);
int EncodeInteger(Field * f, unsigned long val);
int EncodeIntegerField(Field * f, unsigned long val);
int EncodeNumericField(Field * f, int tagtype, unsigned long val);
int EncodeOctet(Field * f, const unsigned char * buf, size_t length);
int EncodeOctetField(Field * f, int tagtype,
	const unsigned char * buf, size_t length);
int EncodeBitString(Field * f, const unsigned char * buf, size_t length);
int EncodeBitStringField(Field * f, const unsigned char * buf, size_t length);
int EncodeOid(Field * f, const Oid *oid);
int EncodeOidField(Field * f, const Oid *oid);
int EncodeNull(Field * f);
int EncodeNullField(Field * f);

/*
**	Dumping functions for debugging support
*/
extern int DDF_v_flag;	/* more verbose output */
int DecodeDumpField(struct Io * outIo, Field * f, int depth);

void dumpHexBufIo(struct Io * io, const unsigned char * ch, size_t len, unsigned int depth);
void dumpHexBuf(const unsigned char * ch, size_t len, unsigned int depth);
void IndentIo(struct Io * io, unsigned int depth);
void Indent(unsigned int depth);

void DumpOidIo(struct Io * io, const Oid * v, unsigned int depth);
void DumpOid(const Oid * v, unsigned int depth);
void DumpAsciiIo(struct Io * io, const Value * v, unsigned int depth);
void DumpAscii(const Value * v, unsigned int depth);
void DumpIntegerIo(struct Io * io, unsigned long val, unsigned int depth);
void DumpInteger(unsigned long val, unsigned int depth);
void DumpOctetIo(struct Io * io, const Value * v, unsigned int depth);
void DumpOctet(const Value * v, unsigned int depth);
void DumpBitStringIo(struct Io * io, const Value * v, unsigned int depth);
void DumpBitString(const Value * v, unsigned int depth);

#ifdef __cplusplus
}
#endif
#endif	/*BER_INCLUDED*/
