/*
 * $Id: include/fm/ptk-compat/field.h 1.1 2013/12/13 16:42:33EST tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 1997,2001 ERACOM Pty. Ltd.
 * All Rights Reserved - Proprietary Information of ERACOM Pty. Ltd.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/field.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:33EST $
 */
#ifndef	FIELD_INCLUDED
#define FIELD_INCLUDED

#ifndef NOIDENT
#pragma ident "@(#)RELEASE VERSION $Name:  $ ERACOM"
#endif

#include "bio.h"

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

#define BER_DEFAULT_DEPTH 16

typedef struct TagInfo {
	unsigned int tc;	/* tag class */
	unsigned int tag;
	int constructed;
} TagInfo;

typedef struct LengthInfo LengthInfo;

struct LengthInfo {
	size_t curlen;
	size_t maxlen;
	size_t eocCount;
};

#define FLD_NO_DECODE_SUB_ENCODINGS	0x01

struct Field {
	Io * io;
	TagInfo ti;
	size_t contlen;
	unsigned int depth;
	unsigned int maxDepth;
	int copy;
	int error;
	LengthInfo *stack;
	void * unused; /* unused */
	unsigned int flags;
	int (*f)(struct Field * f, int id,
		unsigned char * buf, unsigned int len);
};
typedef struct Field Field;

/*
**	Field constructors
*/
Field * NewField(void);
Field * NewFieldFromIo(struct Io * io);
void FreeField( Field * f );
int FieldOpenFile( Field ** pf, const char * ifname, unsigned int type);
int FieldOpenBuf( Field ** pf, unsigned char * buf, size_t length,
			   unsigned int type );
int FieldOpenBufCache( Field ** pf, unsigned char * buf, size_t length,
		unsigned int type);
int FieldOpenCount( Field ** pf );
int FieldField( Field ** pf, Field * ef );
int FieldTell(Field *f, size_t *pos);
int FieldSeek(Field *f, int pos);
int FieldGetPhysicalPos(Field *f, size_t *pos);

/* Field type constants */
#define ASN1_FT_ENCODER 1
#define ASN1_FT_DECODER 2

/* Field Seek type constants */
#define ASN1_SEEK_SET 1
#define ASN1_SEEK_CUR 2
#define ASN1_SEEK_END 3

#ifdef __cplusplus
}
#endif
#endif	/*FIELD_INCLUDED*/
