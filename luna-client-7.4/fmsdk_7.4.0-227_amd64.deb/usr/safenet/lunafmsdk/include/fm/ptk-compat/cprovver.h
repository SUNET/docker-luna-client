/*
 * $Id: include/fm/ptk-compat/cprovver.h 1.1 2013/12/13 16:42:25EST tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 2000,2001 ERACOM Pty. Ltd.
 * All Rights Reserved - Proprietary Information of ERACOM Pty. Ltd.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/cprovver.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:25EST $
 */
#ifndef INC_CPROVVER_H
#define INC_CPROVVER_H

/* NOTE: The way the constants are defined determines how the string
   CPROV_VERSION_STR is formed. If we define major as 0x2 and minor as 0x001uL,
   the string becomes "0x2.00x001uL". */
#ifdef DEMO
	#define CPROV_VER_MAJOR 1
	#define CPROV_VER_MINOR 0
	#define CPROV_VER_PATCH 0
#else
	#define CPROV_VER_MAJOR 4
	#define CPROV_VER_MINOR 2
	#define CPROV_VER_PATCH 0
#endif

#define TOSTR1(X) #X
#define TOSTR(X) TOSTR1(X)

#define CPROV_VERSION_STR TOSTR(CPROV_VER_MAJOR) "." TOSTR(CPROV_VER_MINOR) "." TOSTR(CPROV_VER_PATCH)

#define CPROV_COPYRIGHT_STR "Copyright (c) Safenet, Inc. 2009-2017"
#define CPROV_COPYRIGHT_STR2 "Copyright (c) Safenet, Inc. %s-2017"

/* Global Variables */
extern unsigned int CprovVersion, CprovRelease;

#endif /* INC_CPROVVER_H */
