
#ifndef CERTLIB_H_INCLUDED
#define CERTLIB_H_INCLUDED

#include "cryptoki.h"
#include "uicallbacks.h"

#ifdef __cplusplus
    extern "C" {        /* define as 'C' functions to prevent mangling */
#endif /* #ifdef __cplusplus */

/**
 * The list of callbacks that will be used by CERTLIB.
 */
typedef struct
{
    /**< To prompt for PIN using supplied string */
    UICB_PromptTokenPin_t  promptTokenPin;
    /**< To prompt for a 32-bit integer */
    UICB_PromptInt32_t     promptInt32;
    /**< To prompt for a string */
    UICB_PromptString_t    promptString;
    /**< To dislay a message */
    UICB_ShowMsg_t         showMsg;
} CERT_Callbacks_t;

/**
 * The list of possible signature hashing mechanisms.
 */
typedef enum
{
    CERT_SHA_1 = 0,         /**< Use the SHA1 hash */
    CERT_SHA_256,           /**< Use the SHA256 hash */
    CERT_SHA_384,           /**< Use the SHA384 hash */
    CERT_SHA_512,           /**< Use the SHA512 hash */
    CERT_SHA_224            /**< Use the SHA224 hash */
} CERT_SignHash_t;

/**
 * Set the callbacks for the library to use.
 *
 * @param pCallbacks
 *  Pointer to the structure containing the callbacks to set.
 */
CK_RV CERT_SetCallbacks(CERT_Callbacks_t* pCallbacks);


/**
 * Get the callbacks currently used by the library.
 *
 * @param pCallbacks
 *  Location to store the structure currently used by the library.
 */
CK_RV CERT_GetCallbacks(CERT_Callbacks_t* pCallbacks);


/**
 * @brief            Generate a signed X509 Certificate.
 *
 * This function uses the following callbacks: <br>@li showMsg
 *
 * @param hSession   [in] Handle to an open session on the slot where the
 *                   certificate will be generated.
 * @param hCaSession [in] Handle to an open session on the slot where the
 *                   certificate's signing key is stored. This can be the
 *                   same as hSession.
 * @param hDeriveObj [in] Handle to the public key or certificate request
 *                   object to generate the certificate from.
 * @param hPriObj    [in] Handle to the certificate's private key. This
 *                   key will sign the certificate.
 * @param pTpl       [in] The attribute template to give the newly
 *                   generated certificate. This MUST specifiy the
 *                   CKA_DERIVE attribute as TRUE. It also should contain
 *                   valid values for the CKA_ID, CKA_ISSUER_STR,
 *                   CKA_SUBJECT_STR and CKA_LABEL attributes.
 * @param tplSize    [in] The size of the attribute template specified by pTpl.
 * @param hashType   The signature hashing mechanism to use.
 * @param phCert     [out] Location to store the handle of the resulting
 *                   certificate.
 *
 * @pre              -
 * @post             A handle to a newly generated certificate is returned or
 *                   an error.
 */
CK_RV CERT_GenerateCertificate(CK_SESSION_HANDLE hSession,
                               CK_SESSION_HANDLE hCaSession,
                               CK_OBJECT_HANDLE hDeriveObj,
                               CK_OBJECT_HANDLE hPriObj,
                               CK_ATTRIBUTE* pTpl,
                               CK_SIZE tplSize,
                               CERT_SignHash_t hashType,
                               CK_OBJECT_HANDLE* phCert);

/**
 * @brief            Generate a PKCS#10 Certificate Request.
 *
 * This function uses the following callbacks: <br> @li showMsg
 *
 * @param hSession   [in] Handle to an open session. Note that this session
 *                   must be logged in.
 * @param hPubKeyObj [in] Handle to the public key object to be used with the
 *                   certificate.
 * @param hPriKeyObj [in] Handle to the private key corresponding to the
 *                   public key object
 * @param pTpl       [in] Template for the created certificate request. This
 *                   template is expected to contain at least the CKA_LABEL,
 *                   CKA_ID and CKA_SUBJECT attributes for the certificate. It
 *                   must also have the CKA_DERIVE attribute set to true.
 * @param tplSize    [in] Number of attributes contained in the reqTpl template.
 * @param hashType   The signature hashing mechanism to use.
 * @param phCertReq  [out] Location to store the handle of the generated
 *                   certificate request.
 *
 * @pre              -
 * @post             The handle to the generated certificate request is
 *                   returned, or an error.
 */
CK_RV CERT_GenerateCertificateRequest(CK_SESSION_HANDLE hSession,
                                      CK_OBJECT_HANDLE hPubKeyObj,
                                      CK_OBJECT_HANDLE hPriKeyObj,
                                      CK_ATTRIBUTE* pTpl,
                                      CK_SIZE tplSize,
                                      CERT_SignHash_t hashType,
                                      CK_OBJECT_HANDLE_PTR phCertRequest);

/**
 * Import a PEM encoded certificate file.
 *
 * This function uses the following callbacks:
 * @li showMsg
 *
 * @param hSession
 *  Handle to an open session.
 *
 * @param pszLabel
 *  Label to give the imported key.
 *
 * @param pszFileName
 *  Name of the file that contains the PEM encoded certificate.
 *
 * @param phCert
 *  Location to store the handle of the imported certificate.
 */
CK_RV CERT_ImportCertificate(CK_SESSION_HANDLE hSession,
                             const char* pszLabel,
                             const char* pszFileName,
                             CK_OBJECT_HANDLE* phCert);


/**
 * Export a specified certificate to PEM encoded certificate file.
 *
 * This function uses the following callbacks:
 * @li showMsg
 *
 * @param hSession
 *  Handle to an open session.
 *
 * @param hCert
 *  Handle to the certificate object to be exported.
 *
 * @param objClass
 *  The class of the object being exported. Only CKO_CERTIFICATE and
 *  CKO_CERTIFICATE_REQUEST are valid values.
 *
 * @param pszFileName
 *  Name of the file to export PEM encoded certificate to.
 */
CK_RV CERT_ExportCertificate(CK_SESSION_HANDLE hSession,
                             CK_OBJECT_HANDLE hCert,
                             CK_OBJECT_CLASS objClass,
                             const char* pszFileName);


/**
 * Set the CKA_TRUSTED attribute on a given certificate.
 *
 * This function uses the following callbacks:
 * @li showMsg
 * @li promptTokenPin
 *
 * @param hSession
 *  Handle to an open SO RW session. If the SO is not logged in, the SO pin
 *  will be prompted for using the promptTokenPin callback.
 *
 * @param hCert
 *  Handle to the certificate object to be set to trusted.
 */
CK_RV CERT_SetTrusted(CK_SESSION_HANDLE hSession,
                      CK_OBJECT_HANDLE hCert);

/**
 * Set the start and end dates based on a given duration.
 *
 * @param pszCertDuration
 *  Duration for which certificate will be valid, expressed as an alphanumeric
 *  string in the following format :
 *     {0-9}*{M|H|D|Y} Where M = Minutes, H = Hours, D = Days, Y = Years
 *
 * @param ppCertStart
 *  Location to hold certificate start date, which will be expressed in the
 *  following format : YYYYMMDDHHmmss. The length of the buffer should be 15
 *  bytes with the 15th byte being null. If this value is passed in as NULL,
 *  it will be set to the current time, with memory being allocated inside
 *  this function. The memory must be released by the caller, using free().
 *
 *  It is valid to set this to any time in the future. The certEnd return
 *  value will be determined based on this value and the certDuration.
 *
 * @param ppCertEnd
 *  Location to hold the certificate end date, which will be expressed in the
 *  following format : YYYYMMDDHHmmss. The memory for the buffer will be
 *  allocated inside this function and must be released by the caller,
 *  using free().
 *
 */
CK_RV CERT_SetCertDuration(const char* pszCertDuration,
                           char** ppCertStart,
                           char** ppCertEnd);


/**
 * Validate the given time, converting to GMT if necessary, and return
 * the validated time in the supplied pointer.
 *
 * @param pszCertTime
 *  Time to validate, in the following format : YYYYMMDDHHmmss[z|Z].
 *
 * @param ppCertTimeValid.
 *  The validated time converted, if necessary, to GMT. Memory for the
 *  buffer is allocated inside this function and must be freed, using free(),
 *  by the caller.
 */
CK_RV CERT_SetCertTime(const char* pszCertTime,
                       char **ppCertTimeValid);

#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

#endif
