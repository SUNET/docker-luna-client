/*
 * $Id: include/fm/ptk-compat/bio.h 1.1 2013/12/13 16:42:21EST tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 1997,2001 ERACOM Pty. Ltd.
 * All Rights Reserved - Proprietary Information of ERACOM Pty. Ltd.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/bio.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:21EST $
 */
#ifndef	BIO_INCLUDED
#define BIO_INCLUDED

#ifndef NOIDENT
#pragma ident "@(#)RELEASE VERSION $Name:  $ ERACOM"
#endif

#include <integers.h>

#ifdef __cplusplus
extern "C" {		/* define as 'C' functions to prevent mangling */
#endif

struct Io {
	void * data;

	int (*Free)(void * data);

	int (*Getch)(struct Io * io, unsigned char *ch);
	int (*Read)(struct Io * io, unsigned char * buf, size_t len, size_t *br);

	int (*Putch)(struct Io * io, unsigned char ch);
	int (*Puts)(struct Io * io, const char * str);
	int (*Write)(struct Io * io, const unsigned char * buf, size_t len, size_t *bw);

	int (*Seek)(struct Io * io, size_t len);
	int (*Tell)(struct Io * io, size_t * plen);
	int (*Ungetc)(struct Io * io, unsigned char c);
	size_t (*PosLogToPhys)(struct Io * io, size_t pos);
	size_t (*PosPhysToLog)(struct Io * io, size_t pos);

	int (*IsEof)(struct Io * io);
};
typedef struct Io Io;


Io *
NewIo(void * data, int (*Free)(void * data),
	   int (* getch)(struct Io * io, unsigned char *ch),
	   int (*putch)(struct Io * io, unsigned char ch),
	   int (*read)(struct Io * io, unsigned char * buf, size_t len, size_t *br),
	   int (*write)(struct Io * io, const unsigned char * buf, size_t len, size_t *bw),
	   int (*Seek)(struct Io * io, size_t len),
	   int (*Tell)(struct Io * io, size_t * plen),
	   int (*Ungetc)(struct Io * io, unsigned char c),
	   size_t (*PosLogToPhys)(struct Io * io, size_t pos),
	   size_t (*PosPhysToLog)(struct Io * io, size_t pos),
	   int (*iseof)(struct Io * io) );

void FreeIo(Io * io);

int IoOpenBufNull( Io ** pio );
int IoOpenBufAsnCache( Io ** pio, unsigned char * buf, size_t length,
		unsigned long flags );
int IoOpenBufAsn(struct Io ** pio, unsigned char * buf, size_t length,
			   unsigned long flags );
int IoOpenFile( Io ** pio, const char * ifname, const char * mode);
int IoOpenBuf( Io ** pio, unsigned char * buf, size_t length,
		unsigned long flags );

#define BIO_CRLF  (1 << 0)
#define BIO_READ  (1 << 1)
#define BIO_WRITE (1 << 2)

#define BIO_ERR_ERROR 1

int printfIo( Io * out, char * fmt, ... );
int ioGets(Io *io, char * buf, size_t len);

#ifdef __cplusplus
}
#endif
#endif	/*BIO_INCLUDED*/
