/*
 * $Id: include/fm/ptk-compat/b64.h 1.1 2013/12/13 16:42:20EST tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 2000,2001 ERACOM Pty. Ltd.
 * All Rights Reserved - Proprietary Information of ERACOM Pty. Ltd.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/b64.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:20EST $
 */

#ifndef INC_B64_H
#define INC_B64_H

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

/*
**	Internal Base64 encoder / decoder context.
*/
typedef struct B64CTX {
	struct Io * io;			/* IO stream */
	unsigned char holding[4];/* B64 buffer */
	unsigned int held;		/* number of bytes in 'holding' buffer */
	unsigned int outLen;	/* used to output nl every 76 chars */
} B64CTX;

/*
**	Description
**		Tell caller if a buffer contains a valid base 64 encoding.
**
**	Return
**
**		TRUE (1)
**		Buffer contains valid base64 encoding.
**
**		FALSE (0)
**		Buffer does not contain a valid Base 64 encoding.
*/
int isB64(unsigned char * buf, unsigned int length);

/*
**	Init the base 64 encoder.
*/
int BinToB64Init(B64CTX * b64ctx, struct Io * ioOut);
/*
**	Encode a buffer of binary data into base 64
*/
int BinToB64Upd(B64CTX * b64ctx, unsigned char * buf, unsigned int length);
int BinToB64UpdIo(B64CTX * b64ctx, Io * ioIn);
/*
**	Finish off a base 64 encoding.
*/
int BinToB64Final(B64CTX * b64ctx);

/*
**	Init the Base 64 decoder.
*/
int B64ToBinInit(B64CTX * b64ctx, Io * ioOut);
/*
**	dEcode a buffer of binary from base64
*/
int B64ToBinUpd(B64CTX * b64ctx, unsigned char * buf, unsigned int length);
int B64ToBinUpdIo(B64CTX * b64ctx, Io * ioIn);
/*
**	Finish off a base 64 decoding.
*/
int B64ToBinFinal(B64CTX * b64ctx);

#ifdef __cplusplus
}
#endif
#endif /* ifndef INC_B64_H */
