/*
 * $Id: include/fm/ptk-compat/ctalias.h 1.1 2013/12/13 16:42:27EST tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 2009 SafeNet Inc.
 * All Rights Reserved - Proprietary Information of SafeNet Inc.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/ctalias.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:27EST $
 */

/*
**	Structure member alias list to get rid of pointless type dependancy
*/
#ifndef CTALIAS_INCLUDED
#define CTALIAS_INCLUDED

#include <cryptoki.h>

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE (!FALSE)
#endif

#define CK_VOID void
#define CK_COUNT CK_ULONG
#define CK_SIZE CK_ULONG
#define CK_SIZE_PTR CK_ULONG_PTR
#define CK_COUNT_PTR CK_ULONG_PTR
#define CK_NUMERIC  CK_COUNT
#define CK_NUMERIC_PTR  CK_COUNT_PTR

#define CK_SERIAL_NUMBER_SIZE 16

/* Non standard definitions */
#define CK_MANUFACTURER_SIZE 32
#define CK_SERIAL_NUMBER_SIZE 16
#define CK_TIME_SIZE 16
#define CK_LIB_DESC_SIZE 32
#define CK_SLOT_DESCRIPTION_SIZE 64
#define CK_SLOT_MANUFACTURER_SIZE 32
#define CK_MAX_PIN_LEN 255
#define CK_TOKEN_LABEL_SIZE 32
#define CK_TOKEN_MANUFACTURER_SIZE 32
#define CK_TOKEN_MODEL_SIZE 16
#define CK_TOKEN_SERIAL_NUMBER_SIZE 16
#define CK_TOKEN_TIME_SIZE 16
#define CK_MAX_PBE_IV_SIZE	8
/* AES and ARIA are the largest with a 16 byte block size */
#define CK_MAX_PAD_SIZE 16
/* end Non standard definitions */




#define valueLen ulValueLen

#if 0

#define parameterLen ulParameterLen 
#define usMaxSessionCount maxSessionCount
#define ulMaxSessionCount maxSessionCount
#define usSessionCount sessionCount
#define ulSessionCount sessionCount
#define usMaxRwSessionCount maxRwSessionCount
#define ulMaxRwSessionCount maxRwSessionCount
#define usRwSessionCount rwSessionCount
#define ulRwSessionCount rwSessionCount
#define usMaxPinLen maxPinLen
#define ulMaxPinLen maxPinLen
#define usMinPinLen minPinLen
#define ulMinPinLen minPinLen
#define ulTotalPublicMemory totalPublicMemory
#define ulFreePublicMemory freePublicMemory
#define ulTotalPrivateMemory totalPrivateMemory
#define ulFreePrivateMemory freePrivateMemory
#define usDeviceError deviceError
#define ulDeviceError deviceError
#define ulMinKeySize minKeySize
#define ulMaxKeySize maxKeySize
#define usParameterLen parameterLen
#define usEffectiveBits effectiveBits
#define ulEffectiveBits effectiveBits
#define ulPasswordLen passwordLen
#define ulSaltLen saltLen
#define ulIteration iteration
#define ulXLen XLen
#define ulSourceDataLen sourceDataLen
#define ulClientRandomLen clientRandomLen
#define ulServerRandomLen serverRandomLen
#define ulMacSizeInBits macSizeInBits
#define ulKeySizeInBits keySizeInBits
#define ulIVSizeInBits IVSizeInBits
#define ulLen len
#define ulMacLength macLength
#define ulWordsize wordsize
#define ulRounds rounds
#define ulIvLen ivLen
#endif

#endif
