/*
 * $Id: include/fm/ptk-compat/getOption.h 1.1 2013/12/13 16:42:34EST tlowe Exp  $
 * $Author: tlowe $
 *
 * Copyright (c) 2000,2001 ERACOM Pty. Ltd.
 * All Rights Reserved - Proprietary Information of ERACOM Pty. Ltd.
 * Not to be Construed as a Published Work.
 *
 * $Source: include/fm/ptk-compat/getOption.h $
 * $Revision: 1.1 $
 * $Date: 2013/12/13 16:42:34EST $
 */

#ifndef _GETOPTION_H
#define _GETOPTION_H 1

enum optionType {
	opt_end = 0,	/* Terminates loops */
	opt_help,		/* Calls usage() (provided by program) then displays options and returns 1 */
	opt_boolean,	/* sets variable to 1 or 0. Accepts no argument. */
	opt_character,	/* returns char. Error if no arg or more than 1 char. Interprets \t\v\f\r\n\b */
	opt_integer,	/* Error if no arg, non-integer argument or out of range */
	opt_string,		/* Error if no arg */
	opt_filename,	/* Error if no arg */
	opt_real,		/* Error if no arg, non-numeric or out of range */
	opt_double, 	/* Error if no arg, non-numeric or out of range */
	opt_long	    /* Error if no arg, non-long argument or out of range */
};

struct getOption_s {
	enum optionType	optionType;		/* as above */
	char 			*optionName;	/* long option name e.g. slot-num */
	char 			optionLetter;	/* single letter option e.g. s */
	void			*optionValue;	/* return result e.g. &slotNum where int slotNUm;*/
	char			*optionString; 	/* put help here on input; get returned string on output; NULL to hide the option in 'help' */
	char			*optionLabel;	/* what to call the parameter in 'help' */
};

typedef struct getOption_s getOption_t;

getOption_t * getOption(int *argc, char **argv, getOption_t *options);

/* provided by getOption: */
extern void getOptionPrintHelp(char *progName, getOption_t *options);
extern void getOptionprintShortOptionUsage(char *progName, getOption_t *options);

/* to be provided by application: */
extern void printArgsAndShortDescription(char * progName);
extern void printExtraHelp(char * progName);

#ifdef WIN32
#define DIRSEP '\\'
#else
#define DIRSEP '/'
#endif

#endif /* _GETOPTION_H */
