/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#ifndef INC_MKFMHEADER_H
#define INC_MKFMHEADER_H

#include "fmhdr.h"

/*
 * FM Header population macro.
 *
 * The header itself isstored as a struct that can be read by the loader,
 * and in a custom elf section so it can be accessed and modified by FM tools.
 *
 *TODO: define full header and macro for Luna in fmhdr.h and populate here.
 *  Can a bunch of the content be hidden inside a lib or separated into two structs,
 *  a public one populated by the FM developer with the public macro here, and
 *  a private one populated by libfm ?
 */
#define DEFINE_FM_HEADER(FM_NUMBER,									\
        FM_VERSION,													\
        FM_SERIAL_NO,												\
        MANUFACTURER_ID,											\
        PRODUCT_ID)	                                                \
                                                                    \
const FM_Header_t FM_HEADER_SYMBOL __attribute__ ((section(".fm.header"))) __attribute__((visibility("protected"))) = { \
        .number = FM_NUMBER,                                         \
        .version = FM_VERSION,                                       \
        .serialNo = FM_SERIAL_NO,                                    \
        .manufacturerId = MANUFACTURER_ID,                           \
        .productId = PRODUCT_ID,                                     \
        .productionDate = __DATE__ "-" __TIME__                      \
}

extern const FM_Header_t FM_HEADER_SYMBOL __attribute__ ((section(".fm.header"))) __attribute__((visibility("protected")));

static inline FmNumber_t GetFMID(void) { return FM_HEADER_SYMBOL.number; }
static inline const char * GetFMName(void) { return FM_HEADER_SYMBOL.productId; }

#endif /* INC_MKFMHEADER_H */
