/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#ifndef INC_PRIVILEGE_H
#define INC_PRIVILEGE_H

#include <cryptoki.h>
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file
 *  privilege - Allows elevatation of privilege level to circumvent
 *              builtin security mechanisms on PKCS#11 objects.
 */

/**
 * Normal privilege level
 */
#define PRIVILEGE_NORMAL    0

/**
 * Elevate privilege level allowing override of sensitive attribute and
 * key usage
 */
#define PRIVILEGE_OVERRIDE  1

/**
 * This function is an ERACOM extension to PKCS#11. It can be used to set
 * the privilege level of the caller to the specified value, if the caller
 * has access to the function. It has a global effect on all
 * sessions/applications.
 *
 * @param level
 *  Required privilege level
 */
CK_RV CK_ENTRY CT_SetPrivilegeLevel( int level );

/**
 * This function is an ERACOM extension to PKCS#11. It can be used to get
 * the privilege level of the caller.
 *
 * @return Required privilege level
 */
int CK_ENTRY CT_GetPrivilegeLevel( void );

#if defined (INSAM) || defined (OS2) || defined(WIN32)
typedef CK_RV (CK_ENTRY *CK_CT_SetPrivilegeLevel)( int level );
typedef int (CK_ENTRY *CK_CT_GetPrivilegeLevel)( void );
#else
typedef CK_RV CK_ENTRY (*CK_CT_SetPrivilegeLevel)( int level );
typedef int CK_ENTRY (*CK_CT_GetPrivilegeLevel)( void );
#endif

#ifdef __cplusplus
}
#endif

#endif /* INC_PRIVILEGE_H */
