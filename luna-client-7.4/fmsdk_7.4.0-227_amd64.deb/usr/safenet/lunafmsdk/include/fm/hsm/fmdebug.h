/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

/** @file
 *  FMDEBUG - Provides debug functions to FM writers.
 */

#ifndef INC_FMDEBUG_H
#define INC_FMDEBUG_H

#include <string.h>
#include <stdio.h>


/* ------------------------ DEBUG FUNCTION PROTOTYPES -------------------- */

/**
 * This function dumps the hex values of each byte in a buffer
 *
 * @param desc
 *  Describes the buffer being dumped. This string is dumped immediately before
 *  the buffer.
 *
 * @param data
 *  This is a pointer to the buffer to be dumped.
 *
 * @param len
 *  The length of the buffer to be dumped.
 */
void dump(char *desc, unsigned char *data, short len);


/* -------------------------- DEBUG INFORMATION MACROS ------------------- */
#ifdef DEBUG

#   define debug(x) x

#else /* NOT DEBUG */

#   define debug(x)

#endif /* DEBUG */

#endif /* INC_FMDEBUG_H */
