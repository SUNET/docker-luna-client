/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#ifndef INC_FMAPPID_H
#define INC_FMAPPID_H
#include <stdint.h>

#define FM_DEFAULT_PID UINT32_MAX
#define FM_DEFAULT_OID UINT32_MAX

/**
 * This function returns the app id recorded in the current request originated
 * from the host side.
 *
 * @return uint64_t
 *     The appid of the application which originated the request.
 */
uint64_t FM_GetCurrentAppId (void);

/**
 * This function overrides the app id recorded in the current request originated
 * from the host side. If there is no active request the function does nothing.
 *
 * @param appid
 *     The new app id to be recorded in the request.
 */
void FM_SetCurrentAppId (uint64_t appid);

#endif /* INC_FMAPPID_H */
