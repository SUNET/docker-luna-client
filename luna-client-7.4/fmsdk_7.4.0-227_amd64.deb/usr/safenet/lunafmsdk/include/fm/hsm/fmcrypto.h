/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#ifndef INCL_FMCRYPTO
#define INCL_FMCRYPTO

#include "cryptoki.h"

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

#define FMCE_MAX_RSA_BITS  (8*1024)
#define FMCE_MAX_DSA_BITS  (3*1024)
#define FMCE_MAX_SEC_BITS  4096
#define FMCE_DSA_SIG_LEN   40

typedef struct raw_key_component_s {
   CK_BYTE_PTR  val;
   CK_ULONG     len;
} raw_key_component_t;

typedef struct FMCE_RAW_SYM_KEY_S {
   /* Sym key value */
   raw_key_component_t  sym_key;

} FMCE_RAW_SYM_KEY;

typedef struct FMCE_RAW_RSA_PUBLIC_KEY_S {
   /* Modulus */
   raw_key_component_t mod;

   /* Public exponent */
   raw_key_component_t pub;
   
} FMCE_RAW_RSA_PUBLIC_KEY;

typedef struct FMCE_RAW_RSA_PRIVATE_KEY_S {
   /* Modulus */
   raw_key_component_t  mod;

   /* Public exponent */
   raw_key_component_t  pub;

   /* Private exponent */
   raw_key_component_t  pri;

   /* prime_1, p */
   raw_key_component_t  p;

   /* prime_2, q */
   raw_key_component_t  q;

   /* exponent_1, for p */
   raw_key_component_t  dmp1;

   /* exponent_2, for q */
   raw_key_component_t  dmq1;

   /* coefficient, inv(q) mod p */
   raw_key_component_t  iqmp;

} FMCE_RAW_RSA_PRIVATE_KEY;

typedef struct FMCE_RAW_DSA_PUBLIC_KEY_S {
   /* Prime */
   raw_key_component_t  p;

   /* Subprime */
   raw_key_component_t  q;

   /* Generator */
   raw_key_component_t  g;

   /* Public key */
   raw_key_component_t  pub_key;

} FMCE_RAW_DSA_PUBLIC_KEY;

typedef struct FMCE_RAW_DSA_PRIVATE_KEY_S {
   /* Prime */
   raw_key_component_t  p;

   /* Subprime */
   raw_key_component_t  q;

   /* Generator */
   raw_key_component_t  g;

   /* Private key */
   raw_key_component_t  pri_key;

} FMCE_RAW_DSA_PRIVATE_KEY;

typedef struct FMCE_RAW_DSA_DOMAIN_PARAMS_S {
   /* Prime */
   raw_key_component_t  p;

   /* Subprime */
   raw_key_component_t  q;

   /* Generator */
   raw_key_component_t  g;

} FMCE_RAW_DSA_DOMAIN_PARAMS;

typedef struct FMCE_RAW_EC_PUBLIC_KEY_S {
   raw_key_component_t  ec_param;
   raw_key_component_t  pub_key;

} FMCE_RAW_EC_PUBLIC_KEY;

typedef struct FMCE_RAW_EC_PRIVATE_KEY_S {
   raw_key_component_t  ec_param;
   raw_key_component_t  pub_key;
   raw_key_component_t  pri_key;

} FMCE_RAW_EC_PRIVATE_KEY;


typedef struct FMCE_RAW_KCDSA_PUBLIC_KEY_S {
   raw_key_component_t  p;
   raw_key_component_t  q;
   raw_key_component_t  g;
   raw_key_component_t  pub_key;

} FMCE_RAW_KCDSA_PUBLIC_KEY; 

typedef struct FMCE_RAW_KCDSA_PRIVATE_KEY_S {
   raw_key_component_t  p;
   raw_key_component_t  q;
   raw_key_component_t  g;
   raw_key_component_t  pri_key;

} FMCE_RAW_KCDSA_PRIVATE_KEY; 


typedef struct FMCE_RAW_DH_PUBLIC_KEY_S {
   raw_key_component_t  p;
   raw_key_component_t  g;
   raw_key_component_t  pub_key;

} FMCE_RAW_DH_PUBLIC_KEY;

typedef struct FMCE_RAW_DH_PRIVATE_KEY_S {
   raw_key_component_t  p;
   raw_key_component_t  g;
   raw_key_component_t  pri_key;
   CK_ULONG             val_bits;

} FMCE_RAW_DH_PRIVATE_KEY;

typedef struct FMCE_RAW_X9_42_DH_PUBLIC_KEY_S {
   raw_key_component_t  p;
   raw_key_component_t  q;
   raw_key_component_t  g;
   raw_key_component_t  pub_key;

} FMCE_RAW_X9_42_DH_PUBLIC_KEY;

typedef struct FMCE_RAW_X9_42_DH_PRIVATE_KEY_S {
   raw_key_component_t  p;
   raw_key_component_t  q;
   raw_key_component_t  g;
   raw_key_component_t  pri_key;

} FMCE_RAW_X9_42_DH_PRIVATE_KEY;

/*
 *  * Combination of all possible raw key types
 */
typedef struct FMCE_KEY {

   CK_OBJECT_CLASS            key_class;
   CK_KEY_TYPE                key_type;

   union {
      FMCE_RAW_SYM_KEY              sym;
      FMCE_RAW_RSA_PUBLIC_KEY       rsa_pub;
      FMCE_RAW_RSA_PRIVATE_KEY      rsa_pri;
      FMCE_RAW_DSA_PUBLIC_KEY       dsa_pub;
      FMCE_RAW_DSA_PRIVATE_KEY      dsa_pri;
      FMCE_RAW_DSA_DOMAIN_PARAMS    dsa_dom;
      FMCE_RAW_EC_PUBLIC_KEY        ec_pub;
      FMCE_RAW_EC_PRIVATE_KEY       ec_pri;
      FMCE_RAW_KCDSA_PUBLIC_KEY     kcdsa_pub;
      FMCE_RAW_KCDSA_PRIVATE_KEY    kcdsa_pri;
      FMCE_RAW_DH_PUBLIC_KEY        dh_pub;
      FMCE_RAW_DH_PRIVATE_KEY       dh_pri;
      FMCE_RAW_X9_42_DH_PUBLIC_KEY  x9_42_dh_pub;
      FMCE_RAW_X9_42_DH_PRIVATE_KEY x9_42_dh_pri;
   };

} FMCE_KEY;

typedef FMCE_KEY * FMCE_KEY_PTR;

typedef  CK_ULONG FMCE_HANDLE;
typedef  FMCE_HANDLE * FMCE_HANDLE_PTR;

///////////////// Crypto functions ////////

// single part Sign operation
extern CK_RV FMCE_Sign(
               CK_MECHANISM_PTR pMech,  // IN: mechanism type and parameters
               FMCE_KEY_PTR     pKey,   // IN: key value

               CK_ULONG         ulDataInLen,  // len of data to sign
               CK_BYTE_PTR      pDataIn,      // IN: data to sign
               CK_ULONG_PTR     pulSigOutLen, // IN: len of sig buf OUT: len of signature
               CK_BYTE_PTR      pSigOut       // OUT: signature
                      );


// single part verify operation
extern CK_RV FMCE_Verify(
               CK_MECHANISM_PTR pMech,  // IN: mechanism type and parameters
               FMCE_KEY_PTR     pKey,   // IN: key value

               CK_ULONG         ulDataInLen,  // len of signed data 
               CK_BYTE_PTR      pDataIn,      // IN: signed data
               CK_ULONG         ulSigLen,     // len of signature
               CK_BYTE_PTR      pSig);        // IN: signature

// single part encrypt operation
extern CK_RV FMCE_Encrypt(
               CK_MECHANISM_PTR pMech,  // mechanism type and parameters
               FMCE_KEY_PTR     pKey,   // key value

               CK_ULONG         ulDataInLen,
               CK_BYTE_PTR      pDataIn,
               CK_ULONG_PTR     pulOutLen,
               CK_BYTE_PTR      pOut);

// single part decrypt operation
extern CK_RV FMCE_Decrypt(
               CK_MECHANISM_PTR pMech,  // mechanism type and parameters
               FMCE_KEY_PTR     pKey,   // key value

               CK_ULONG         ulDataInLen,
               CK_BYTE_PTR      pDataIn,
               CK_ULONG_PTR     pulOutLen,
               CK_BYTE_PTR      pOut);

// single part digest operation
extern CK_RV FMCE_Digest(
               CK_MECHANISM_PTR pMech,  // IN: mechanism type and parameters

               CK_ULONG         ulDataInLen,  // len of data to digest
               CK_BYTE_PTR      pDataIn,      // IN: data to digest
               CK_ULONG_PTR     pulDigOutLen, // IN: len of digest uffer OUT: len of digest
               CK_BYTE_PTR      pDigOut       // OUT: digest
                        );

/////

// multi-part sign operation init
extern CK_RV FMCE_SignInit(
               CK_MECHANISM_PTR pMech,  // IN: mechanism type and parameters
               FMCE_KEY_PTR     pKey,   // IN: key value

               FMCE_HANDLE_PTR  pCtxHdl // OUT: handle for following calls
                         );

// multi-part encrypt operation init
extern CK_RV FMCE_EncInit(
               CK_MECHANISM_PTR pMech,  // mechanism type and parameters
               FMCE_KEY_PTR     pKey,   // key value

               FMCE_HANDLE_PTR  pCtxHdl // OUT: handle for following calls
                         );

// multi-part verify operation init
extern CK_RV FMCE_VerifyInit(
               CK_MECHANISM_PTR pMech,  // mechanism type and parameters
               FMCE_KEY_PTR     pKey,   // key value

               FMCE_HANDLE_PTR  pCtxHdl // OUT: handle for following calls
                         );

// multi-part decrypt operation init
extern CK_RV FMCE_DecInit(
               CK_MECHANISM_PTR pMech,  // mechanism type and parameters
               FMCE_KEY_PTR     pKey,   // key value

               FMCE_HANDLE_PTR  pCtxHdl // OUT: handle for following calls
                         );

// multi-part digest operation init
extern CK_RV FMCE_DigestInit(
               CK_MECHANISM_PTR pMech,  // mechanism type and parameters

               FMCE_HANDLE_PTR  pCtxHdl // OUT: handle for following calls
                         );


// multi-part sign operation update
extern CK_RV FMCE_SignUpdate(
               FMCE_HANDLE     ulCtxHdl,    // handle from init operation
               CK_ULONG        ulDataInLen, // len of data to sign
               CK_BYTE_PTR     pDataIn      // IN: data to sign
                            );

// multi-part verify operation update
extern CK_RV FMCE_VerifyUpdate(
               FMCE_HANDLE     ulCtxHdl,    // handle from init operation
               CK_ULONG        ulDataInLen, // len of signed data
               CK_BYTE_PTR     pDataIn      // IN: signed data
                              );

// multi-part decrypt operation update
extern CK_RV FMCE_DecUpdate(
               FMCE_HANDLE     ulCtxHdl,    // handle from init operation
               CK_ULONG        ulDataInLen, // len of cipher data
               CK_BYTE_PTR     pDataIn,     // IN: cipher data
               CK_ULONG_PTR    pulDataOutLen, // IN: o/p data len OUT: len clear text
               CK_BYTE_PTR     pDataOut     // OUT: clear text
                          );

// multi-part encrypt operation update
extern CK_RV FMCE_EncUpdate(
               FMCE_HANDLE     ulCtxHdl,     // handle from init operation
               CK_ULONG        ulDataInLen,  // len clear text
               CK_BYTE_PTR     pDataIn,      // IN: clear text
               CK_ULONG_PTR    pulDataOutLen,// IN: len cipher text buffer OUT: len cipher text
               CK_BYTE_PTR     pDataOut      // OUT: cipher text
                           );

// multi-part digest operation update
extern CK_RV FMCE_DigestUpdate(
               FMCE_HANDLE     ulCtxHdl,     // handle from init operation
               CK_ULONG        ulDataInLen,  // len of data
               CK_BYTE_PTR     pDataIn       // IN: data to digest
                              );


// multi-part sign operation final
extern CK_RV FMCE_SignFinal(
               FMCE_HANDLE     ulCtxHdl,     // handle from init operation
               CK_ULONG        ulMacLen,     // len (in bytes) of MAC (only for MAC operations) else ignored
               CK_ULONG_PTR    pulSigOutLen, // IN: len of signature buffer OUT: len of signature
               CK_BYTE_PTR     pSigOut       // OUT: signature
                          );

// multi-part verify operation final
extern CK_RV FMCE_VerifyFinal(
               FMCE_HANDLE     ulCtxHdl,     // handle from init operation
               CK_ULONG        ulSigInLen,   // len of signature
               CK_BYTE_PTR     pSigIn        // IN: signature
                             );

// multi-part decrypt operation final
extern CK_RV FMCE_DecFinal(
               FMCE_HANDLE     ulCtxHdl,     // handle from init operation
               CK_ULONG_PTR    pulDataOutLen,// IN: len of clear text buffer OUT: len of clear text
               CK_BYTE_PTR     pDataOut      // OUT: clear text
                          );

// multi-part encrypt operation final
extern CK_RV FMCE_EncFinal(
               FMCE_HANDLE     ulCtxHdl,     // handle from init operation
               CK_ULONG_PTR    pulDataOutLen,// IN: len of buffer OUT: len cipher text
               CK_BYTE_PTR     pDataOut      // OUT: cipher text
                         );

// multi-part digest operation final
extern CK_RV FMCE_DigestFinal(
               FMCE_HANDLE     ulCtxHdl,     // handle from init operation
               CK_ULONG_PTR    pulDigOutLen, // IN: len of buffer OUT: len of digest 
               CK_BYTE_PTR     pDigOut       // OUT: digest
                             );


#ifdef __cplusplus
}
#endif

#endif /* INCL_FMCRYPTO */
