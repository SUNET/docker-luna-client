/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#ifndef INC_OBJSTATE_H
#define INC_OBJSTATE_H
#include <cryptoki.h>
#include "fmhdr.h"

/**
 * This function can be used to associate user data with a session handle.
 * The data is associated with the (PID, hSession) pair by the library. The
 * function specified in this call will be called to free the user data if the
 * session is closed (via a C_CloseSesion() or a C_CloseAllSessions() call), or
 * the application owning the session finalizes.
 *
 * If the session handle already contains another user data, it will be freed
 * (by calling the current free function) before the new data association is
 * created.
 *
 * @return CK_RV
 *     CKR_OK - The operation was successful.
 *     CKR_ARGUMENTS_BAD - freeUserData was NULL; or fmNo was not
 *     FM_NUMBER_CUSTOM_FM.
 *     CKR_SESSION_HANDLE_INVALID - the specified session handle is invalid.
 *     CKR_CRYPTOKI_NOT_INITIALIZED - Cryptoki is not initialized yet.
 *
 * @param fmNo
 *     The fm number of the caller. It must be FM_NUMBER_CUSTOM_FM in this
 *     release.
 * @param hSession
 *     A session handle, which was obtained from an C_OpenSesion() call. The
 *     validity of this parameter is checked.
 * @param userData
 *     Address of the memory block that will be associated with the session
 *     handle. If it is NULL, the current associated buffer is freed.
 * @param freeUserData
 *     Address of a function that will be called to free the userData, if the
 *     library decides that it should be freed. It must be non-NULL if userData
 *     is not NULL.
 */
CK_RV FM_SetSessionUserData(
		FmNumber_t fmNo,
		CK_SESSION_HANDLE hSession,
		CK_VOID_PTR userData,
		void (*freeUserData)(CK_VOID_PTR)
		);

/**
 * This function is used to obtain the userData associated with the specified
 * session handle. If there are no associated buffers, NULL is returned in
 * ppUserData.
 *
 * @return CK_RV
 *     CKR_OK - Operation was successful. The associated user data is placed in
 *     the variable specified by ppUserData.
 *     CKR_ARGUMENTS_BAD - ppUserData was NULL; or fmNo was not
 *     FM_NUMBER_CUSTOM_FM.
 *     CKR_SESSION_HANDLE_INVALID - hSession is not a valid session handle.
 *     CKR_CRYPTOKI_NOT_INITIALIZED - Cryptoki is not initialized yet.
 *
 * @param hSession
 *     A session handle, which was obtained from an C_OpenSesion() call. The
 *     validity of this parameter is checked.
 * @param ppUserData
 *     Address of a variable (of type CK_VOID_PTR) which will contain the
 *     address of the user data if this function returns CKR_OK. It must be
 *     non-NULL.
 */
CK_RV FM_GetSessionUserData(
		FmNumber_t fmNo,
		CK_SESSION_HANDLE hSession,
		CK_VOID_PTR_PTR ppUserData
		);


#endif /* INC_OBJSTATE_H */
