/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#ifndef FMSUPT_INCL
#define FMSUPT_INCL

#include <fm/host/md.h>

int FM_GetNDRandom (char * out, int len);

// Note includes "FM: <fm name>: "
#define FM_MAX_AUDIT_LEN 100

int FM_AddToExtLog (char * str);

MD_RV FM_GetHsmInfo( MD_Info_t infoType, void *pValue, uint32_t valueLen );

// BIP32 extensions
CK_RV CA_Bip32ExportPublicKey(
   CK_SESSION_HANDLE hSession,
   CK_ULONG          ulObjectHandle,      //BIP32 public key to export
   CK_BYTE_PTR       pPublicSerialData,   //Base58 encoded data dest.
   CK_ULONG_PTR      pulPublicSerialLen //in: max.buffer size, out: returned size
);
CK_RV CA_Bip32ImportPublicKey(
   CK_SESSION_HANDLE hSession,
   CK_BYTE_PTR      pBase58Key, //Base58 encoded data src.
   CK_ULONG         usKeyLen,   //encoded data size
   CK_ATTRIBUTE_PTR pTemplate,  //user-specified attributes
   CK_ULONG         usCount,
   CK_OBJECT_HANDLE_PTR phImportedObject  //returned handle of created key
);

#endif // FMSUPT_INCL
