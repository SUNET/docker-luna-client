/****************************************************************************\
*
*  Filename:      fm_io_service.h
*
*  Description:   This file contains fm SVC_* function prototypes.
*
*  Copyright © 2004-18 SafeNet. All rights reserved.

*  This file contains information that is proprietary to SafeNet and may not be
*  distributed or copied without written consent from SafeNet.
*
\****************************************************************************/
#ifndef FM_IO_SERVICE_H
#define FM_IO_SERVICE_H

#include <stdint.h>

typedef void *FmMsgHandle;


/**
 * This function is used by the called applications to receive a reply
 * buffer from the Service module.
 *
 * @param token
 *     A token identifying the request.
 *
 * @param size
 *     Length of the reply buffer.
 *
 * @return
 *     @li If there is already a reply buffer, NULL is returned.
 *     @li If there is not enough memory to allocate the requested amount of
 *         reply buffer, @c NULL is returned.
 *     @li Otherwise, a pointer to the reply buffer is returned.
 */
void *SVC_GetReplyBuffer(FmMsgHandle token, uint32_t size);

/**
 * This function is used to reuse the request buffer as the reply buffer. This
 * call may cause a memcopy when the reply is being posted back to the host
 * system.
 *
 * @param token
 *    A token identifying the request.
 *
 * @return
 *    @li If there is already a reply buffer, NULL is returned.
 *    @li Otherwise, pointer to the reply buffer is returned. The reply buffer
 *        is not guaranteed to be at the same address as the request buffer.
 *        However, it will contain the request buffer contents.
 */
void *SVC_ConvertReqToReply(FmMsgHandle token);

/**
 * This function is called by the request handling function when the reply is
 * ready to be sent back to the host. The function may perform operations after
 * this function is called, but it should not use the token in further Service
 * Module functions.
 *
 * @param token
 *    A token identifying the request.
 *
 * @param status
 *    Application status to be returned to host.
 */
void SVC_SendReply(FmMsgHandle token, uint32_t status);

/**
 * This function is used to resize the reply buffer.
 *
 * @param token
 *    A token identifying the request.
 *
 * @param replyLength
 *    New length of the reply buffer.
 *
 * @return
 *    @li If there is not a reply buffer, NULL is returned.
 *    @li If there is not enough memory to allocate a reply buffer, NULL is
 *    returned.
 *    @li Otherwise, pointer to a reply buffer is returned. The new reply buffer
 *    will contain the data in the old reply buffer.
 */
void *SVC_ResizeReplyBuffer(FmMsgHandle token, uint32_t replyLength);

/**
 * This function discards the current reply buffer.
 *
 * @param token
 *    A token identifying the request.
 */
void SVC_DiscardReplyBuffer(FmMsgHandle token);

/**
 * This function is used to learn the reply buffer length specified by the host
 * system.
 *
 * @param token
 *    A token identifying the request.
 *
 * @return
 *    Length of the reply buffer on the host system.
 */
uint32_t SVC_GetUserReplyBufLen(FmMsgHandle token);

/**
 * This function retrieves the Pid recorded in the request. The Pid is the
 * Process Id of the host application that originated the request.
 *
 * @param token
 *    A token identifying the request.
 *
 * @return
 *    The Process identifier recorded in the request is returned.
 */
uint32_t SVC_GetPid(FmMsgHandle token);

/**
 * This function retrieves the Oid recorded in the request. The Oid is a value
 * passed in from the host application.
 *
 * @param token
 *    A token identifying the request.
 *
 * @return
 *    The Originator identifier recorded in the request is returned.
 */
uint32_t SVC_GetOid(FmMsgHandle token);

/**
 * This function overrides the Pid recorded in the request. The Pid is
 * the Process Id of the host application that originated the request.
 *
 * @param token
 *    A token identifying the request.
 *
 * @param pid
 *    The new pid value.
 */
void SVC_SetPid(FmMsgHandle token, uint32_t pid);

/**
 * This function overrides the Oid recorded in the request. The Oid is a value
 * passed in from the host application.
 *
 * @param token
 *    A token identifying the request.
 *
 * @param oid
 *    The new oid value.
 */
void SVC_SetOid(FmMsgHandle token, uint32_t oid);

/**
 * This function retrieves the address of request data in the token.
 *
 * @param token
 *    A token identifying the request.
 *
 * @return
 *    The request buffer address in the token is returned.
 */
void *SVC_GetRequest(FmMsgHandle token);

/**
 * This function retrieves the length of request data in the token.
 *
 * @param token
 *    A token identifying the request.
 *
 * @return
 *    The length of the request buffer in the token is returned.
 */
uint32_t SVC_GetRequestLength(FmMsgHandle token);

/**
 * This function retrieves the address of current reply buffer.
 *
 * @param token
 *    A token identifying the request.
 *
 * @return
 *    The address of the current reply buffer in the token is returned.
 */
void *SVC_GetReply(FmMsgHandle token);

/**
 * This function retrieves the length of reply data in number of bytes.
 *
 * @param token
 *    A token identifying the request.
 *
 * @return
 *    The length of the current reply buffer in the token is returned.
 */
uint32_t SVC_GetReplyLength(FmMsgHandle token);

/**
 * This function retrieves the usage level of the HSM as a load percentage.
 *
 * @return
 *    The rolling average of the usage level of the HSM.
 */
unsigned long SVC_GetHsmUsageLevel(void);

/*
 * If we were to deprecate the existing PS SVC_Xxx APIs and encourage users to
 * move towards the Luna model, these are the new core SVC APIs:
 */

/*
 * Streaming IO model needs a different dispatch entry point
   FMSW_STATUS FMSW_RegisterStreamDispatch(uint16_t fmid, int (*proc)(FmMsgHandle token));
   see fmsw.h
 */


 /*
 *      Reads up to the 'size' bytes to the user destination buffer from the
 *      I/O input buffer (a.k.a. "command" buffer). Returns the size actually
 *      read (if the end of the data is reached the returned size can be
 *      smaller than the requested one).
 */
unsigned int SVC_IO_Read(FmMsgHandle token, void *destination, int size);

 /*
 *      Writes up to the 'size' bytes from the user source buffer to the I/O
 *      output buffer (a.k.a. "reply" or "response" buffer). Returns the size
 *      actually written (if the capacity of the output buffer is reached the
 *      returned size can be smaller than the requested size).
 */
unsigned int SVC_IO_Write(FmMsgHandle token, void *source, int size);

 /*
 *      Returns the pointer to the input buffer and its size. If the buffer
 *      is internally scattered or chunked in any other way, the pointer and
 *      the size relate to the current chunk only. The user can then directly
 *      access the buffer via the pointer, but only within the limits of the
 *      returned size.
 */
unsigned int SVC_IO_GetReadPointer(FmMsgHandle token, void **read_pointer);

 /*
 *      Returns the pointer to consecutive input buffer, chunks will be coalesed if required.
 *      The user can then directly access the full input buffer via the pointer.
 */
unsigned int SVC_IO_GetReadBuffer(FmMsgHandle token, void **read_pointer);

 /*
 *      Tells the I/O subsystem that the 'size' amount has been consumed
 *      ("read") from the current chunk of the input buffer. Next
 *      SVC_IO_GetReadPointer() call will return the pointer to the remaining
 *      portion of the chunk, or to the new chunk altogether if the 'size'
 *      consumes all the remaining portion of the current input buffer chunk.
 *      This function assumes that the 'size' parameter does _not_ exceed the
 *      return value of the previous SVC_IO_GetReadPointer() call.
 */
void SVC_IO_UpdateReadPointer(FmMsgHandle token, int size);

 /*
 *      These two functions do the same for write buffer as
 *      the previous ones does for reads from the command buffer.
 */
unsigned int SVC_IO_GetWritePointer(FmMsgHandle token, void **write_pointer);
void SVC_IO_UpdateWritePointer(FmMsgHandle token, int size);

 /*
 *      This function does the same for writes into the reply buffer as
 *      the previous does for reads from the command buffer.
 */
unsigned int SVC_IO_GetWriteBuffer(FmMsgHandle token, void **write_pointer);


 /*
 *      These functions are like SVC_IO_Read() except that the size of the
 *      data is assumed by the input data type and endian conversion is performed.
 *      The implementation may be able to make these functions faster than the
 *      generic SVC_IO_Read().
 */

unsigned int SVC_IO_Read8(FmMsgHandle token, uint8_t *v);
unsigned int SVC_IO_Read16(FmMsgHandle token, uint16_t *v);
unsigned int SVC_IO_Read32(FmMsgHandle token, uint32_t *v);
unsigned int SVC_IO_Read64(FmMsgHandle token, uint64_t *v);

 /*
 *      Similar to SVC_IO_Read8/16/32(), but for writes to the reply buffer.
 */
unsigned int SVC_IO_Write8(FmMsgHandle token, uint8_t v);
unsigned int SVC_IO_Write16(FmMsgHandle token, uint16_t v);
unsigned int SVC_IO_Write32(FmMsgHandle token, uint32_t v);
unsigned int SVC_IO_Write64(FmMsgHandle token, uint64_t v);


#endif /* FM_IO_SERVICE_H */
