/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#ifndef INCL_FMCIPHOBJ
#define INCL_FMCIPHOBJ

#include	"fmcrypto.h"

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

/* This is the type returned from CiphObj functions */
enum _CiphObjStat {
	CO_OK = 0,			/* OK */
	CO_PARAM_INVALID = 1,	/* Usually mode is wrong */
	CO_SIG_INVALID = 2,
	CO_LENGTH_INVALID = 3,
	CO_DEVICE_ERROR	 = 4,
	CO_GENERAL_ERROR = 5,
	CO_MEMORY_ERROR	 = 6,
	CO_BUFFER_TOO_SMALL = 7,
	CO_DATA_INVALID	 = 8,
	CO_NEED_IV_UPDATE = 9,
	CO_NOT_SUPPORTED = 10,
	CO_DUPLICATE_IV_FOUND = 11,
    CO_FIPSG_ERROR= 12,   /* Output from FIPSG whitener failed FIPS RNG test */
    CO_FUNCTION_NOT_IMPLEMENTED = 13
};

typedef enum _CiphObjStat CiphObjStat;

/*
 * Ciph Objects - CipherObject cryptographic support as exported to FMs
 *  Includes hash objects as well.
 */

/* RSA key structures */

#define MAX_RSA_MOD_BYTES    ((8*1024)/8)
#define MAX_RSA_PRIME_BYTES  MAX_RSA_MOD_BYTES/2

#define MAX_DSA_BYTES    ((3*1024)/8)

#ifndef byte
#define byte unsigned char
#endif

// all fields hold number big endian right aligned and padded with null on left
// e.g.  to store 0x823456 in a 6 byte buffer you get | 0x00 0x00 0x00 0x82 0x34 0x56 |
typedef struct {
    byte bits[2];     // unused
    byte mod [MAX_RSA_MOD_BYTES];
    byte exp [MAX_RSA_MOD_BYTES];
}
RSA_PUBLIC_KEY;

typedef struct {
    byte bits[2];     // unused
    byte mod [MAX_RSA_MOD_BYTES];
    byte pub [MAX_RSA_MOD_BYTES];
    byte pri [MAX_RSA_MOD_BYTES];
    byte p   [MAX_RSA_PRIME_BYTES];
    byte q   [MAX_RSA_PRIME_BYTES];
    byte e1  [MAX_RSA_PRIME_BYTES];
    byte e2  [MAX_RSA_PRIME_BYTES];
    byte u   [MAX_RSA_PRIME_BYTES];
}
RSA_PRIVATE_KEY_XCRT;

// pass this structure as the key for RSA verify or Enc operations
struct CtPubRsaKey {
	int isPub;		     // TRUE
	unsigned int modSz;  // sizeof mod in bytes
	RSA_PUBLIC_KEY key;
};
typedef struct CtPubRsaKey CtPubRsaKey;

// pass this structure as the key for RSA sign or Dec operations
struct CtPriRsaKey {
	int isPub;	         // FALSE
	int isXcrt;          // True
	unsigned int modSz;  // sizeof mod in bytes
	RSA_PRIVATE_KEY_XCRT key;
};
typedef struct CtPriRsaKey CtPriRsaKey;

/* pass this structue in as the key for DSA sign operations */
typedef struct {
    byte p [MAX_DSA_BYTES]; /* prime p (512-1024 bits,in steps of 64 bits) */
    byte q [MAX_DSA_BYTES]; /* subprime q (160 bits) */
    byte g [MAX_DSA_BYTES]; /* base g */
    byte y [MAX_DSA_BYTES]; /* public value y */
} DSA_PUBLIC_KEY;

/* pass this structue in as the key for DSA verify operations */
typedef struct {
    byte p [MAX_DSA_BYTES]; /* prime p (512-1024 bits, in steps of 64 bits */
    byte q [MAX_DSA_BYTES]; /* subprime q (160 bits) */
    byte g [MAX_DSA_BYTES]; /* base g */
    byte x [MAX_DSA_BYTES]; /* private value x */
} DSA_PRIVATE_KEY;


/*
** constant values used to refer to a particular cipher object
** for backwards compatability do not change any of these values
*/
enum FMCO_CipherObjIndex {

	FMCO_IDX_AES		= 0,
	FMCO_IDX_CAST		= 1,  // CAST128
	FMCO_IDX_RC2		= 3,
	FMCO_IDX_RC4		= 4,
	FMCO_IDX_DES		= 5,
	FMCO_IDX_TRIPLEDES	= 6,

	FMCO_IDX_DSA		= 10,
//	FMCO_IDX_ECDSA		= 11,  // unsupported

//	FMCO_IDX_HMACMD2	= 20,  // unsupported
	FMCO_IDX_HMACMD5	= 21,
	FMCO_IDX_HMACSHA1	= 22,
//	FMCO_IDX_HMACRMD128	= 23,  // unsupported
	FMCO_IDX_HMACRMD160	= 24,

	FMCO_IDX_RSA		= 30,
//	FMCO_IDX_RSA_MD2	= 31,  // unsupported
	FMCO_IDX_RSA_MD5	= 32,
	FMCO_IDX_RSA_SHA1	= 33,
	FMCO_IDX_RSA_SHA256	= 34,
	FMCO_IDX_RSA_SHA384	= 35,
	FMCO_IDX_RSA_SHA512	= 36,
	FMCO_IDX_RSA_SHA224 = 39,

//   FMCO_IDX_ECDSA_SHA1     = 40,  // unsupported
//   FMCO_IDX_ECDSA_SHA224   = 41,  // unsupported
//   FMCO_IDX_ECDSA_SHA256   = 42,  // unsupported
//   FMCO_IDX_ECDSA_SHA384   = 43,  // unsupported
//   FMCO_IDX_ECDSA_SHA512   = 44,  // unsupported
//   FMCO_IDX_ECIES          = 45,  // unsupported

	FMCO_INVALID        = -1
};
typedef enum FMCO_CipherObjIndex FMCO_CipherObjIndex;

/** minimum MAC length for symmetric ciphers */
#define MIN_MAC 4

/** Common symmetric cipher encrypt/decrypt modes for symmetric ciphers
 *  Choose from 0 to 5 and optionally 'or in' a padding specifier.
 *
 *  Padding is the method used to extend the last bit of data up to a block
 *  boundary so the block cipher can be applied.
 *
 *  PKCS#1 padding applies from 1 to 8 bytes where the value of each byte
 *  is the number of bytes added.
 *  NULL padding adds from 0 to 7 bytes of zero.
 *  An error is returned from Final calls if no padding is selected and there
 *  are bytes left over.
 *
 *  Algorithm block lengths are published with the GetInfo function (see
 *  CipherObjGetInfo and CipherInfo).
 */
enum _CipherEncMode {
    SYM_MODE_ECB = 0,   /* Electronic Code Book */
    SYM_MODE_CBC = 1,   /* Cipher Block Chaining */
    SYM_MODE_CFB = 2,   /* Cipher Feed Back (64 bit) */
    SYM_MODE_BCF = 3,   /* Byte Cipher Feedback (8 bit CFB) */
    SYM_MODE_OFB = 4,   /* Output feed back (64 bit) */
    SYM_MODE_BOF = 5,   /* Byte - 8 bit - Output feed back */
    SYM_MODE_MASK= 0x0F,/* Mask to select Mode */

    SYM_MODE_PADNULL  = 0x80,   /* NULL padding to be applied */
    SYM_MODE_PADPKCS1 = 0x90,   /* PKCS#1 padding to be applied */
    SYM_MODE_PADMASK  = 0xF0    /* Mask to select PAdding */
};
typedef enum _CipherEncMode CipherEncMode;

/** temporary value for backwards compatability */
#define SYM_MODE_PAD SYM_MODE_PADNULL

/** Common symmetric cipher MAC (signature) modes

    Padding is the method used to extend the last bit of data up to a block
    boundary so the block cipher can be applied.
    NULL padding adds from 0 to 7 bytes of zero.

    The message is always padded.

    Standard CBC mode uses DES-CBC or DES3-CBC encryption.
*/
enum _CipherSignMode {
    SYM_MODE_MAC_3    = 0,  /* standard CBC with NULL padding */
    SYM_MODE_MAC_GEN  = 1   /* standard CBC with NULL padding - generic length */
};
typedef enum _CipherSignMode CipherSignMode ;

/* RSA Object modes */
#define RSA_MODE_X509	0
#define RSA_MODE_PKCS	1
#define RSA_MODE_9796	2
#define RSA_MODE_OAEP	3

/**
 *  Cipher information.
 *
 *  Allows application to determine characteristics of the cipher.
 */
struct CipherInfo {
    char name[32];              /**< null terminated ascii string e.g. "DES" */
    unsigned int minKeyLength;  /**< minimum key length (bytes) */
    unsigned int maxKeyLength;  /**< maximum key length (bytes) */
    unsigned int blockSize;     /**< cipher block size in bytes (may depend on
                                  mode) */
    unsigned int defSignatureSize;  /**< default signature size (bytes) */
    struct CipherObj * ciph;    /**< parent cipher object */
};
typedef struct CipherInfo CipherInfo;


/******************************************************************************
*
*       THE CIPHER OBJECT STRUCTURE
*
*
    Generic Cipher object.
    Wraps cipher algorithms into a common interface.

    The object is implemented by a structure and function pointers within that
    structure.

    There will be various implementations of these structures for different
    cipher algorithms and

    Generally all ciphers can be managed in the same way however there is, in
    some cases, some cipher specific details. In particular the encryption and
    signature mode parameters may have a different meaning depending on the
    Cipher algorithm and different levels of support between different Class
    Object implementations of the same algorithm.  (e.g. mode parameter for RSA
    objects has a different meaning for DES objects. More mode parameter values
    are supported by the SW DES object than the CSA8000 DES object)

    To use cipher objects the caller -
    - Creates a new object by calling FmCreateCipherObject()
    - The caller then invokes functions in the new structure (passing the ptr
        to the new object as the first argument).
    - When finished the caller Destroys the object by calling the 'Free'
        function in the new object.

    Each object may support the following cipher mechanisms -
        Encryption
        Decryption
        Signature Generation (e.g. MACing)
        Signature Verification (e.g. MAC Verifying)
        Signature Generation with data recovery (e.g. RSA ISO 9796)
        Signature Verification with data recovery

    Signature Generation and Verification with data recovery are mechanisms
    that include the message into the signature (so that it can be recovered
    when the signature is verified). These mechanisms are therefore single part
    operations. i.e. no update operations are allowed following the SignInit or
    VerifyInit. (Signatures with mesage recovery are only supported on RSA
    based Cipher Objects).

    Not all functions are supported by all object implementations - unsupported
    functions may simply return an error or may have a NULL pointer in the
    object where the function pointer should be.  Callers need to check for
    NULL pointers or ensure the object supports the function by some other
    means before calling the function entries in any object.

    The object can be in different states depending on the previous operations
    executed on it.  In particular if the object has been moded up for
    encryption (with the EncInit function) then the object may only be used for
    encryption until another Init operation is called. Therefore if you want to
    encrypt and decrypt with the same key you should either Init the same
    object twice or init two different objects. The choice depends on whether
    the operations need to be performed in parrallel or serially.

    REENTRANCY - Cipher object contexts are NOT re-entrant. Threads should
    keep objects they create private or arrange other means to protect shared
    objects.

  Example Usage
    CipherObj * p = FmCreateCipherObject(idx);
    p->EncInit( p, .....);
    p->EncUpdate( p, ....);
    p->EncFinal(p, ....);
    p->Free(p);
*/

/**
 * CipherObj structure
 *  Holds functions performed by cipher objects.
 */
struct CipherObj {

    /*
     * private context data for member functions
     */

    CipherInfo info;
    unsigned int sigOutLen;
    unsigned long key_type;
    unsigned long hash_mech;
    unsigned long co_index;
    unsigned long hdl;

    /*
     * public functions
     */

    /**
    CipherObj destructor

    The cipher object Free function releases resources used by the object.
    The context structure attached to the object will be freed. The object
    itself will be freed if it was malloced

    @return
        see CiphObjStat
    */
    int (*Free)(struct CipherObj * ctx);

    /**
    CipherObj.GetInfo will return information about an initialized CipherObj.
    No sensitive information is returned by this function.

    (see CipherInfo for more details).

    @return
        see CiphObjStat
    */
    int (*GetInfo)(struct CipherObj * ctx, struct CipherInfo * info);

    /**
    CipherObj.EncInit configures the object to perform encryption.

    The algorithm will always verify that the mode, key length and parameter
    length is valid.
    See the particular Cipher Class implementation description for details on
    valid modes and parameters.
    Valid Key lengths are published with the GetInfo function (see
    CipherObj.GetInfo and CipherInfo).

    @return
        see CiphObjStat
    */
    int (*EncInit)(struct CipherObj * ctx,
        int mode,
        const void * key, unsigned int klength,
        const void * param, unsigned int plength);

    /**
    CipherObj.DecInit configures the object to perform decryption.

    The algorithm will always verify that the mode, key length and parameter
    length is valid.
    See the particular Cipher Class implementation description for details on
    valid modes and parameters.
    Valid Key lengths are published with the GetInfo function (see
    CipherObj.GetInfo and CipherInfo).

    @return
        see CiphObjStat
    */
    int (*DecInit)(struct CipherObj * ctx,
        int mode,
        const void * key, unsigned int klength,
        const void * param, unsigned int plength);

    /**
    CipherObj.SignInit configures the object to perform signature generation.

    The algorithm will always verify that the mode, key length and parameter
    length is valid.
    See the particular Cipher Class implementation description for details on
    valid modes and parameters.
    Valid Key lengths are published with the GetInfo function (see
    CipherObj.GetInfo and CipherInfo).

    @return
        see CiphObjStat
    */
    int (*SignInit)(struct CipherObj * ctx,
        int mode,
        const void * key, unsigned int klength,
        const void * param, unsigned int plength);

    /**
    CipherObj.VerifyInit configures the object to perform signature verifications

    The algorithm will always verify that the mode, key length and parameter
    length is valid.
    See the particular Cipher Class implementation description for details on
    valid modes and parameters.
    Valid Key lengths are published with the GetInfo function (see
    CipherObj.GetInfo and CipherInfo).

    @return
        see CiphObjStat
    */
    int (*VerifyInit)(struct CipherObj * ctx,
        int mode,
        const void * key, unsigned int klength,
        const void * param, unsigned int plength);

    /**
    CipherObj.EncryptUpdate uses the object to perform encryptions

    Because of buffering the output length may not equal the input length.
    If 'tgt' is NULL no operation is performed but the length that would be
    output is returned in '*plen'.

    The RSA object uses this method to do single part enc/dec operations
    @return
        see CiphObjStat
    */
    int (*EncryptUpdate)(struct CipherObj * ctx,
        void * tgt, unsigned int tlength, unsigned int * plen,
        const void * src, unsigned int length);

    /**
    CipherObj.EncryptFinal uses the object to finish an encryption

    Because of various buffering algorithms the output length may equal none or
    one blocks.
    If 'tgt' is NULL no operation is performed but the length that would be
    output is returned in '*plen'.

    @return
        see CiphObjStat
    */
    int (*EncryptFinal)(struct CipherObj * ctx,
        void * tgt, unsigned int tlength, unsigned int * plen);

    /**
    CipherObj.DecryptUpdate uses the object to perform decryptions

    Because of buffering the output length may not equal the input length.
    If 'tgt' is NULL no operation is performed but the length that would be
    output is returned in '*plen'.

    The RSA object uses this method to do single part enc/dec operations
    @return
        see CiphObjStat
    */
    int (*DecryptUpdate)(struct CipherObj * ctx,
        void * tgt, unsigned int tlength, unsigned int * plen,
        const void * src, unsigned int length);

    /**
    CipherObj.DecryptFinal uses the object to finish a decryption

    Because of various buffering algorithms the output length may from zero to
    the length of one block.
    If 'tgt' is NULL no operation is performed but the length that would be
    output is returned in '*plen'.

    @return
        see CiphObjStat
    */
    int (*DecryptFinal)(struct CipherObj * ctx,
        void * tgt, unsigned int tlength, unsigned int * plen);

    /**
    CipherObj.SignUpdate specifies more data for signature generation.
    Generally the data is absorbed by this function and no data is returned.
    However the internal object context state will be modified to reflect the
    new data.

    Some CipherObj implementations may be only able to accept a limited amount
    of data.

    @return
        see CiphObjStat
    */
    int (*SignUpdate)(struct CipherObj * ctx,
        const void * src, unsigned int length);

    /**
    CipherObj.SignFinal indicates signature generation message has finished and
    the sig should be returned.

    @return
        see CiphObjStat
    */
    int (*SignFinal)(struct CipherObj * ctx,
        void * tgt, unsigned int tlength, unsigned int * plen);

    /** gen and return signature
    CipherObj.SignRecover performs signature generation operation.
    The message to be signed must be passed in in src
    The signature is passed back to 'tgt'.
    tgt may be null for length prediction

    @return
        see CiphObjStat
    */
    int (*SignRecover)(struct CipherObj * ctx,
        void * tgt, unsigned int tlength, unsigned int * plen,
        const void * src, unsigned int length);

    /**
    CipherObj.VerifyUpdate specifies more data for signature verification.
    Generally the data is absorbed by this function and no data is returned.
    However the internal object context state will be modified to reflect the
    new data.

    Some CipherObj implementations may be only able to accept a limited amount
    of data.

    @return
        see CiphObjStat
    */
    int (*VerifyUpdate)(struct CipherObj * ctx,
        const void * src, unsigned int length);

    /**
    CipherObj.VerifyFinal performs signature verification operation.
    The message to be signed must have been passed in in previous
        CipherObj.VerifyUpdate calls.
    The signature to compare against is passed in in 'sig'. Compare errors are
    returned as a return error code.

    @return
        see CiphObjStat
    */
    int (*VerifyFinal)(struct CipherObj * ctx,
        const void * sig, unsigned int slength,
        void * tgt, unsigned int tlength, unsigned int * plen);

    /** verify signature and return message (see CipherObj.VerifyRecover)
    CipherObj.VerifyRecover performs signature verification operation.
    The message to be signed must be passed in in src
    The original hash value should be returned in tgt but this is not supported.
    The signature to compare against is passed in in 'sig'.
    Compare errors are returned as a return error code.

    @return
        see CiphObjStat
    */
    int (*VerifyRecover)(struct CipherObj * ctx,
        const void * sig, unsigned int slength,
        void * tgt, unsigned int tlength, unsigned int * plen,
        const void * src, unsigned int length);

    /**
    CipherObj.Verify performs a single part signature verification operation.
    This function not supported on Symmetrical Cipher objects.
    A message (probably a hash value) is compared to the message recovered from
    the sig cryptogram.

    Compare errors are returned as a return error code.

    @return
        see CiphObjStat
    */
    int (*Verify)(struct CipherObj * ctx,
        const void * sig, unsigned int slength,
        const void * src, unsigned int length);

};
typedef struct CipherObj CipherObj;

/**
**	Hash information.
**
**	Allows application to determine characteristics of the digest algorithm.
*/
struct HashInfo {
	char name[32];	            /**< null terminated ascii string e.g. "SHA-1" */
	unsigned int blockLength;	/**< optimal hash block size */
	unsigned int hashLength;	/**< size of hash value */
	struct HashObj * hobj;      /**< version 1 */
};
typedef struct HashInfo HashInfo;

/**
**	The hash object includes a context pointer and member functions.
*/
struct HashObj {
    HashInfo info;
    unsigned int mech;
    unsigned int hdl;

    /**
    HashObj destructor

    The hash object Free function releases resources used by the object.
    The context structure attached to the object will be freed. The object
    itself will be freed if it was malloced (see HashObjNew for more details).

    @return
        see CiphObjStat
    */
	int (*Free)(struct HashObj * ctx);

	/** prepare to hash  */
    /**
    HashObjInit configures the object to perform a hash operation.

    @return
        see CiphObjStat
    */
	int (*Init)(struct HashObj * ctx);
    /**
    HashObjUpdate uses the object to perform a hash operation

    The data passed in src is passed throught the hash algorithm

    @return
        see CiphObjStat
    */
	int (*Update)(struct HashObj * ctx, const void * buf, unsigned int length);
    /**
    HashObjFinal uses the object to finish a hash operation

    If 'tgt' is NULL no operation is performed but the length that would be
    output is returned in '*plen'.

    @return
        see CiphObjStat
    */
	int (*Final)(struct HashObj * ctx,
		unsigned char * hashVal, unsigned int length, unsigned int * plength);
    /**
    HashObjGetInfo will return information about an initialized HashObj.
    No sensitive information is returned by this function.

    (see HashInfo for more details).

    @return
        see CiphObjStat
    */
	int (*GetInfo)(struct HashObj * ctx, struct HashInfo * hinfo);
};
typedef struct HashObj HashObj;

/*
** constant values used to refer to a particular hash object
** for backwards compatability do not change any of these values
*/
enum FMCO_HashObjIndex {

//	FMCO_IDX_MD2		= 0,  // unsupported
	FMCO_IDX_MD5		= 1,
//	FMCO_IDX_RMD128		= 2,  // unsupported
	FMCO_IDX_RMD160		= 3,
	FMCO_IDX_SHA1		= 4,
	FMCO_IDX_SHA256		= 5,
	FMCO_IDX_SHA384		= 6,
	FMCO_IDX_SHA512		= 7,
	FMCO_IDX_SHA224		= 8

};
typedef enum FMCO_HashObjIndex FMCO_HashObjIndex;


/*
 * Returns the address of a cipher object for performing crypto operations.
 * Returns pointer to an initialised cipherobject or null in an error condition.
 */
CipherObj * FmCreateCipherObject(
							FMCO_CipherObjIndex index
					);

/*
 * Returns the address of a hash object for digest operations.
 * Returns pointer to an initialised hash object or null in an error condition.
 */
HashObj * FmCreateHashObject(
							FMCO_HashObjIndex index
					);


#ifdef __cplusplus
}
#endif

#endif /* INCL_FMCIPHOBJ */
