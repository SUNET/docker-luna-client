/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#ifndef INC_FM_H
#define INC_FM_H

#include "../common/fmerr.h"
#include "../common/integers.h"

/*
 * This header declares the functions that must be implemented by a FM.
 */

/*
 * Startup() is the entry point of the FM.
 *
 * The FM can perform the initialization and resource acquisition required by
 * the rest of its functions in this function.
 *
 * This function must perform its operations, and return immediately. The rest
 * of the system is blocked until the initialization is finished. If the adapter
 * is reset before the FM initialization is finished, the FM will be disabled
 * automatically.
 */
FM_RV Startup(void);

//extern struct FM_Header_st FM_Header;


#if defined(IS_BIG_ENDIAN) || defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__

#define hton_short(x) (x)
#define ntoh_short(x) (x)
#define hton_long(x) (x)
#define ntoh_long(x) (x)

#else

#define hton_short(x) ((((x) >> 8)&0xffu) | (((x) << 8) & 0xff00u))
#define ntoh_short(x) hton_short(x)
#define hton_long(x) ((((x) >> 24)&0xffuL) | (((x) >> 8) & 0xff00uL) | (((x) << 8) & 0xff0000uL) | (((x) << 24) & 0xff000000uL))
#define ntoh_long(x) hton_long(x)

#endif /* #ifdef IS_BIG_ENDIAN */

/* Functionality module number type. Each FM loaded to the system has a unique
   FM number. These numbers are also used as the major numbers for the HIFACE
   communication.
*/
typedef uint16 FmNumber_t;

/* Functionality module version type. */
typedef uint16 FmVersion_t;

/* Embedded FM to test host/FM I/O */
#define FM_NUMBER_HIFACE	0x0000

/* Embedded FM for internal service requests from the HOST to FM process */
#define FM_NUMBER_EMBEDDED 0x0001

/* The first FM number allowed for customer's FMs */
#ifndef FM_NUMBER_CUSTOM_FM
#define FM_NUMBER_CUSTOM_FM 0x0100
#endif

#define FMID_ALLOCATE_HIGH  0xffff
#define FMID_ALLOCATE_NORM  0xfffe
#define FMID_ALLOCATE_LOW  0xfffd

#define FM_ID_HIGH_MIN 0xE000
#define FM_ID_HIGH_MAX 0xFF00

#define FM_ID_NORM_MIN 0xA000
#define FM_ID_NORM_MAX 0xDFFF

#define FM_ID_LOW_MIN 0x8000
#define FM_ID_LOW_MAX 0x9FFF

#define FM_ID_CUSTOM_MIN 0x100
#define FM_ID_CUSTOM_MAX 0x7fff

/* Unused Flash ROM sector */
#define FM_NUMBER_EMPTY		0xFFFF

/* Macro to create FM version. */
#define FM_MAKE_VERSION(MAJOR, MINOR) (((MINOR&0xFF)<<8)|(MAJOR&0xFF))

/* Macro to obtain the version major number from FmVersion_t */
#define FM_VERSION_MAJOR(VERSION) ((VERSION)&0xFF)

/* Macro to obtain the version minor number from FmVersion_t */
#define FM_VERSION_MINOR(VERSION) (((VERSION)&0xFF00)>>8)

#include "fmhdr.h"

#endif /* INC_FM_H */
