/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

#ifndef INC_FMHDR_H
#define INC_FMHDR_H
#include "stdint.h"
#include "csa8fm.h"

/* Generalized Time format.
 *  GeneralizedTime values MUST be expressed Greenwich Mean Time
 *  and MUST include seconds (i.e., times are
 *  YYYYMMDDHHMMSS,0x00,0x00), even where the number of seconds is
 *  zero, and MUST NOT include fractional seconds.
 */
// tl: changed size to 21 so we can use C99 macros to set FM build sate & time
//    "MMM DD YYYY-HH:MM:SS"
typedef unsigned char SP_DateTimeHSM[21];

/*	This type contains the sector usage of a functionality module. It can
 	contain the following values:
		FM_NOT_USED: Sector not in use
		FM_TO_BE_USED: Sector being programmed
		FM_LENGTH_WRITTEN: Length of FM written to FM header
		FM_IN_USE0: FM completely written, and can be used
		FM_UPGRADING0: Preparing to upgrade FM for the first time
		FM_IN_USE1:First upgrade failed
		FM_UPGRADING1: Preparing to upgrade FM for the second time
		FM_IN_USE2: Second upgrade failed
		FM_UPGRADING2: Preparing to upgrade FM for the third time
		FM_IN_USE3: Third upgrade failed
		FM_UPGRADING3: Preparing to upgrade FM for the fourth (last) time
		FM_DELETED: FM Deleted => Sector(s) can be re-used
		FM_DISABLE: (same as FM_DELETED)
*/
typedef uint32 FM_SectorUsage_t;

/* Sector not in use */
#define FM_NOT_USED 0xFFFFFFFFU

/* Sector being programmed */
#define FM_TO_BE_USED 0xFFFFFFFEU

/* Length of FM written to FM header */
#define FM_LENGTH_WRITTEN 0xFFFFFFFCU

/* FM completely written, and can be used */
#define FM_IN_USE0 0xFFFF0000U

/* Preparing to upgrade FM for the first time */
#define FM_UPGRADING0 0xFFFE0000U

/* First upgrade failed */
#define FM_IN_USE1 0xFFFC0000U

/* Preparing to upgrade FM for the second time */
#define FM_UPGRADING1 0xFFFE0000U

/* Second upgrade failed */
#define FM_IN_USE2 0xFFFC0000U

/* Preparing to upgrade FM for the third time */
#define FM_UPGRADING2 0xFFFE0000U

/* Third upgrade failed */
#define FM_IN_USE3 0xFFFC0000U

/* Preparing to upgrade FM for the fourth (last) time */
#define FM_UPGRADING3 0xFFFE0000U

/* FM Deleted => Sector(s) can be re-used */
#define FM_DELETED 0xF0000000U
#define FM_DISABLED 0xF0000000U

/* Version of the FM_Header_t format. The initial version is 0, and it is
   incremented by 1 every time it is changed in such a way that it is no longer
   compatible with the older versions. */
typedef uint32 FM_FormatVersion_t;

/* Serial number of an FM. This field is not interpreted by the SCF, or the
   PKISupt. If unused, it should be set to 0. */
typedef uint32 FM_SerialNumber_t;

/* Functionality module entry point */
typedef uint32 (*FM_Entry)( void );

/* Number of bytes in the hash inside the FM Header */
#define FM_HDR_HASH_LENGTH 20

/*	 This structure is the functionality module header. It holds information
	 about the functionality module in the Flash ROM.
 */
typedef struct FM_Header_st {
	/* The current usage status of the FM */
	FM_SectorUsage_t sectorUsage;

	/* Hash of the FM (including header, excluding usage and hash fields in
	   header). The hash is calculated using the SHA-1 algorithm. */
	uint8 hash[FM_HDR_HASH_LENGTH];

	/* The version of the FM Header format */
	FM_FormatVersion_t formatVersion;

	/* FM Number of the functionality module */
	FmNumber_t number;

	/* Version of the FM */
	FmVersion_t version;

	/* Serial number of FM, or 0x00000000 */
	FM_SerialNumber_t serialNo;

	/* Production Date/Time of the FM */
	SP_DateTimeHSM productionDate;
	char pad[3];

	/* Manufacturer ID (zero terminated) */
	char manufacturerId[32];

	/* Name of the FM (zero terminated) */
	char productId[32];

	/* Start address of the FM */
	FM_Entry entry;

	/* Base address of data group.*/
	uint32 dataSegBase;

	/* End address of the data group. The data contained in this address is not
	   part of the data group. */
	uint32 dataSegEnd;

	/* Reserved for future extensions */
	uint32 reserved[3];

	/* Length of the FM body in Flash ROM */
	uint32 length;
} FM_Header_t;

#define FM_HEADER_SYMBOL  FM_Header
#define FM_HEADER_NAME   "FM_Header"

#endif /* INC_FMHDR_H */
