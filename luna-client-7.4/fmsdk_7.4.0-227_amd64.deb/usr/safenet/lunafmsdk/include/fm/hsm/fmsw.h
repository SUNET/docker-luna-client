/*
Copyright © 2004-18 SafeNet. All rights reserved.

This file contains information that is proprietary to SafeNet and may not be
distributed or copied without written consent from SafeNet.
*/

/**
 * @file Funcitonality Module Switcher. This module handles directing requests
 * received from the HIFACE to the correct dispatch handler function.
 */
#ifndef INC_FMSW_H
#define INC_FMSW_H

#include "stdint.h"
#include "fm/hsm/fm_io_service.h"
#include "fm/hsm/mkfmhdr.h"

/**
 * Error codes for FM Switcher module.
 */
typedef enum {
	/** The function completed OK. */
	FMSW_OK = 0,

	/** There is already a function registered for FM */
	FMSW_ALREADY_REGISTERED,

	/** Invalid FM number */
	FMSW_BAD_FM_NUMBER,

	/** Bad pointer value */
	FMSW_BAD_POINTER,

	/** Not enough memory to complete operation */
	FMSW_INSUFFICIENT_RESOURCES,

	/** The function was not registered for FM */
	FMSW_NOT_REGISTERED,

	/** The FM is currently handling a message */
	FMSW_BUSY,

	/** Message dispatching on FM is blocked. */
	FMSW_DISPATCH_BLOCKED
} FMSW_STATUS;



/**
 * FM number type.
 */
typedef uint16_t FMSW_FmNumber_t;

/**
 * Special value for FM number, indicating "not an FM"
 */
#define FMSW_INVALID_FM ((FMSW_FmNumber_t)0xFFFFu)

/**
 * Randon Access Dispatch entry point function pointer type.
 *
 * @param token
 *   A token used to allocate reply buffers, and send the reply back to host.
 *
 * @param reqBuffer
 *   Pointer to the request buffer.
 *
 * @param reqLength
 *   Length of the request buffer.
 */

typedef void (*FMSW_RandomDispatchFn_t)(FmMsgHandle token, void *reqBuffer, uint32_t reqLength);


/**
 * Streaming IO Model Dispatch entry point function pointer type.
 *
 * @param token
 *   A token used to associate reply buffers, and send the reply back to host.
 */

typedef int (*FMSW_StreamDispatchFn_t)(FmMsgHandle token);



/**
 * Register dispatch function. The dispatch function handles the host
 * messages sent to the FM.
 *
 * @param fmNumber
 *   FM Number
 *
 * @param dispatch
 *   Dispatch function pointer.
 *
 * @return
 *   @li FMSW_OK: The function was registered successfully.
 *   @li FMSW_BAD_POINTER: The function pointer is invalid
 *   @li FMSW_INSUFFISICENT_RESOURCES: Not enough memory to complete operation
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_ALREADY_REGISTERED: A dispatch function was already registered.
 */
FMSW_STATUS FMSW_RegisterRandomDispatch(FMSW_FmNumber_t fmNumber,
                                        FMSW_RandomDispatchFn_t dispatch);

/**
 * Register Stream dispatch function. The dispatch function handles the host
 * messages sent to the FM using new serial io api.
 *
 * @param fmNumber
 *   FM Number
 *
 * @param dispatch
 *   Dispatch function pointer.
 *
 * @return
 *   @li FMSW_OK: The function was registered successfully.
 *   @li FMSW_BAD_POINTER: The function pointer is invalid
 *   @li FMSW_INSUFFISICENT_RESOURCES: Not enough memory to complete operation
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_ALREADY_REGISTERED: A dispatch function was already registered.
 */
FMSW_STATUS FMSW_RegisterStreamDispatch(FMSW_FmNumber_t fmNumber,
                                        FMSW_StreamDispatchFn_t dispatch);


/**
 * Deregister a dispatch function. The function will not be called again after
 * this function returns.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @return
 *   none
 */
void FMSW_DeregisterDispatch(FMSW_FmNumber_t fmNumber);

// tl: the following may be useful additions, but remove them from the public header
// if we do not add them
#if 0

/**
 * Register shutdown function. The shutdown function is called before the system
 * is restarted.
 *
 * @note This functionality is not used in the current firmware.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @param shutdown
 *   Shudown function pointer.
 *
 * Return Value:
 *   @li FMSW_OK: The function was registered successfully.
 *   @li FMSW_BAD_POINTER: The function pointer is invalid
 *   @li FMSW_INSUFFISICENT_RESOURCES: Not enough memory to complete operation
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_ALREADY_REGISTERED: A shutdown function was already registered.
 */
FMSW_STATUS FMSW_RegisterShutdown(FMSW_FmNumber_t fmNumber,
								  FMSW_ShutdownFn_t shutdown);

/**
 * Register an unload function. The unload function will be called
 * when the FM is about to be unloaded.
 *
 * @note This functionality is not used in the current firmware.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @param unload
 *   Unload function pointer.
 *
 * @return
 *   @li FMSW_OK: The function was registered successfully.
 *   @li FMSW_BAD_POINTER: The function pointer is invalid
 *   @li FMSW_INSUFFISICENT_RESOURCES: Not enough memory to complete operation
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_ALREADY_REGISTERED: An unload function was already registered.
 */
FMSW_STATUS FMSW_RegisterUnload(FMSW_FmNumber_t fmNumber,
								FMSW_UnloadFn_t unload);

/**
 * Register callaout table. The callout table is used by other FMs to
 * call functions of the FM.
 *
 * @note This functionality is not used in the current firmware.
 *
 * @param fmNumber
 *   FM Number
 *
 * @param table
 *   Address of the callout table.
 *
 * @return
 *   @li FMSW_OK: The function was registered successfully.
 *   @li FMSW_BAD_POINTER: The function pointer is invalid
 *   @li FMSW_INSUFFISICENT_RESOURCES: Not enough memory to complete operation
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_ALREADY_REGISTERED: A callout table was already registered.
 */
FMSW_STATUS FMSW_RegisterFnTable(FMSW_FmNumber_t fmNumber,
								 const void *table);

/**
 * Deregister a notify function.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @param notify
 *   Address of the notify function. It must match the currently registered
 *   notify function address.
 *
 * @return
 *   @li FMSW_OK: The function was deregistered OK.
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: The function was not registered for fmNumber.
 */
FMSW_STATUS FMSW_DeregisterHostNotify(FMSW_FmNumber_t fmNumber,
									  FMSW_HostNotifyFn_t notify);

/**
 * Deregister a shutdown function.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @param shotdown
 *   Address of the shutdown function to be de-registered. It must match the
 *   currently registered function address.
 *
 * @return
 *   @li FMSW_OK: The function was deregistered OK.
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: The function was not registered for fmNumber.
 */
FMSW_STATUS FMSW_DeregisterShutdown(FMSW_FmNumber_t fmNumber,
									FMSW_ShutdownFn_t shutdown);

/**
 * Deregister an unload function.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @param unload
 *   Address of the function to be de-registered. It must match the currently
 *   registered function address.
 *
 * @return
 *   @li FMSW_OK: The function was deregistered OK.
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: The function was not registered for fmNumber.
 */
FMSW_STATUS FMSW_DeregisterUnload(FMSW_FmNumber_t fmNumber,
								  FMSW_UnloadFn_t unload);

/**
 * Dispatch a command to a functionality module.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @param token
 *   A token used to allocate reply buffers, and send the reply back to the host.
 *
 * @param reqBuffer
 *   Start address of the request buffer.
 *
 * @param reqLength
 *   Length, in number of bytes, of the request buffer.
 *
 * @return
 *   @li FMSW_OK: The function processed the command OK.
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: The functionality module specified has not
 *       registered a dispatch function.
 *   @li FMSW_DISPATCH_BLOCKED: Message dispatching on FM is blocked.
 */
FMSW_STATUS FMSW_CallDispatch(FMSW_FmNumber_t fmNumber,
							  uint32_t token,
							  void *reqBuffer,
							  uint32_t reqLength);



/**
 * Request that a Functionality Module shutdown.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @param sdType
 *   The type of shutdown.
 *
 * @return
 *   @li FMSW_OK: The FM has shutdown OK.
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: A shutdown function was not registered for fmNumber.
 */
FMSW_STATUS FMSW_CallShutdown(FMSW_FmNumber_t fmNumber,
							  FMSW_ShutdownType_t sdType);

/**
 * Request a FM to get ready for unload.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @return
 *   @li FMSW_OK: unload function called successfully.
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: An unload function was not registered for fmNumber.
 */
FMSW_STATUS FMSW_CallUnload(FMSW_FmNumber_t fmNumber);

/**
 * This function is used to obtain the callout table registered with
 * the specified functionality module.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @param table
 *   Address of the variable that will receive the address of the callout table.
 *
 * @return
 *   @li FMSW_OK: unload function called successfully.
 *   @li BAD_POINTER: the table parameter is not a valid pointer.
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: A callout table was not registered for fmNumber.
 */
FMSW_STATUS FMSW_GetFnTable(FMSW_FmNumber_t fmNumber, void **table);

/**
 * Determine if a Functionality Module is currently handling a message dispatch.
 *
 * @param fmNumber
 *    FM Number.
 *
 * Return Value:
 *   @li FMSW_OK: The FM is not busy.
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: The FM has not registered a dispatch function.
 *   @li FMSW_BUSY: The FM is processing requests at the moment.
 */
FMSW_STATUS FMSW_IsBusy(FMSW_FmNumber_t fmNumber);

/**
 * Block all calls to a Functionality Module.
 *
 * @param fmNumber
 *    FM Number.
 *
 * @return
 *   @li FMSW_OK: All calls to the FM are now being blocked.
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: The functionality module specified has not
 *   registered a dispatch entry point with the switcher.
 */
FMSW_STATUS FMSW_BlockDispatch(FMSW_FmNumber_t fmNumber);

/**
 * Unblock message dispatching on fmNumber.
 *
 * @param fmNumber
 *   FM Number.
 *
 * @return
 *   @li FMSW_OK: Dispatches are allowed to the
 *   @li FMSW_BAD_FM_NUMBER: The FM number is incorrect.
 *   @li FMSW_NOT_REGISTERED: The functionality module specified has not
 *   registered a dispatch entry point with the switcher.
 */
FMSW_STATUS FMSW_UnBlockDispatch(FMSW_FmNumber_t fmNumber);

/**
 * This function is used to enumerate all FMs which registered at least one
 * function. The first FM number is obtained by passing FMSW_INVALID_FM in
 * current. For all subsequent FMs, the FM number obtained should be passed to
 * the function in the 'current' parameter.
 *
 * @param current
 *   The FM number to start the search on. The special value @c FMSW_INVALID_FM
 *   is used to start the search.
 *
 * @return
 *   @li The FM number following 'current'. When 'current is FMSW_INVALID_FM,
 *       the first FM number is returned.
 *   @li If there are no more registered FMs, or the 'current' parameter is
 *       invalid, FMSW_INVALID_FM is returned.
 */
FMSW_FmNumber_t FMSW_GetNextFm(FMSW_FmNumber_t current);
#endif

#endif /* INC_FMSW_H */
